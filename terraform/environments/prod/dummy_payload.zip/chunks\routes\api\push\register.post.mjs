import { d as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const subscription = (body == null ? void 0 : body.subscription) || body;
  if (!subscription || !subscription.endpoint) {
    return { error: "Invalid subscription" };
  }
  const filePath = path.resolve(process.cwd(), "..", ".push-subscription.json");
  fs.writeFileSync(filePath, JSON.stringify(subscription, null, 2), "utf-8");
  console.log("[Push Register] Subscription saved to:", filePath);
  return { success: true, savedTo: filePath };
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
