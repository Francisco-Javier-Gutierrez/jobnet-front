import { d as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event).catch(() => ({}));
  const subscription = (body == null ? void 0 : body.subscription) || body;
  if (!subscription || !subscription.endpoint) {
    return { success: true, message: "No subscription provided" };
  }
  return { success: true };
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
