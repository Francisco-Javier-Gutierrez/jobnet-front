import { d as defineEventHandler, r as readBody, l as createError, A as getCognitoConfig, B as calculateSecretHash, C as callCognito, e as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const linkAccount_post = defineEventHandler(async (event) => {
  var _a;
  const body = await readBody(event);
  const { email, password, googleSub } = body;
  if (!email || !password || !googleSub) {
    throw createError({
      statusCode: 400,
      statusMessage: "Faltan datos obligatorios para vincular la cuenta (email, contrase\xF1a o identificador de Google)."
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const authParams = {
    USERNAME: email,
    PASSWORD: password
  };
  if (clientSecret) {
    authParams.SECRET_HASH = calculateSecretHash(email, clientId, clientSecret);
  }
  let authResult;
  try {
    const res = await callCognito("InitiateAuth", {
      AuthFlow: "USER_PASSWORD_AUTH",
      ClientId: clientId,
      AuthParameters: authParams
    });
    authResult = res.AuthenticationResult;
  } catch (error) {
    throw createError({
      statusCode: 401,
      statusMessage: "La contrase\xF1a ingresada es incorrecta. Por favor verifique sus credenciales para autorizar la vinculaci\xF3n.",
      data: { code: "InvalidPasswordForLinking" }
    });
  }
  let nativeUserId = "";
  if (authResult == null ? void 0 : authResult.IdToken) {
    try {
      const payloadBase64 = authResult.IdToken.split(".")[1];
      const payload = JSON.parse(
        Buffer.from(payloadBase64, "base64").toString("ascii")
      );
      nativeUserId = payload.sub;
    } catch {
    }
  }
  const config = useRuntimeConfig();
  if (!nativeUserId) {
    const profiles = await $fetch(
      `${config.public.apiUrl}/profiles`
    ).catch(() => []);
    const matched = profiles.find(
      (p) => p.email && p.email.toLowerCase() === email.toLowerCase() && p.origenRegistro !== "GOOGLE_OAUTH"
    );
    nativeUserId = (matched == null ? void 0 : matched.id) || ((_a = matched == null ? void 0 : matched.PK) == null ? void 0 : _a.replace("USER#", "")) || "";
  }
  if (!nativeUserId) {
    throw createError({
      statusCode: 404,
      statusMessage: "No se localiz\xF3 el perfil nativo asociado al correo."
    });
  }
  const updatedProfile = await $fetch(
    `${config.public.apiUrl}/profile/${nativeUserId}`,
    {
      method: "POST",
      headers: {
        "x-user-id": nativeUserId,
        "x-user-role": "CANDIDATO"
      },
      body: {
        isFederated: true,
        linkedGoogleSub: googleSub,
        origenRegistro: "LINKED_GOOGLE",
        fechaVinculacion: (/* @__PURE__ */ new Date()).toISOString()
      }
    }
  ).catch((err) => {
    console.error("Error al actualizar perfil con vinculaci\xF3n de Google:", err);
    return null;
  });
  return {
    success: true,
    message: "Cuenta de Google vinculada exitosamente con tu cuenta de JobNet.",
    nativeUserId,
    profile: updatedProfile
  };
});

export { linkAccount_post as default };
//# sourceMappingURL=link-account.post.mjs.map
