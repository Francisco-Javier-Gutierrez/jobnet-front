import { d as defineEventHandler, J as getRouterParam, e as useRuntimeConfig, f as getHeader, o as createError, r as readBody, K as MOCK_INCIDENTS } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const openAudit_post = defineEventHandler(async (event) => {
  const incidentId = getRouterParam(event, "id");
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = (getHeader(event, "x-user-role") || "MODERATOR").toUpperCase();
  if (userRoleHeader !== "MODERATOR" && userRoleHeader !== "MODERADOR" && userRoleHeader !== "ADMIN") {
    throw createError({
      statusCode: 403,
      statusMessage: "Acceso denegado: Apertura de auditor\xEDa de mensajer\xEDa exclusiva para Moderadores."
    });
  }
  const body = await readBody(event).catch(() => ({}));
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/moderator/incidents/${incidentId}/open-audit`,
      {
        method: "POST",
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader
        },
        body
      }
    );
    if (backendData == null ? void 0 : backendData.success) {
      return backendData;
    }
  } catch {
  }
  const incident = MOCK_INCIDENTS.find((i) => i.id === incidentId);
  if (incident) {
    incident.estatus = "AUDITORIA";
    incident.status = "AUDITORIA";
    incident.auditState = "AUDIT_ACTIVE";
    incident.supervisionStatus = "UNDER_AUDIT";
    incident.auditOpenedAt = (/* @__PURE__ */ new Date()).toISOString();
  }
  return {
    success: true,
    message: "Fase 1 completada: Notificaci\xF3n formal despachada a ambas partes. El canal de mensajer\xEDa privada entra en periodo de revisi\xF3n supervisada.",
    incidentId,
    auditState: "AUDIT_ACTIVE",
    supervisionStatus: "UNDER_AUDIT"
  };
});

export { openAudit_post as default };
//# sourceMappingURL=open-audit.post.mjs.map
