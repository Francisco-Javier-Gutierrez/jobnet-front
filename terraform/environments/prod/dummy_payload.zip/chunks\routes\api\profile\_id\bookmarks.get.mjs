import { d as defineEventHandler, e as useRuntimeConfig, g as getQuery, f as getHeader, o as createError } from '../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const bookmarks_get = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  const query = getQuery(event);
  const userId = query.userId || getHeader(event, "x-user-id") || getHeader(event, "user-id") || "";
  try {
    const data = await $fetch(
      `${config.public.apiUrl}/profile/${encodeURIComponent(id || "")}/bookmarks`,
      {
        headers: userId ? { "x-user-id": userId } : {}
      }
    );
    return data;
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error fetching profile bookmarks from backend",
      data: error.data || { data: [], posts: [], jobs: [] }
    });
  }
});

export { bookmarks_get as default };
//# sourceMappingURL=bookmarks.get.mjs.map
