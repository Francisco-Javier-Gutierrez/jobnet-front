import { d as defineEventHandler, r as readBody, l as createError, A as getCognitoConfig, B as calculateSecretHash, C as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const resendCode_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email } = body;
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email es obligatorio"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const params = {
    ClientId: clientId,
    Username: email
  };
  if (clientSecret) {
    params.SecretHash = calculateSecretHash(email, clientId, clientSecret);
  }
  try {
    await callCognito("ResendConfirmationCode", params);
    return {
      success: true,
      message: "C\xF3digo de verificaci\xF3n reenviado con \xE9xito"
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al reenviar el c\xF3digo",
      data: error.data || {}
    });
  }
});

export { resendCode_post as default };
//# sourceMappingURL=resend-code.post.mjs.map
