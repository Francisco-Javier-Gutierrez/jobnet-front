import { y as defineEventHandler, r as readBody, j as createError, z as getCognitoConfig, A as calculateSecretHash, B as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const register_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, password, role, fullname, companyName, taxId, phone } = body;
  if (!email || !password || !role) {
    throw createError({
      statusCode: 400,
      statusMessage: "Faltan campos obligatorios"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const userAttributes = [
    { Name: "email", Value: email },
    { Name: "custom:role", Value: role }
  ];
  if (role === "candidate" || role === "blank" || role === "unassigned") {
    userAttributes.push({ Name: "name", Value: fullname || "" });
  } else if (role === "company") {
    userAttributes.push({ Name: "name", Value: companyName || "" });
    if (taxId) {
      userAttributes.push({ Name: "custom:tax_id", Value: taxId });
    }
    if (phone) {
      userAttributes.push({ Name: "phone_number", Value: phone });
    }
  }
  const signUpParams = {
    ClientId: clientId,
    Username: email,
    Password: password,
    UserAttributes: userAttributes,
    ClientMetadata: {
      tipoUsuario: role,
      role,
      nombre: fullname || companyName || ""
    }
  };
  if (clientSecret) {
    signUpParams.SecretHash = calculateSecretHash(
      email,
      clientId,
      clientSecret
    );
  }
  try {
    const result = await callCognito("SignUp", signUpParams);
    return {
      success: true,
      userConfirmed: result.UserConfirmed,
      userSub: result.UserSub
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al registrar el usuario",
      data: error.data || {}
    });
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
