import { y as defineEventHandler, e as useRuntimeConfig, r as readBody, j as createError } from '../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const share_post = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  const body = await readBody(event);
  try {
    const data = await $fetch(
      `${config.public.apiUrl}/posts/${id}/share`,
      {
        method: "POST",
        body
      }
    );
    return data;
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error registering share in AWS backend",
      data: error.data || {}
    });
  }
});

export { share_post as default };
//# sourceMappingURL=share.post.mjs.map
