import { j as useTypedBackendConfig, e as useRuntimeConfig, E as ERROR_MESSAGES, k as defu, l as eventHandler, s as sendRedirect, m as getHeaders, p as parseCookies, g as getQuery, o as createError, q as isMethod, r as readBody, t as getResponseHeader, v as setResponseHeader, x as setCookie, y as getRequestHost, z as getRequestProtocol, A as getServerOrigin, B as translateCognitoError } from '../../../_/nitro.mjs';
import * as crypto from 'crypto';
import crypto__default, { createHash, randomFillSync, KeyObject, timingSafeEqual as timingSafeEqual$1, createHmac, getCiphers, createDecipheriv, createCipheriv, createSecretKey, createPublicKey, diffieHellman, generateKeyPair as generateKeyPair$1, pbkdf2 as pbkdf2$1, privateDecrypt, publicEncrypt, constants, createPrivateKey } from 'crypto';
import * as openidClient from 'openid-client';
import * as oauth from 'oauth';
import { Buffer as Buffer$1 } from 'buffer';
import * as util from 'util';
import { promisify } from 'util';
import { inflateRaw as inflateRaw$1, deflateRaw as deflateRaw$1 } from 'zlib';
import * as preactRenderToString from 'preact-render-to-string';
import * as preact from 'preact';
import * as cookie$1 from 'cookie';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

function getDefaultExportFromNamespaceIfNotNamed (n) {
	return n && Object.prototype.hasOwnProperty.call(n, 'default') && Object.keys(n).length === 1 ? n['default'] : n;
}

var cognito = {};

Object.defineProperty(cognito, "__esModule", {
  value: true
});
var _default$2 = cognito.default = Cognito;

function Cognito(options) {
  return {
    id: "cognito",
    name: "Cognito",
    type: "oauth",
    wellKnown: `${options.issuer}/.well-known/openid-configuration`,
    idToken: true,

    profile(profile) {
      return {
        id: profile.sub,
        name: profile.name,
        email: profile.email,
        image: profile.picture
      };
    },

    style: {
      logo: "/cognito.svg",
      logoDark: "/cognito.svg",
      bg: "#fff",
      text: "#C17B9E",
      bgDark: "#fff",
      textDark: "#C17B9E"
    },
    options
  };
}

var credentials = {};

Object.defineProperty(credentials, "__esModule", {
  value: true
});
var _default$1 = credentials.default = Credentials;

function Credentials(options) {
  return {
    id: "credentials",
    name: "Credentials",
    type: "credentials",
    credentials: {},
    authorize: () => null,
    options
  };
}

var core = {};

var interopRequireDefault = {exports: {}};

(function (module) {
	function _interopRequireDefault(e) {
	  return e && e.__esModule ? e : {
	    "default": e
	  };
	}
	module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports; 
} (interopRequireDefault));

var interopRequireDefaultExports = interopRequireDefault.exports;

var logger = {};

var defineProperty = {exports: {}};

var toPropertyKey = {exports: {}};

var _typeof = {exports: {}};

var hasRequired_typeof;

function require_typeof () {
	if (hasRequired_typeof) return _typeof.exports;
	hasRequired_typeof = 1;
	(function (module) {
		function _typeof(o) {
		  "@babel/helpers - typeof";

		  return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
		    return typeof o;
		  } : function (o) {
		    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
		}
		module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (_typeof));
	return _typeof.exports;
}

var toPrimitive = {exports: {}};

var hasRequiredToPrimitive;

function requireToPrimitive () {
	if (hasRequiredToPrimitive) return toPrimitive.exports;
	hasRequiredToPrimitive = 1;
	(function (module) {
		var _typeof = /*@__PURE__*/ require_typeof()["default"];
		function toPrimitive(t, r) {
		  if ("object" != _typeof(t) || !t) return t;
		  var e = t[Symbol.toPrimitive];
		  if (void 0 !== e) {
		    var i = e.call(t, r || "default");
		    if ("object" != _typeof(i)) return i;
		    throw new TypeError("@@toPrimitive must return a primitive value.");
		  }
		  return ("string" === r ? String : Number)(t);
		}
		module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (toPrimitive));
	return toPrimitive.exports;
}

var hasRequiredToPropertyKey;

function requireToPropertyKey () {
	if (hasRequiredToPropertyKey) return toPropertyKey.exports;
	hasRequiredToPropertyKey = 1;
	(function (module) {
		var _typeof = /*@__PURE__*/ require_typeof()["default"];
		var toPrimitive = /*@__PURE__*/ requireToPrimitive();
		function toPropertyKey(t) {
		  var i = toPrimitive(t, "string");
		  return "symbol" == _typeof(i) ? i : i + "";
		}
		module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (toPropertyKey));
	return toPropertyKey.exports;
}

var hasRequiredDefineProperty;

function requireDefineProperty () {
	if (hasRequiredDefineProperty) return defineProperty.exports;
	hasRequiredDefineProperty = 1;
	(function (module) {
		var toPropertyKey = /*@__PURE__*/ requireToPropertyKey();
		function _defineProperty(e, r, t) {
		  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		    value: t,
		    enumerable: true,
		    configurable: true,
		    writable: true
		  }) : e[r] = t, e;
		}
		module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (defineProperty));
	return defineProperty.exports;
}

var errors = {};

var regeneratorRuntime$1 = {exports: {}};

var OverloadYield = {exports: {}};

var hasRequiredOverloadYield;

function requireOverloadYield () {
	if (hasRequiredOverloadYield) return OverloadYield.exports;
	hasRequiredOverloadYield = 1;
	(function (module) {
		function _OverloadYield(e, d) {
		  this.v = e, this.k = d;
		}
		module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (OverloadYield));
	return OverloadYield.exports;
}

var regenerator$1 = {exports: {}};

var regeneratorDefine = {exports: {}};

var hasRequiredRegeneratorDefine;

function requireRegeneratorDefine () {
	if (hasRequiredRegeneratorDefine) return regeneratorDefine.exports;
	hasRequiredRegeneratorDefine = 1;
	(function (module) {
		function _regeneratorDefine(e, r, n, t) {
		  var i = Object.defineProperty;
		  try {
		    i({}, "", {});
		  } catch (e) {
		    i = 0;
		  }
		  module.exports = _regeneratorDefine = function regeneratorDefine(e, r, n, t) {
		    function o(r, n) {
		      _regeneratorDefine(e, r, function (e) {
		        return this._invoke(r, n, e);
		      });
		    }
		    r ? i ? i(e, r, {
		      value: n,
		      enumerable: !t,
		      configurable: !t,
		      writable: !t
		    }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2));
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _regeneratorDefine(e, r, n, t);
		}
		module.exports = _regeneratorDefine, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorDefine));
	return regeneratorDefine.exports;
}

var hasRequiredRegenerator$1;

function requireRegenerator$1 () {
	if (hasRequiredRegenerator$1) return regenerator$1.exports;
	hasRequiredRegenerator$1 = 1;
	(function (module) {
		var regeneratorDefine = /*@__PURE__*/ requireRegeneratorDefine();
		function _regenerator() {
		  /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */
		  var e,
		    t,
		    r = "function" == typeof Symbol ? Symbol : {},
		    n = r.iterator || "@@iterator",
		    o = r.toStringTag || "@@toStringTag";
		  function i(r, n, o, i) {
		    var c = n && n.prototype instanceof Generator ? n : Generator,
		      u = Object.create(c.prototype);
		    return regeneratorDefine(u, "_invoke", function (r, n, o) {
		      var i,
		        c,
		        u,
		        f = 0,
		        p = o || [],
		        y = false,
		        G = {
		          p: 0,
		          n: 0,
		          v: e,
		          a: d,
		          f: d.bind(e, 4),
		          d: function d(t, r) {
		            return i = t, c = 0, u = e, G.n = r, a;
		          }
		        };
		      function d(r, n) {
		        for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) {
		          var o,
		            i = p[t],
		            d = G.p,
		            l = i[2];
		          r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0));
		        }
		        if (o || r > 1) return a;
		        throw y = true, n;
		      }
		      return function (o, p, l) {
		        if (f > 1) throw TypeError("Generator is already running");
		        for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) {
		          i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u);
		          try {
		            if (f = 2, i) {
		              if (c || (o = "next"), t = i[o]) {
		                if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object");
		                if (!t.done) return t;
		                u = t.value, c < 2 && (c = 0);
		              } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1);
		              i = e;
		            } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break;
		          } catch (t) {
		            i = e, c = 1, u = t;
		          } finally {
		            f = 1;
		          }
		        }
		        return {
		          value: t,
		          done: y
		        };
		      };
		    }(r, o, i), true), u;
		  }
		  var a = {};
		  function Generator() {}
		  function GeneratorFunction() {}
		  function GeneratorFunctionPrototype() {}
		  t = Object.getPrototypeOf;
		  var c = [][n] ? t(t([][n]())) : (regeneratorDefine(t = {}, n, function () {
		      return this;
		    }), t),
		    u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c);
		  function f(e) {
		    return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, regeneratorDefine(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e;
		  }
		  return GeneratorFunction.prototype = GeneratorFunctionPrototype, regeneratorDefine(u, "constructor", GeneratorFunctionPrototype), regeneratorDefine(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", regeneratorDefine(GeneratorFunctionPrototype, o, "GeneratorFunction"), regeneratorDefine(u), regeneratorDefine(u, o, "Generator"), regeneratorDefine(u, n, function () {
		    return this;
		  }), regeneratorDefine(u, "toString", function () {
		    return "[object Generator]";
		  }), (module.exports = _regenerator = function _regenerator() {
		    return {
		      w: i,
		      m: f
		    };
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
		}
		module.exports = _regenerator, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regenerator$1));
	return regenerator$1.exports;
}

var regeneratorAsync = {exports: {}};

var regeneratorAsyncGen = {exports: {}};

var regeneratorAsyncIterator = {exports: {}};

var hasRequiredRegeneratorAsyncIterator;

function requireRegeneratorAsyncIterator () {
	if (hasRequiredRegeneratorAsyncIterator) return regeneratorAsyncIterator.exports;
	hasRequiredRegeneratorAsyncIterator = 1;
	(function (module) {
		var OverloadYield = /*@__PURE__*/ requireOverloadYield();
		var regeneratorDefine = /*@__PURE__*/ requireRegeneratorDefine();
		function AsyncIterator(t, e) {
		  function n(r, o, i, f) {
		    try {
		      var c = t[r](o),
		        u = c.value;
		      return u instanceof OverloadYield ? e.resolve(u.v).then(function (t) {
		        n("next", t, i, f);
		      }, function (t) {
		        n("throw", t, i, f);
		      }) : e.resolve(u).then(function (t) {
		        c.value = t, i(c);
		      }, function (t) {
		        return n("throw", t, i, f);
		      });
		    } catch (t) {
		      f(t);
		    }
		  }
		  var r;
		  this.next || (regeneratorDefine(AsyncIterator.prototype), regeneratorDefine(AsyncIterator.prototype, "function" == typeof Symbol && Symbol.asyncIterator || "@asyncIterator", function () {
		    return this;
		  })), regeneratorDefine(this, "_invoke", function (t, o, i) {
		    function f() {
		      return new e(function (e, r) {
		        n(t, i, e, r);
		      });
		    }
		    return r = r ? r.then(f, f) : f();
		  }, true);
		}
		module.exports = AsyncIterator, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorAsyncIterator));
	return regeneratorAsyncIterator.exports;
}

var hasRequiredRegeneratorAsyncGen;

function requireRegeneratorAsyncGen () {
	if (hasRequiredRegeneratorAsyncGen) return regeneratorAsyncGen.exports;
	hasRequiredRegeneratorAsyncGen = 1;
	(function (module) {
		var regenerator = /*@__PURE__*/ requireRegenerator$1();
		var regeneratorAsyncIterator = /*@__PURE__*/ requireRegeneratorAsyncIterator();
		function _regeneratorAsyncGen(r, e, t, o, n) {
		  return new regeneratorAsyncIterator(regenerator().w(r, e, t, o), n || Promise);
		}
		module.exports = _regeneratorAsyncGen, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorAsyncGen));
	return regeneratorAsyncGen.exports;
}

var hasRequiredRegeneratorAsync;

function requireRegeneratorAsync () {
	if (hasRequiredRegeneratorAsync) return regeneratorAsync.exports;
	hasRequiredRegeneratorAsync = 1;
	(function (module) {
		var regeneratorAsyncGen = /*@__PURE__*/ requireRegeneratorAsyncGen();
		function _regeneratorAsync(n, e, r, t, o) {
		  var a = regeneratorAsyncGen(n, e, r, t, o);
		  return a.next().then(function (n) {
		    return n.done ? n.value : a.next();
		  });
		}
		module.exports = _regeneratorAsync, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorAsync));
	return regeneratorAsync.exports;
}

var regeneratorKeys = {exports: {}};

var hasRequiredRegeneratorKeys;

function requireRegeneratorKeys () {
	if (hasRequiredRegeneratorKeys) return regeneratorKeys.exports;
	hasRequiredRegeneratorKeys = 1;
	(function (module) {
		function _regeneratorKeys(e) {
		  var n = Object(e),
		    r = [];
		  for (var t in n) r.unshift(t);
		  return function e() {
		    for (; r.length;) if ((t = r.pop()) in n) return e.value = t, e.done = false, e;
		    return e.done = true, e;
		  };
		}
		module.exports = _regeneratorKeys, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorKeys));
	return regeneratorKeys.exports;
}

var regeneratorValues = {exports: {}};

var hasRequiredRegeneratorValues;

function requireRegeneratorValues () {
	if (hasRequiredRegeneratorValues) return regeneratorValues.exports;
	hasRequiredRegeneratorValues = 1;
	(function (module) {
		var _typeof = /*@__PURE__*/ require_typeof()["default"];
		function _regeneratorValues(e) {
		  if (null != e) {
		    var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"],
		      r = 0;
		    if (t) return t.call(e);
		    if ("function" == typeof e.next) return e;
		    if (!isNaN(e.length)) return {
		      next: function next() {
		        return e && r >= e.length && (e = void 0), {
		          value: e && e[r++],
		          done: !e
		        };
		      }
		    };
		  }
		  throw new TypeError(_typeof(e) + " is not iterable");
		}
		module.exports = _regeneratorValues, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorValues));
	return regeneratorValues.exports;
}

var hasRequiredRegeneratorRuntime;

function requireRegeneratorRuntime () {
	if (hasRequiredRegeneratorRuntime) return regeneratorRuntime$1.exports;
	hasRequiredRegeneratorRuntime = 1;
	(function (module) {
		var OverloadYield = /*@__PURE__*/ requireOverloadYield();
		var regenerator = /*@__PURE__*/ requireRegenerator$1();
		var regeneratorAsync = /*@__PURE__*/ requireRegeneratorAsync();
		var regeneratorAsyncGen = /*@__PURE__*/ requireRegeneratorAsyncGen();
		var regeneratorAsyncIterator = /*@__PURE__*/ requireRegeneratorAsyncIterator();
		var regeneratorKeys = /*@__PURE__*/ requireRegeneratorKeys();
		var regeneratorValues = /*@__PURE__*/ requireRegeneratorValues();
		function _regeneratorRuntime() {

		  var r = regenerator(),
		    e = r.m(_regeneratorRuntime),
		    t = (Object.getPrototypeOf ? Object.getPrototypeOf(e) : e.__proto__).constructor;
		  function n(r) {
		    var e = "function" == typeof r && r.constructor;
		    return !!e && (e === t || "GeneratorFunction" === (e.displayName || e.name));
		  }
		  var o = {
		    "throw": 1,
		    "return": 2,
		    "break": 3,
		    "continue": 3
		  };
		  function a(r) {
		    var e, t;
		    return function (n) {
		      e || (e = {
		        stop: function stop() {
		          return t(n.a, 2);
		        },
		        "catch": function _catch() {
		          return n.v;
		        },
		        abrupt: function abrupt(r, e) {
		          return t(n.a, o[r], e);
		        },
		        delegateYield: function delegateYield(r, o, a) {
		          return e.resultName = o, t(n.d, regeneratorValues(r), a);
		        },
		        finish: function finish(r) {
		          return t(n.f, r);
		        }
		      }, t = function t(r, _t, o) {
		        n.p = e.prev, n.n = e.next;
		        try {
		          return r(_t, o);
		        } finally {
		          e.next = n.n;
		        }
		      }), e.resultName && (e[e.resultName] = n.v, e.resultName = void 0), e.sent = n.v, e.next = n.n;
		      try {
		        return r.call(this, e);
		      } finally {
		        n.p = e.prev, n.n = e.next;
		      }
		    };
		  }
		  return (module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
		    return {
		      wrap: function wrap(e, t, n, o) {
		        return r.w(a(e), t, n, o && o.reverse());
		      },
		      isGeneratorFunction: n,
		      mark: r.m,
		      awrap: function awrap(r, e) {
		        return new OverloadYield(r, e);
		      },
		      AsyncIterator: regeneratorAsyncIterator,
		      async: function async(r, e, t, o, u) {
		        return (n(e) ? regeneratorAsyncGen : regeneratorAsync)(a(r), e, t, o, u);
		      },
		      keys: regeneratorKeys,
		      values: regeneratorValues
		    };
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
		}
		module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (regeneratorRuntime$1));
	return regeneratorRuntime$1.exports;
}

var regenerator;
var hasRequiredRegenerator;

function requireRegenerator () {
	if (hasRequiredRegenerator) return regenerator;
	hasRequiredRegenerator = 1;
	// TODO(Babel 8): Remove this file.

	var runtime = /*@__PURE__*/ requireRegeneratorRuntime()();
	regenerator = runtime;

	// Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
	try {
	  regeneratorRuntime = runtime;
	} catch (accidentalStrictMode) {
	  if (typeof globalThis === "object") {
	    globalThis.regeneratorRuntime = runtime;
	  } else {
	    Function("r", "regeneratorRuntime = r")(runtime);
	  }
	}
	return regenerator;
}

var asyncToGenerator = {exports: {}};

var hasRequiredAsyncToGenerator;

function requireAsyncToGenerator () {
	if (hasRequiredAsyncToGenerator) return asyncToGenerator.exports;
	hasRequiredAsyncToGenerator = 1;
	(function (module) {
		function asyncGeneratorStep(n, t, e, r, o, a, c) {
		  try {
		    var i = n[a](c),
		      u = i.value;
		  } catch (n) {
		    return void e(n);
		  }
		  i.done ? t(u) : Promise.resolve(u).then(r, o);
		}
		function _asyncToGenerator(n) {
		  return function () {
		    var t = this,
		      e = arguments;
		    return new Promise(function (r, o) {
		      var a = n.apply(t, e);
		      function _next(n) {
		        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
		      }
		      function _throw(n) {
		        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
		      }
		      _next(void 0);
		    });
		  };
		}
		module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (asyncToGenerator));
	return asyncToGenerator.exports;
}

var assertThisInitialized = {exports: {}};

var hasRequiredAssertThisInitialized;

function requireAssertThisInitialized () {
	if (hasRequiredAssertThisInitialized) return assertThisInitialized.exports;
	hasRequiredAssertThisInitialized = 1;
	(function (module) {
		function _assertThisInitialized(e) {
		  if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
		  return e;
		}
		module.exports = _assertThisInitialized, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (assertThisInitialized));
	return assertThisInitialized.exports;
}

var classCallCheck = {exports: {}};

var hasRequiredClassCallCheck;

function requireClassCallCheck () {
	if (hasRequiredClassCallCheck) return classCallCheck.exports;
	hasRequiredClassCallCheck = 1;
	(function (module) {
		function _classCallCheck(a, n) {
		  if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
		}
		module.exports = _classCallCheck, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classCallCheck));
	return classCallCheck.exports;
}

var createClass = {exports: {}};

var hasRequiredCreateClass;

function requireCreateClass () {
	if (hasRequiredCreateClass) return createClass.exports;
	hasRequiredCreateClass = 1;
	(function (module) {
		var toPropertyKey = /*@__PURE__*/ requireToPropertyKey();
		function _defineProperties(e, r) {
		  for (var t = 0; t < r.length; t++) {
		    var o = r[t];
		    o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, toPropertyKey(o.key), o);
		  }
		}
		function _createClass(e, r, t) {
		  return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
		    writable: false
		  }), e;
		}
		module.exports = _createClass, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (createClass));
	return createClass.exports;
}

var inherits = {exports: {}};

var setPrototypeOf = {exports: {}};

var hasRequiredSetPrototypeOf;

function requireSetPrototypeOf () {
	if (hasRequiredSetPrototypeOf) return setPrototypeOf.exports;
	hasRequiredSetPrototypeOf = 1;
	(function (module) {
		function _setPrototypeOf(t, e) {
		  return module.exports = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
		    return t.__proto__ = e, t;
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _setPrototypeOf(t, e);
		}
		module.exports = _setPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (setPrototypeOf));
	return setPrototypeOf.exports;
}

var hasRequiredInherits;

function requireInherits () {
	if (hasRequiredInherits) return inherits.exports;
	hasRequiredInherits = 1;
	(function (module) {
		var setPrototypeOf = /*@__PURE__*/ requireSetPrototypeOf();
		function _inherits(t, e) {
		  if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
		  t.prototype = Object.create(e && e.prototype, {
		    constructor: {
		      value: t,
		      writable: true,
		      configurable: true
		    }
		  }), Object.defineProperty(t, "prototype", {
		    writable: false
		  }), e && setPrototypeOf(t, e);
		}
		module.exports = _inherits, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (inherits));
	return inherits.exports;
}

var possibleConstructorReturn = {exports: {}};

var hasRequiredPossibleConstructorReturn;

function requirePossibleConstructorReturn () {
	if (hasRequiredPossibleConstructorReturn) return possibleConstructorReturn.exports;
	hasRequiredPossibleConstructorReturn = 1;
	(function (module) {
		var _typeof = /*@__PURE__*/ require_typeof()["default"];
		var assertThisInitialized = /*@__PURE__*/ requireAssertThisInitialized();
		function _possibleConstructorReturn(t, e) {
		  if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
		  if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
		  return assertThisInitialized(t);
		}
		module.exports = _possibleConstructorReturn, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (possibleConstructorReturn));
	return possibleConstructorReturn.exports;
}

var getPrototypeOf = {exports: {}};

var hasRequiredGetPrototypeOf;

function requireGetPrototypeOf () {
	if (hasRequiredGetPrototypeOf) return getPrototypeOf.exports;
	hasRequiredGetPrototypeOf = 1;
	(function (module) {
		function _getPrototypeOf(t) {
		  return module.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
		    return t.__proto__ || Object.getPrototypeOf(t);
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _getPrototypeOf(t);
		}
		module.exports = _getPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (getPrototypeOf));
	return getPrototypeOf.exports;
}

var wrapNativeSuper = {exports: {}};

var isNativeFunction = {exports: {}};

var hasRequiredIsNativeFunction;

function requireIsNativeFunction () {
	if (hasRequiredIsNativeFunction) return isNativeFunction.exports;
	hasRequiredIsNativeFunction = 1;
	(function (module) {
		function _isNativeFunction(t) {
		  try {
		    return -1 !== Function.toString.call(t).indexOf("[native code]");
		  } catch (n) {
		    return "function" == typeof t;
		  }
		}
		module.exports = _isNativeFunction, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (isNativeFunction));
	return isNativeFunction.exports;
}

var construct = {exports: {}};

var isNativeReflectConstruct = {exports: {}};

var hasRequiredIsNativeReflectConstruct;

function requireIsNativeReflectConstruct () {
	if (hasRequiredIsNativeReflectConstruct) return isNativeReflectConstruct.exports;
	hasRequiredIsNativeReflectConstruct = 1;
	(function (module) {
		function _isNativeReflectConstruct() {
		  try {
		    var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
		  } catch (t) {}
		  return (module.exports = _isNativeReflectConstruct = function _isNativeReflectConstruct() {
		    return !!t;
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
		}
		module.exports = _isNativeReflectConstruct, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (isNativeReflectConstruct));
	return isNativeReflectConstruct.exports;
}

var hasRequiredConstruct;

function requireConstruct () {
	if (hasRequiredConstruct) return construct.exports;
	hasRequiredConstruct = 1;
	(function (module) {
		var isNativeReflectConstruct = /*@__PURE__*/ requireIsNativeReflectConstruct();
		var setPrototypeOf = /*@__PURE__*/ requireSetPrototypeOf();
		function _construct(t, e, r) {
		  if (isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
		  var o = [null];
		  o.push.apply(o, e);
		  var p = new (t.bind.apply(t, o))();
		  return r && setPrototypeOf(p, r.prototype), p;
		}
		module.exports = _construct, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (construct));
	return construct.exports;
}

var hasRequiredWrapNativeSuper;

function requireWrapNativeSuper () {
	if (hasRequiredWrapNativeSuper) return wrapNativeSuper.exports;
	hasRequiredWrapNativeSuper = 1;
	(function (module) {
		var getPrototypeOf = /*@__PURE__*/ requireGetPrototypeOf();
		var setPrototypeOf = /*@__PURE__*/ requireSetPrototypeOf();
		var isNativeFunction = /*@__PURE__*/ requireIsNativeFunction();
		var construct = /*@__PURE__*/ requireConstruct();
		function _wrapNativeSuper(t) {
		  var r = "function" == typeof Map ? new Map() : void 0;
		  return module.exports = _wrapNativeSuper = function _wrapNativeSuper(t) {
		    if (null === t || !isNativeFunction(t)) return t;
		    if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
		    if (void 0 !== r) {
		      if (r.has(t)) return r.get(t);
		      r.set(t, Wrapper);
		    }
		    function Wrapper() {
		      return construct(t, arguments, getPrototypeOf(this).constructor);
		    }
		    return Wrapper.prototype = Object.create(t.prototype, {
		      constructor: {
		        value: Wrapper,
		        enumerable: false,
		        writable: true,
		        configurable: true
		      }
		    }), setPrototypeOf(Wrapper, t);
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _wrapNativeSuper(t);
		}
		module.exports = _wrapNativeSuper, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (wrapNativeSuper));
	return wrapNativeSuper.exports;
}

var hasRequiredErrors;

function requireErrors () {
	if (hasRequiredErrors) return errors;
	hasRequiredErrors = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(errors, "__esModule", {
	  value: true
	});
	errors.UnsupportedStrategy = errors.UnknownError = errors.OAuthCallbackError = errors.MissingSecret = errors.MissingAuthorize = errors.MissingAdapterMethods = errors.MissingAdapter = errors.MissingAPIRoute = errors.InvalidCallbackUrl = errors.AccountNotLinkedError = void 0;
	errors.adapterErrorHandler = adapterErrorHandler;
	errors.capitalize = capitalize;
	errors.eventsErrorHandler = eventsErrorHandler;
	errors.upperSnake = upperSnake;

	var _regenerator = _interopRequireDefault(/*@__PURE__*/ requireRegenerator());

	var _asyncToGenerator2 = _interopRequireDefault(/*@__PURE__*/ requireAsyncToGenerator());

	var _assertThisInitialized2 = _interopRequireDefault(/*@__PURE__*/ requireAssertThisInitialized());

	var _defineProperty2 = _interopRequireDefault(/*@__PURE__*/ requireDefineProperty());

	var _classCallCheck2 = _interopRequireDefault(/*@__PURE__*/ requireClassCallCheck());

	var _createClass2 = _interopRequireDefault(/*@__PURE__*/ requireCreateClass());

	var _inherits2 = _interopRequireDefault(/*@__PURE__*/ requireInherits());

	var _possibleConstructorReturn2 = _interopRequireDefault(/*@__PURE__*/ requirePossibleConstructorReturn());

	var _getPrototypeOf2 = _interopRequireDefault(/*@__PURE__*/ requireGetPrototypeOf());

	var _wrapNativeSuper2 = _interopRequireDefault(/*@__PURE__*/ requireWrapNativeSuper());

	function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2.default)(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2.default)(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2.default)(this, result); }; }

	function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

	var UnknownError = function (_Error) {
	  (0, _inherits2.default)(UnknownError, _Error);

	  var _super = _createSuper(UnknownError);

	  function UnknownError(error) {
	    var _message;

	    var _this;

	    (0, _classCallCheck2.default)(this, UnknownError);
	    _this = _super.call(this, (_message = error === null || error === void 0 ? void 0 : error.message) !== null && _message !== void 0 ? _message : error);
	    _this.name = "UnknownError";
	    _this.code = error.code;

	    if (error instanceof Error) {
	      _this.stack = error.stack;
	    }

	    return _this;
	  }

	  (0, _createClass2.default)(UnknownError, [{
	    key: "toJSON",
	    value: function toJSON() {
	      return {
	        name: this.name,
	        message: this.message,
	        stack: this.stack
	      };
	    }
	  }]);
	  return UnknownError;
	}((0, _wrapNativeSuper2.default)(Error));

	errors.UnknownError = UnknownError;

	var OAuthCallbackError = function (_UnknownError) {
	  (0, _inherits2.default)(OAuthCallbackError, _UnknownError);

	  var _super2 = _createSuper(OAuthCallbackError);

	  function OAuthCallbackError() {
	    var _this2;

	    (0, _classCallCheck2.default)(this, OAuthCallbackError);

	    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    _this2 = _super2.call.apply(_super2, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this2), "name", "OAuthCallbackError");
	    return _this2;
	  }

	  return (0, _createClass2.default)(OAuthCallbackError);
	}(UnknownError);

	errors.OAuthCallbackError = OAuthCallbackError;

	var AccountNotLinkedError = function (_UnknownError2) {
	  (0, _inherits2.default)(AccountNotLinkedError, _UnknownError2);

	  var _super3 = _createSuper(AccountNotLinkedError);

	  function AccountNotLinkedError() {
	    var _this3;

	    (0, _classCallCheck2.default)(this, AccountNotLinkedError);

	    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
	      args[_key2] = arguments[_key2];
	    }

	    _this3 = _super3.call.apply(_super3, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this3), "name", "AccountNotLinkedError");
	    return _this3;
	  }

	  return (0, _createClass2.default)(AccountNotLinkedError);
	}(UnknownError);

	errors.AccountNotLinkedError = AccountNotLinkedError;

	var MissingAPIRoute = function (_UnknownError3) {
	  (0, _inherits2.default)(MissingAPIRoute, _UnknownError3);

	  var _super4 = _createSuper(MissingAPIRoute);

	  function MissingAPIRoute() {
	    var _this4;

	    (0, _classCallCheck2.default)(this, MissingAPIRoute);

	    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
	      args[_key3] = arguments[_key3];
	    }

	    _this4 = _super4.call.apply(_super4, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this4), "name", "MissingAPIRouteError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this4), "code", "MISSING_NEXTAUTH_API_ROUTE_ERROR");
	    return _this4;
	  }

	  return (0, _createClass2.default)(MissingAPIRoute);
	}(UnknownError);

	errors.MissingAPIRoute = MissingAPIRoute;

	var MissingSecret = function (_UnknownError4) {
	  (0, _inherits2.default)(MissingSecret, _UnknownError4);

	  var _super5 = _createSuper(MissingSecret);

	  function MissingSecret() {
	    var _this5;

	    (0, _classCallCheck2.default)(this, MissingSecret);

	    for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
	      args[_key4] = arguments[_key4];
	    }

	    _this5 = _super5.call.apply(_super5, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this5), "name", "MissingSecretError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this5), "code", "NO_SECRET");
	    return _this5;
	  }

	  return (0, _createClass2.default)(MissingSecret);
	}(UnknownError);

	errors.MissingSecret = MissingSecret;

	var MissingAuthorize = function (_UnknownError5) {
	  (0, _inherits2.default)(MissingAuthorize, _UnknownError5);

	  var _super6 = _createSuper(MissingAuthorize);

	  function MissingAuthorize() {
	    var _this6;

	    (0, _classCallCheck2.default)(this, MissingAuthorize);

	    for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
	      args[_key5] = arguments[_key5];
	    }

	    _this6 = _super6.call.apply(_super6, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this6), "name", "MissingAuthorizeError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this6), "code", "CALLBACK_CREDENTIALS_HANDLER_ERROR");
	    return _this6;
	  }

	  return (0, _createClass2.default)(MissingAuthorize);
	}(UnknownError);

	errors.MissingAuthorize = MissingAuthorize;

	var MissingAdapter = function (_UnknownError6) {
	  (0, _inherits2.default)(MissingAdapter, _UnknownError6);

	  var _super7 = _createSuper(MissingAdapter);

	  function MissingAdapter() {
	    var _this7;

	    (0, _classCallCheck2.default)(this, MissingAdapter);

	    for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
	      args[_key6] = arguments[_key6];
	    }

	    _this7 = _super7.call.apply(_super7, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this7), "name", "MissingAdapterError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this7), "code", "EMAIL_REQUIRES_ADAPTER_ERROR");
	    return _this7;
	  }

	  return (0, _createClass2.default)(MissingAdapter);
	}(UnknownError);

	errors.MissingAdapter = MissingAdapter;

	var MissingAdapterMethods = function (_UnknownError7) {
	  (0, _inherits2.default)(MissingAdapterMethods, _UnknownError7);

	  var _super8 = _createSuper(MissingAdapterMethods);

	  function MissingAdapterMethods() {
	    var _this8;

	    (0, _classCallCheck2.default)(this, MissingAdapterMethods);

	    for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
	      args[_key7] = arguments[_key7];
	    }

	    _this8 = _super8.call.apply(_super8, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this8), "name", "MissingAdapterMethodsError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this8), "code", "MISSING_ADAPTER_METHODS_ERROR");
	    return _this8;
	  }

	  return (0, _createClass2.default)(MissingAdapterMethods);
	}(UnknownError);

	errors.MissingAdapterMethods = MissingAdapterMethods;

	var UnsupportedStrategy = function (_UnknownError8) {
	  (0, _inherits2.default)(UnsupportedStrategy, _UnknownError8);

	  var _super9 = _createSuper(UnsupportedStrategy);

	  function UnsupportedStrategy() {
	    var _this9;

	    (0, _classCallCheck2.default)(this, UnsupportedStrategy);

	    for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
	      args[_key8] = arguments[_key8];
	    }

	    _this9 = _super9.call.apply(_super9, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this9), "name", "UnsupportedStrategyError");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this9), "code", "CALLBACK_CREDENTIALS_JWT_ERROR");
	    return _this9;
	  }

	  return (0, _createClass2.default)(UnsupportedStrategy);
	}(UnknownError);

	errors.UnsupportedStrategy = UnsupportedStrategy;

	var InvalidCallbackUrl = function (_UnknownError9) {
	  (0, _inherits2.default)(InvalidCallbackUrl, _UnknownError9);

	  var _super10 = _createSuper(InvalidCallbackUrl);

	  function InvalidCallbackUrl() {
	    var _this10;

	    (0, _classCallCheck2.default)(this, InvalidCallbackUrl);

	    for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
	      args[_key9] = arguments[_key9];
	    }

	    _this10 = _super10.call.apply(_super10, [this].concat(args));
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this10), "name", "InvalidCallbackUrl");
	    (0, _defineProperty2.default)((0, _assertThisInitialized2.default)(_this10), "code", "INVALID_CALLBACK_URL_ERROR");
	    return _this10;
	  }

	  return (0, _createClass2.default)(InvalidCallbackUrl);
	}(UnknownError);

	errors.InvalidCallbackUrl = InvalidCallbackUrl;

	function upperSnake(s) {
	  return s.replace(/([A-Z])/g, "_$1").toUpperCase();
	}

	function capitalize(s) {
	  return "".concat(s[0].toUpperCase()).concat(s.slice(1));
	}

	function eventsErrorHandler(methods, logger) {
	  return Object.keys(methods).reduce(function (acc, name) {
	    acc[name] = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee() {
	      var method,
	          _args = arguments;
	      return _regenerator.default.wrap(function _callee$(_context) {
	        while (1) {
	          switch (_context.prev = _context.next) {
	            case 0:
	              _context.prev = 0;
	              method = methods[name];
	              _context.next = 4;
	              return method.apply(void 0, _args);

	            case 4:
	              return _context.abrupt("return", _context.sent);

	            case 7:
	              _context.prev = 7;
	              _context.t0 = _context["catch"](0);
	              logger.error("".concat(upperSnake(name), "_EVENT_ERROR"), _context.t0);

	            case 10:
	            case "end":
	              return _context.stop();
	          }
	        }
	      }, _callee, null, [[0, 7]]);
	    }));
	    return acc;
	  }, {});
	}

	function adapterErrorHandler(adapter, logger) {
	  if (!adapter) return;
	  return Object.keys(adapter).reduce(function (acc, name) {
	    acc[name] = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee2() {
	      var _len10,
	          args,
	          _key10,
	          method,
	          e,
	          _args2 = arguments;

	      return _regenerator.default.wrap(function _callee2$(_context2) {
	        while (1) {
	          switch (_context2.prev = _context2.next) {
	            case 0:
	              _context2.prev = 0;

	              for (_len10 = _args2.length, args = new Array(_len10), _key10 = 0; _key10 < _len10; _key10++) {
	                args[_key10] = _args2[_key10];
	              }

	              logger.debug("adapter_".concat(name), {
	                args: args
	              });
	              method = adapter[name];
	              _context2.next = 6;
	              return method.apply(void 0, args);

	            case 6:
	              return _context2.abrupt("return", _context2.sent);

	            case 9:
	              _context2.prev = 9;
	              _context2.t0 = _context2["catch"](0);
	              logger.error("adapter_error_".concat(name), _context2.t0);
	              e = new UnknownError(_context2.t0);
	              e.name = "".concat(capitalize(name), "Error");
	              throw e;

	            case 15:
	            case "end":
	              return _context2.stop();
	          }
	        }
	      }, _callee2, null, [[0, 9]]);
	    }));
	    return acc;
	  }, {});
	}
	return errors;
}

var _interopRequireDefault$1 = interopRequireDefaultExports;

Object.defineProperty(logger, "__esModule", {
  value: true
});
logger.default = void 0;
logger.proxyLogger = proxyLogger;
logger.setLogger = setLogger;

var _defineProperty2 = _interopRequireDefault$1(/*@__PURE__*/ requireDefineProperty());

var _errors = /*@__PURE__*/ requireErrors();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function formatError(o) {
  if (o instanceof Error && !(o instanceof _errors.UnknownError)) {
    return {
      message: o.message,
      stack: o.stack,
      name: o.name
    };
  }

  if (hasErrorProperty(o)) {
    var _o$message;

    o.error = formatError(o.error);
    o.message = (_o$message = o.message) !== null && _o$message !== void 0 ? _o$message : o.error.message;
  }

  return o;
}

function hasErrorProperty(x) {
  return !!(x !== null && x !== void 0 && x.error);
}

var _logger$1 = {
  error: function error(code, metadata) {
    metadata = formatError(metadata);
    console.error("[next-auth][error][".concat(code, "]"), "\nhttps://next-auth.js.org/errors#".concat(code.toLowerCase()), metadata.message, metadata);
  },
  warn: function warn(code) {
    console.warn("[next-auth][warn][".concat(code, "]"), "\nhttps://next-auth.js.org/warnings#".concat(code.toLowerCase()));
  },
  debug: function debug(code, metadata) {
    console.log("[next-auth][debug][".concat(code, "]"), metadata);
  }
};

function setLogger() {
  var newLogger = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var debug = arguments.length > 1 ? arguments[1] : undefined;
  if (!debug) _logger$1.debug = function () {};
  if (newLogger.error) _logger$1.error = newLogger.error;
  if (newLogger.warn) _logger$1.warn = newLogger.warn;
  if (newLogger.debug) _logger$1.debug = newLogger.debug;
}

var _default = _logger$1;
logger.default = _default;

function proxyLogger() {
  var logger = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _logger$1;
  var basePath = arguments.length > 1 ? arguments[1] : undefined;

  try {
    if ("undefined" === "undefined") {
      return logger;
    }

    var clientLogger = {};

    var _loop = function _loop(level) {
      clientLogger[level] = function (code, metadata) {
        _logger$1[level](code, metadata);

        if (level === "error") {
          metadata = formatError(metadata);
        }

        ;
        metadata.client = true;
        var url = "".concat(basePath, "/_log");
        var body = new URLSearchParams(_objectSpread({
          level: level,
          code: code
        }, metadata));

        if (navigator.sendBeacon) {
          return navigator.sendBeacon(url, body);
        }

        return fetch(url, {
          method: "POST",
          body: body,
          keepalive: true
        });
      };
    };

    for (var level in logger) {
      _loop(level);
    }

    return clientLogger;
  } catch (_unused) {
    return _logger$1;
  }
}

var detectHost$1 = {};

Object.defineProperty(detectHost$1, "__esModule", {
  value: true
});
detectHost$1.detectHost = detectHost;

function detectHost(forwardedHost) {
  var _process$env$VERCEL;

  if ((_process$env$VERCEL = process.env.VERCEL) !== null && _process$env$VERCEL !== void 0 ? _process$env$VERCEL : process.env.AUTH_TRUST_HOST) return forwardedHost;
  return process.env.NEXTAUTH_URL;
}

var routes$1 = {};

var callback$1 = {};

var callback = {};

const require$$0$2 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(openidClient);

var client = {};

var hasRequiredClient;

function requireClient () {
	if (hasRequiredClient) return client;
	hasRequiredClient = 1;

	Object.defineProperty(client, "__esModule", {
	  value: true
	});
	client.openidClient = openidClient;

	var _openidClient = require$$0$2;

	async function openidClient(options) {
	  const provider = options.provider;
	  if (provider.httpOptions) _openidClient.custom.setHttpOptionsDefaults(provider.httpOptions);
	  let issuer;

	  if (provider.wellKnown) {
	    issuer = await _openidClient.Issuer.discover(provider.wellKnown);
	  } else {
	    var _provider$authorizati, _provider$token, _provider$userinfo;

	    issuer = new _openidClient.Issuer({
	      issuer: provider.issuer,
	      authorization_endpoint: (_provider$authorizati = provider.authorization) === null || _provider$authorizati === void 0 ? void 0 : _provider$authorizati.url,
	      token_endpoint: (_provider$token = provider.token) === null || _provider$token === void 0 ? void 0 : _provider$token.url,
	      userinfo_endpoint: (_provider$userinfo = provider.userinfo) === null || _provider$userinfo === void 0 ? void 0 : _provider$userinfo.url,
	      jwks_uri: provider.jwks_endpoint
	    });
	  }

	  const client = new issuer.Client({
	    client_id: provider.clientId,
	    client_secret: provider.clientSecret,
	    redirect_uris: [provider.callbackUrl],
	    ...provider.client
	  }, provider.jwks);
	  client[_openidClient.custom.clock_tolerance] = 10;
	  return client;
	}
	return client;
}

var clientLegacy = {};

const require$$0$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(oauth);

var hasRequiredClientLegacy;

function requireClientLegacy () {
	if (hasRequiredClientLegacy) return clientLegacy;
	hasRequiredClientLegacy = 1;

	Object.defineProperty(clientLegacy, "__esModule", {
	  value: true
	});
	clientLegacy.oAuth1Client = oAuth1Client;
	clientLegacy.oAuth1TokenStore = void 0;

	var _oauth = require$$0$1;

	function oAuth1Client(options) {
	  var _provider$version, _provider$encoding;

	  const provider = options.provider;
	  const oauth1Client = new _oauth.OAuth(provider.requestTokenUrl, provider.accessTokenUrl, provider.clientId, provider.clientSecret, (_provider$version = provider.version) !== null && _provider$version !== void 0 ? _provider$version : "1.0", provider.callbackUrl, (_provider$encoding = provider.encoding) !== null && _provider$encoding !== void 0 ? _provider$encoding : "HMAC-SHA1");
	  const originalGet = oauth1Client.get.bind(oauth1Client);

	  oauth1Client.get = async (...args) => {
	    return await new Promise((resolve, reject) => {
	      originalGet(...args, (error, result) => {
	        if (error) {
	          return reject(error);
	        }

	        resolve(result);
	      });
	    });
	  };

	  const originalGetOAuth1AccessToken = oauth1Client.getOAuthAccessToken.bind(oauth1Client);

	  oauth1Client.getOAuthAccessToken = async (...args) => {
	    return await new Promise((resolve, reject) => {
	      originalGetOAuth1AccessToken(...args, (error, oauth_token, oauth_token_secret) => {
	        if (error) {
	          return reject(error);
	        }

	        resolve({
	          oauth_token,
	          oauth_token_secret
	        });
	      });
	    });
	  };

	  const originalGetOAuthRequestToken = oauth1Client.getOAuthRequestToken.bind(oauth1Client);

	  oauth1Client.getOAuthRequestToken = async (params = {}) => {
	    return await new Promise((resolve, reject) => {
	      originalGetOAuthRequestToken(params, (error, oauth_token, oauth_token_secret, params) => {
	        if (error) {
	          return reject(error);
	        }

	        resolve({
	          oauth_token,
	          oauth_token_secret,
	          params
	        });
	      });
	    });
	  };

	  return oauth1Client;
	}

	const oAuth1TokenStore = new Map();
	clientLegacy.oAuth1TokenStore = oAuth1TokenStore;
	return clientLegacy;
}

var checks = {};

var jwt = {};

const digest = (algorithm, data) => createHash(algorithm).update(data).digest();

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const MAX_INT32 = 2 ** 32;
function concat(...buffers) {
    const size = buffers.reduce((acc, { length }) => acc + length, 0);
    const buf = new Uint8Array(size);
    let i = 0;
    buffers.forEach((buffer) => {
        buf.set(buffer, i);
        i += buffer.length;
    });
    return buf;
}
function p2s(alg, p2sInput) {
    return concat(encoder.encode(alg), new Uint8Array([0]), p2sInput);
}
function writeUInt32BE(buf, value, offset) {
    if (value < 0 || value >= MAX_INT32) {
        throw new RangeError(`value must be >= 0 and <= ${MAX_INT32 - 1}. Received ${value}`);
    }
    buf.set([value >>> 24, value >>> 16, value >>> 8, value & 0xff], offset);
}
function uint64be(value) {
    const high = Math.floor(value / MAX_INT32);
    const low = value % MAX_INT32;
    const buf = new Uint8Array(8);
    writeUInt32BE(buf, high, 0);
    writeUInt32BE(buf, low, 4);
    return buf;
}
function uint32be(value) {
    const buf = new Uint8Array(4);
    writeUInt32BE(buf, value);
    return buf;
}
function lengthAndInput(input) {
    return concat(uint32be(input.length), input);
}
async function concatKdf(secret, bits, value) {
    const iterations = Math.ceil((bits >> 3) / 32);
    const res = new Uint8Array(iterations * 32);
    for (let iter = 0; iter < iterations; iter++) {
        const buf = new Uint8Array(4 + secret.length + value.length);
        buf.set(uint32be(iter + 1));
        buf.set(secret, 4);
        buf.set(value, 4 + secret.length);
        res.set(await digest('sha256', buf), iter * 32);
    }
    return res.slice(0, bits >> 3);
}

let encode;
function normalize(input) {
    let encoded = input;
    if (encoded instanceof Uint8Array) {
        encoded = decoder.decode(encoded);
    }
    return encoded;
}
if (Buffer$1.isEncoding('base64url')) {
    encode = (input) => Buffer$1.from(input).toString('base64url');
}
else {
    encode = (input) => Buffer$1.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
const decode = (input) => Buffer$1.from(normalize(input), 'base64');

class JOSEError extends Error {
    static get code() {
        return 'ERR_JOSE_GENERIC';
    }
    constructor(message) {
        var _a;
        super(message);
        this.code = 'ERR_JOSE_GENERIC';
        this.name = this.constructor.name;
        (_a = Error.captureStackTrace) === null || _a === void 0 ? void 0 : _a.call(Error, this, this.constructor);
    }
}
class JWTClaimValidationFailed extends JOSEError {
    static get code() {
        return 'ERR_JWT_CLAIM_VALIDATION_FAILED';
    }
    constructor(message, claim = 'unspecified', reason = 'unspecified') {
        super(message);
        this.code = 'ERR_JWT_CLAIM_VALIDATION_FAILED';
        this.claim = claim;
        this.reason = reason;
    }
}
class JWTExpired extends JOSEError {
    static get code() {
        return 'ERR_JWT_EXPIRED';
    }
    constructor(message, claim = 'unspecified', reason = 'unspecified') {
        super(message);
        this.code = 'ERR_JWT_EXPIRED';
        this.claim = claim;
        this.reason = reason;
    }
}
class JOSEAlgNotAllowed extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JOSE_ALG_NOT_ALLOWED';
    }
    static get code() {
        return 'ERR_JOSE_ALG_NOT_ALLOWED';
    }
}
class JOSENotSupported extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JOSE_NOT_SUPPORTED';
    }
    static get code() {
        return 'ERR_JOSE_NOT_SUPPORTED';
    }
}
class JWEDecryptionFailed extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JWE_DECRYPTION_FAILED';
        this.message = 'decryption operation failed';
    }
    static get code() {
        return 'ERR_JWE_DECRYPTION_FAILED';
    }
}
class JWEDecompressionFailed extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JWE_DECOMPRESSION_FAILED';
        this.message = 'decompression operation failed';
    }
    static get code() {
        return 'ERR_JWE_DECOMPRESSION_FAILED';
    }
}
class JWEInvalid extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JWE_INVALID';
    }
    static get code() {
        return 'ERR_JWE_INVALID';
    }
}
class JWTInvalid extends JOSEError {
    constructor() {
        super(...arguments);
        this.code = 'ERR_JWT_INVALID';
    }
    static get code() {
        return 'ERR_JWT_INVALID';
    }
}

function bitLength$1(alg) {
    switch (alg) {
        case 'A128GCM':
        case 'A128GCMKW':
        case 'A192GCM':
        case 'A192GCMKW':
        case 'A256GCM':
        case 'A256GCMKW':
            return 96;
        case 'A128CBC-HS256':
        case 'A192CBC-HS384':
        case 'A256CBC-HS512':
            return 128;
        default:
            throw new JOSENotSupported(`Unsupported JWE Algorithm: ${alg}`);
    }
}
const generateIv = (alg) => randomFillSync(new Uint8Array(bitLength$1(alg) >> 3));

const checkIvLength = (enc, iv) => {
    if (iv.length << 3 !== bitLength$1(enc)) {
        throw new JWEInvalid('Invalid Initialization Vector length');
    }
};

const isKeyObject = util.types.isKeyObject
    ? (obj) => util.types.isKeyObject(obj)
    : (obj) => obj != null && obj instanceof KeyObject;

const checkCekLength = (enc, cek) => {
    let expected;
    switch (enc) {
        case 'A128CBC-HS256':
        case 'A192CBC-HS384':
        case 'A256CBC-HS512':
            expected = parseInt(enc.slice(-3), 10);
            break;
        case 'A128GCM':
        case 'A192GCM':
        case 'A256GCM':
            expected = parseInt(enc.slice(1, 4), 10);
            break;
        default:
            throw new JOSENotSupported(`Content Encryption Algorithm ${enc} is not supported either by JOSE or your javascript runtime`);
    }
    if (cek instanceof Uint8Array) {
        const actual = cek.byteLength << 3;
        if (actual !== expected) {
            throw new JWEInvalid(`Invalid Content Encryption Key length. Expected ${expected} bits, got ${actual} bits`);
        }
        return;
    }
    if (isKeyObject(cek) && cek.type === 'secret') {
        const actual = cek.symmetricKeySize << 3;
        if (actual !== expected) {
            throw new JWEInvalid(`Invalid Content Encryption Key length. Expected ${expected} bits, got ${actual} bits`);
        }
        return;
    }
    throw new TypeError('Invalid Content Encryption Key type');
};

const timingSafeEqual = timingSafeEqual$1;

function cbcTag(aad, iv, ciphertext, macSize, macKey, keySize) {
    const macData = concat(aad, iv, ciphertext, uint64be(aad.length << 3));
    const hmac = createHmac(`sha${macSize}`, macKey);
    hmac.update(macData);
    return hmac.digest().slice(0, keySize >> 3);
}

const webcrypto = crypto.webcrypto;
const isCryptoKey = util.types.isCryptoKey
    ? (key) => util.types.isCryptoKey(key)
    :
        (key) => false;

function unusable(name, prop = 'algorithm.name') {
    return new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`);
}
function isAlgorithm(algorithm, name) {
    return algorithm.name === name;
}
function getHashLength(hash) {
    return parseInt(hash.name.slice(4), 10);
}
function checkUsage(key, usages) {
    if (usages.length && !usages.some((expected) => key.usages.includes(expected))) {
        let msg = 'CryptoKey does not support this operation, its usages must include ';
        if (usages.length > 2) {
            const last = usages.pop();
            msg += `one of ${usages.join(', ')}, or ${last}.`;
        }
        else if (usages.length === 2) {
            msg += `one of ${usages[0]} or ${usages[1]}.`;
        }
        else {
            msg += `${usages[0]}.`;
        }
        throw new TypeError(msg);
    }
}
function checkEncCryptoKey(key, alg, ...usages) {
    switch (alg) {
        case 'A128GCM':
        case 'A192GCM':
        case 'A256GCM': {
            if (!isAlgorithm(key.algorithm, 'AES-GCM'))
                throw unusable('AES-GCM');
            const expected = parseInt(alg.slice(1, 4), 10);
            const actual = key.algorithm.length;
            if (actual !== expected)
                throw unusable(expected, 'algorithm.length');
            break;
        }
        case 'A128KW':
        case 'A192KW':
        case 'A256KW': {
            if (!isAlgorithm(key.algorithm, 'AES-KW'))
                throw unusable('AES-KW');
            const expected = parseInt(alg.slice(1, 4), 10);
            const actual = key.algorithm.length;
            if (actual !== expected)
                throw unusable(expected, 'algorithm.length');
            break;
        }
        case 'ECDH': {
            switch (key.algorithm.name) {
                case 'ECDH':
                case 'X25519':
                case 'X448':
                    break;
                default:
                    throw unusable('ECDH, X25519, or X448');
            }
            break;
        }
        case 'PBES2-HS256+A128KW':
        case 'PBES2-HS384+A192KW':
        case 'PBES2-HS512+A256KW':
            if (!isAlgorithm(key.algorithm, 'PBKDF2'))
                throw unusable('PBKDF2');
            break;
        case 'RSA-OAEP':
        case 'RSA-OAEP-256':
        case 'RSA-OAEP-384':
        case 'RSA-OAEP-512': {
            if (!isAlgorithm(key.algorithm, 'RSA-OAEP'))
                throw unusable('RSA-OAEP');
            const expected = parseInt(alg.slice(9), 10) || 1;
            const actual = getHashLength(key.algorithm.hash);
            if (actual !== expected)
                throw unusable(`SHA-${expected}`, 'algorithm.hash');
            break;
        }
        default:
            throw new TypeError('CryptoKey does not support this operation');
    }
    checkUsage(key, usages);
}

function message(msg, actual, ...types) {
    if (types.length > 2) {
        const last = types.pop();
        msg += `one of type ${types.join(', ')}, or ${last}.`;
    }
    else if (types.length === 2) {
        msg += `one of type ${types[0]} or ${types[1]}.`;
    }
    else {
        msg += `of type ${types[0]}.`;
    }
    if (actual == null) {
        msg += ` Received ${actual}`;
    }
    else if (typeof actual === 'function' && actual.name) {
        msg += ` Received function ${actual.name}`;
    }
    else if (typeof actual === 'object' && actual != null) {
        if (actual.constructor && actual.constructor.name) {
            msg += ` Received an instance of ${actual.constructor.name}`;
        }
    }
    return msg;
}
const invalidKeyInput = (actual, ...types) => {
    return message('Key must be ', actual, ...types);
};
function withAlg(alg, actual, ...types) {
    return message(`Key for the ${alg} algorithm must be `, actual, ...types);
}

let ciphers;
const supported = (algorithm) => {
    ciphers || (ciphers = new Set(getCiphers()));
    return ciphers.has(algorithm);
};

const isKeyLike = (key) => isKeyObject(key) || isCryptoKey(key);
const types$1 = ['KeyObject'];
if (globalThis.CryptoKey || (webcrypto === null || webcrypto === void 0 ? void 0 : webcrypto.CryptoKey)) {
    types$1.push('CryptoKey');
}

function cbcDecrypt(enc, cek, ciphertext, iv, tag, aad) {
    const keySize = parseInt(enc.slice(1, 4), 10);
    if (isKeyObject(cek)) {
        cek = cek.export();
    }
    const encKey = cek.subarray(keySize >> 3);
    const macKey = cek.subarray(0, keySize >> 3);
    const macSize = parseInt(enc.slice(-3), 10);
    const algorithm = `aes-${keySize}-cbc`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${enc} is not supported by your javascript runtime`);
    }
    const expectedTag = cbcTag(aad, iv, ciphertext, macSize, macKey, keySize);
    let macCheckPassed;
    try {
        macCheckPassed = timingSafeEqual(tag, expectedTag);
    }
    catch {
    }
    if (!macCheckPassed) {
        throw new JWEDecryptionFailed();
    }
    let plaintext;
    try {
        const decipher = createDecipheriv(algorithm, encKey, iv);
        plaintext = concat(decipher.update(ciphertext), decipher.final());
    }
    catch {
    }
    if (!plaintext) {
        throw new JWEDecryptionFailed();
    }
    return plaintext;
}
function gcmDecrypt(enc, cek, ciphertext, iv, tag, aad) {
    const keySize = parseInt(enc.slice(1, 4), 10);
    const algorithm = `aes-${keySize}-gcm`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${enc} is not supported by your javascript runtime`);
    }
    try {
        const decipher = createDecipheriv(algorithm, cek, iv, { authTagLength: 16 });
        decipher.setAuthTag(tag);
        if (aad.byteLength) {
            decipher.setAAD(aad, { plaintextLength: ciphertext.length });
        }
        const plaintext = decipher.update(ciphertext);
        decipher.final();
        return plaintext;
    }
    catch {
        throw new JWEDecryptionFailed();
    }
}
const decrypt$2 = (enc, cek, ciphertext, iv, tag, aad) => {
    let key;
    if (isCryptoKey(cek)) {
        checkEncCryptoKey(cek, enc, 'decrypt');
        key = KeyObject.from(cek);
    }
    else if (cek instanceof Uint8Array || isKeyObject(cek)) {
        key = cek;
    }
    else {
        throw new TypeError(invalidKeyInput(cek, ...types$1, 'Uint8Array'));
    }
    checkCekLength(enc, key);
    checkIvLength(enc, iv);
    switch (enc) {
        case 'A128CBC-HS256':
        case 'A192CBC-HS384':
        case 'A256CBC-HS512':
            return cbcDecrypt(enc, key, ciphertext, iv, tag, aad);
        case 'A128GCM':
        case 'A192GCM':
        case 'A256GCM':
            return gcmDecrypt(enc, key, ciphertext, iv, tag, aad);
        default:
            throw new JOSENotSupported('Unsupported JWE Content Encryption Algorithm');
    }
};

const inflateRaw = promisify(inflateRaw$1);
const deflateRaw = promisify(deflateRaw$1);
const inflate = (input) => inflateRaw(input, { maxOutputLength: 250000 }).catch(() => {
    throw new JWEDecompressionFailed();
});
const deflate = (input) => deflateRaw(input);

const isDisjoint = (...headers) => {
    const sources = headers.filter(Boolean);
    if (sources.length === 0 || sources.length === 1) {
        return true;
    }
    let acc;
    for (const header of sources) {
        const parameters = Object.keys(header);
        if (!acc || acc.size === 0) {
            acc = new Set(parameters);
            continue;
        }
        for (const parameter of parameters) {
            if (acc.has(parameter)) {
                return false;
            }
            acc.add(parameter);
        }
    }
    return true;
};

function isObjectLike(value) {
    return typeof value === 'object' && value !== null;
}
function isObject(input) {
    if (!isObjectLike(input) || Object.prototype.toString.call(input) !== '[object Object]') {
        return false;
    }
    if (Object.getPrototypeOf(input) === null) {
        return true;
    }
    let proto = input;
    while (Object.getPrototypeOf(proto) !== null) {
        proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(input) === proto;
}

function checkKeySize(key, alg) {
    if (key.symmetricKeySize << 3 !== parseInt(alg.slice(1, 4), 10)) {
        throw new TypeError(`Invalid key size for alg: ${alg}`);
    }
}
function ensureKeyObject$1(key, alg, usage) {
    if (isKeyObject(key)) {
        return key;
    }
    if (key instanceof Uint8Array) {
        return createSecretKey(key);
    }
    if (isCryptoKey(key)) {
        checkEncCryptoKey(key, alg, usage);
        return KeyObject.from(key);
    }
    throw new TypeError(invalidKeyInput(key, ...types$1, 'Uint8Array'));
}
const wrap$1 = (alg, key, cek) => {
    const size = parseInt(alg.slice(1, 4), 10);
    const algorithm = `aes${size}-wrap`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
    }
    const keyObject = ensureKeyObject$1(key, alg, 'wrapKey');
    checkKeySize(keyObject, alg);
    const cipher = createCipheriv(algorithm, keyObject, Buffer$1.alloc(8, 0xa6));
    return concat(cipher.update(cek), cipher.final());
};
const unwrap$1 = (alg, key, encryptedKey) => {
    const size = parseInt(alg.slice(1, 4), 10);
    const algorithm = `aes${size}-wrap`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
    }
    const keyObject = ensureKeyObject$1(key, alg, 'unwrapKey');
    checkKeySize(keyObject, alg);
    const cipher = createDecipheriv(algorithm, keyObject, Buffer$1.alloc(8, 0xa6));
    return concat(cipher.update(encryptedKey), cipher.final());
};

const p256 = Buffer$1.from([42, 134, 72, 206, 61, 3, 1, 7]);
const p384 = Buffer$1.from([43, 129, 4, 0, 34]);
const p521 = Buffer$1.from([43, 129, 4, 0, 35]);
const secp256k1 = Buffer$1.from([43, 129, 4, 0, 10]);
const weakMap$1 = new WeakMap();
const namedCurveToJOSE = (namedCurve) => {
    switch (namedCurve) {
        case 'prime256v1':
            return 'P-256';
        case 'secp384r1':
            return 'P-384';
        case 'secp521r1':
            return 'P-521';
        case 'secp256k1':
            return 'secp256k1';
        default:
            throw new JOSENotSupported('Unsupported key curve for this operation');
    }
};
const getNamedCurve = (kee, raw) => {
    var _a;
    let key;
    if (isCryptoKey(kee)) {
        key = KeyObject.from(kee);
    }
    else if (isKeyObject(kee)) {
        key = kee;
    }
    else {
        throw new TypeError(invalidKeyInput(kee, ...types$1));
    }
    if (key.type === 'secret') {
        throw new TypeError('only "private" or "public" type keys can be used for this operation');
    }
    switch (key.asymmetricKeyType) {
        case 'ed25519':
        case 'ed448':
            return `Ed${key.asymmetricKeyType.slice(2)}`;
        case 'x25519':
        case 'x448':
            return `X${key.asymmetricKeyType.slice(1)}`;
        case 'ec': {
            if (weakMap$1.has(key)) {
                return weakMap$1.get(key);
            }
            let namedCurve = (_a = key.asymmetricKeyDetails) === null || _a === void 0 ? void 0 : _a.namedCurve;
            if (!namedCurve && key.type === 'private') {
                namedCurve = getNamedCurve(createPublicKey(key), true);
            }
            else if (!namedCurve) {
                const buf = key.export({ format: 'der', type: 'spki' });
                const i = buf[1] < 128 ? 14 : 15;
                const len = buf[i];
                const curveOid = buf.slice(i + 1, i + 1 + len);
                if (curveOid.equals(p256)) {
                    namedCurve = 'prime256v1';
                }
                else if (curveOid.equals(p384)) {
                    namedCurve = 'secp384r1';
                }
                else if (curveOid.equals(p521)) {
                    namedCurve = 'secp521r1';
                }
                else if (curveOid.equals(secp256k1)) {
                    namedCurve = 'secp256k1';
                }
                else {
                    throw new JOSENotSupported('Unsupported key curve for this operation');
                }
            }
            if (raw)
                return namedCurve;
            const curve = namedCurveToJOSE(namedCurve);
            weakMap$1.set(key, curve);
            return curve;
        }
        default:
            throw new TypeError('Invalid asymmetric key type for this operation');
    }
};
function setCurve(keyObject, curve) {
    weakMap$1.set(keyObject, curve);
}

const generateKeyPair = promisify(generateKeyPair$1);
async function deriveKey(publicKee, privateKee, algorithm, keyLength, apu = new Uint8Array(0), apv = new Uint8Array(0)) {
    let publicKey;
    if (isCryptoKey(publicKee)) {
        checkEncCryptoKey(publicKee, 'ECDH');
        publicKey = KeyObject.from(publicKee);
    }
    else if (isKeyObject(publicKee)) {
        publicKey = publicKee;
    }
    else {
        throw new TypeError(invalidKeyInput(publicKee, ...types$1));
    }
    let privateKey;
    if (isCryptoKey(privateKee)) {
        checkEncCryptoKey(privateKee, 'ECDH', 'deriveBits');
        privateKey = KeyObject.from(privateKee);
    }
    else if (isKeyObject(privateKee)) {
        privateKey = privateKee;
    }
    else {
        throw new TypeError(invalidKeyInput(privateKee, ...types$1));
    }
    const value = concat(lengthAndInput(encoder.encode(algorithm)), lengthAndInput(apu), lengthAndInput(apv), uint32be(keyLength));
    const sharedSecret = diffieHellman({ privateKey, publicKey });
    return concatKdf(sharedSecret, keyLength, value);
}
async function generateEpk(kee) {
    let key;
    if (isCryptoKey(kee)) {
        key = KeyObject.from(kee);
    }
    else if (isKeyObject(kee)) {
        key = kee;
    }
    else {
        throw new TypeError(invalidKeyInput(kee, ...types$1));
    }
    switch (key.asymmetricKeyType) {
        case 'x25519':
            return generateKeyPair('x25519');
        case 'x448': {
            return generateKeyPair('x448');
        }
        case 'ec': {
            const namedCurve = getNamedCurve(key);
            return generateKeyPair('ec', { namedCurve });
        }
        default:
            throw new JOSENotSupported('Invalid or unsupported EPK');
    }
}
const ecdhAllowed = (key) => ['P-256', 'P-384', 'P-521', 'X25519', 'X448'].includes(getNamedCurve(key));

function checkP2s(p2s) {
    if (!(p2s instanceof Uint8Array) || p2s.length < 8) {
        throw new JWEInvalid('PBES2 Salt Input must be 8 or more octets');
    }
}

const pbkdf2 = promisify(pbkdf2$1);
function getPassword(key, alg) {
    if (isKeyObject(key)) {
        return key.export();
    }
    if (key instanceof Uint8Array) {
        return key;
    }
    if (isCryptoKey(key)) {
        checkEncCryptoKey(key, alg, 'deriveBits', 'deriveKey');
        return KeyObject.from(key).export();
    }
    throw new TypeError(invalidKeyInput(key, ...types$1, 'Uint8Array'));
}
const encrypt$2 = async (alg, key, cek, p2c = 2048, p2s$1 = randomFillSync(new Uint8Array(16))) => {
    checkP2s(p2s$1);
    const salt = p2s(alg, p2s$1);
    const keylen = parseInt(alg.slice(13, 16), 10) >> 3;
    const password = getPassword(key, alg);
    const derivedKey = await pbkdf2(password, salt, p2c, keylen, `sha${alg.slice(8, 11)}`);
    const encryptedKey = await wrap$1(alg.slice(-6), derivedKey, cek);
    return { encryptedKey, p2c, p2s: encode(p2s$1) };
};
const decrypt$1 = async (alg, key, encryptedKey, p2c, p2s$1) => {
    checkP2s(p2s$1);
    const salt = p2s(alg, p2s$1);
    const keylen = parseInt(alg.slice(13, 16), 10) >> 3;
    const password = getPassword(key, alg);
    const derivedKey = await pbkdf2(password, salt, p2c, keylen, `sha${alg.slice(8, 11)}`);
    return unwrap$1(alg.slice(-6), derivedKey, encryptedKey);
};

const weakMap = new WeakMap();
const getLength = (buf, index) => {
    let len = buf.readUInt8(1);
    if ((len & 0x80) === 0) {
        if (index === 0) {
            return len;
        }
        return getLength(buf.subarray(2 + len), index - 1);
    }
    const num = len & 0x7f;
    len = 0;
    for (let i = 0; i < num; i++) {
        len <<= 8;
        const j = buf.readUInt8(2 + i);
        len |= j;
    }
    if (index === 0) {
        return len;
    }
    return getLength(buf.subarray(2 + len), index - 1);
};
const getLengthOfSeqIndex = (sequence, index) => {
    const len = sequence.readUInt8(1);
    if ((len & 0x80) === 0) {
        return getLength(sequence.subarray(2), index);
    }
    const num = len & 0x7f;
    return getLength(sequence.subarray(2 + num), index);
};
const getModulusLength = (key) => {
    var _a, _b;
    if (weakMap.has(key)) {
        return weakMap.get(key);
    }
    const modulusLength = (_b = (_a = key.asymmetricKeyDetails) === null || _a === void 0 ? void 0 : _a.modulusLength) !== null && _b !== void 0 ? _b : (getLengthOfSeqIndex(key.export({ format: 'der', type: 'pkcs1' }), key.type === 'private' ? 1 : 0) -
        1) <<
        3;
    weakMap.set(key, modulusLength);
    return modulusLength;
};
const setModulusLength = (keyObject, modulusLength) => {
    weakMap.set(keyObject, modulusLength);
};
const checkModulusLength = (key, alg) => {
    if (getModulusLength(key) < 2048) {
        throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
    }
};

const checkKey = (key, alg) => {
    if (key.asymmetricKeyType !== 'rsa') {
        throw new TypeError('Invalid key for this operation, its asymmetricKeyType must be rsa');
    }
    checkModulusLength(key, alg);
};
const resolvePadding = (alg) => {
    switch (alg) {
        case 'RSA-OAEP':
        case 'RSA-OAEP-256':
        case 'RSA-OAEP-384':
        case 'RSA-OAEP-512':
            return constants.RSA_PKCS1_OAEP_PADDING;
        case 'RSA1_5':
            return constants.RSA_PKCS1_PADDING;
        default:
            return undefined;
    }
};
const resolveOaepHash = (alg) => {
    switch (alg) {
        case 'RSA-OAEP':
            return 'sha1';
        case 'RSA-OAEP-256':
            return 'sha256';
        case 'RSA-OAEP-384':
            return 'sha384';
        case 'RSA-OAEP-512':
            return 'sha512';
        default:
            return undefined;
    }
};
function ensureKeyObject(key, alg, ...usages) {
    if (isKeyObject(key)) {
        return key;
    }
    if (isCryptoKey(key)) {
        checkEncCryptoKey(key, alg, ...usages);
        return KeyObject.from(key);
    }
    throw new TypeError(invalidKeyInput(key, ...types$1));
}
const encrypt$1 = (alg, key, cek) => {
    const padding = resolvePadding(alg);
    const oaepHash = resolveOaepHash(alg);
    const keyObject = ensureKeyObject(key, alg, 'wrapKey', 'encrypt');
    checkKey(keyObject, alg);
    return publicEncrypt({ key: keyObject, oaepHash, padding }, cek);
};
const decrypt = (alg, key, encryptedKey) => {
    const padding = resolvePadding(alg);
    const oaepHash = resolveOaepHash(alg);
    const keyObject = ensureKeyObject(key, alg, 'unwrapKey', 'decrypt');
    checkKey(keyObject, alg);
    return privateDecrypt({ key: keyObject, oaepHash, padding }, encryptedKey);
};

function bitLength(alg) {
    switch (alg) {
        case 'A128GCM':
            return 128;
        case 'A192GCM':
            return 192;
        case 'A256GCM':
        case 'A128CBC-HS256':
            return 256;
        case 'A192CBC-HS384':
            return 384;
        case 'A256CBC-HS512':
            return 512;
        default:
            throw new JOSENotSupported(`Unsupported JWE Algorithm: ${alg}`);
    }
}
const generateCek = (alg) => randomFillSync(new Uint8Array(bitLength(alg) >> 3));

const tagInteger$1 = 0x02;
const tagBitStr = 0x03;
const tagOctStr = 0x04;
const tagSequence$1 = 0x30;
const bZero = Buffer$1.from([0x00]);
const bTagInteger = Buffer$1.from([tagInteger$1]);
const bTagBitStr = Buffer$1.from([tagBitStr]);
const bTagSequence = Buffer$1.from([tagSequence$1]);
const bTagOctStr = Buffer$1.from([tagOctStr]);
const encodeLength = (len) => {
    if (len < 128)
        return Buffer$1.from([len]);
    const buffer = Buffer$1.alloc(5);
    buffer.writeUInt32BE(len, 1);
    let offset = 1;
    while (buffer[offset] === 0)
        offset++;
    buffer[offset - 1] = 0x80 | (5 - offset);
    return buffer.slice(offset - 1);
};
const oids = new Map([
    ['P-256', Buffer$1.from('06 08 2A 86 48 CE 3D 03 01 07'.replace(/ /g, ''), 'hex')],
    ['secp256k1', Buffer$1.from('06 05 2B 81 04 00 0A'.replace(/ /g, ''), 'hex')],
    ['P-384', Buffer$1.from('06 05 2B 81 04 00 22'.replace(/ /g, ''), 'hex')],
    ['P-521', Buffer$1.from('06 05 2B 81 04 00 23'.replace(/ /g, ''), 'hex')],
    ['ecPublicKey', Buffer$1.from('06 07 2A 86 48 CE 3D 02 01'.replace(/ /g, ''), 'hex')],
    ['X25519', Buffer$1.from('06 03 2B 65 6E'.replace(/ /g, ''), 'hex')],
    ['X448', Buffer$1.from('06 03 2B 65 6F'.replace(/ /g, ''), 'hex')],
    ['Ed25519', Buffer$1.from('06 03 2B 65 70'.replace(/ /g, ''), 'hex')],
    ['Ed448', Buffer$1.from('06 03 2B 65 71'.replace(/ /g, ''), 'hex')],
]);
class DumbAsn1Encoder {
    constructor() {
        this.length = 0;
        this.elements = [];
    }
    oidFor(oid) {
        const bOid = oids.get(oid);
        if (!bOid) {
            throw new JOSENotSupported('Invalid or unsupported OID');
        }
        this.elements.push(bOid);
        this.length += bOid.length;
    }
    zero() {
        this.elements.push(bTagInteger, Buffer$1.from([0x01]), bZero);
        this.length += 3;
    }
    one() {
        this.elements.push(bTagInteger, Buffer$1.from([0x01]), Buffer$1.from([0x01]));
        this.length += 3;
    }
    unsignedInteger(integer) {
        if (integer[0] & 0x80) {
            const len = encodeLength(integer.length + 1);
            this.elements.push(bTagInteger, len, bZero, integer);
            this.length += 2 + len.length + integer.length;
        }
        else {
            let i = 0;
            while (integer[i] === 0 && (integer[i + 1] & 0x80) === 0)
                i++;
            const len = encodeLength(integer.length - i);
            this.elements.push(bTagInteger, encodeLength(integer.length - i), integer.slice(i));
            this.length += 1 + len.length + integer.length - i;
        }
    }
    octStr(octStr) {
        const len = encodeLength(octStr.length);
        this.elements.push(bTagOctStr, encodeLength(octStr.length), octStr);
        this.length += 1 + len.length + octStr.length;
    }
    bitStr(bitS) {
        const len = encodeLength(bitS.length + 1);
        this.elements.push(bTagBitStr, encodeLength(bitS.length + 1), bZero, bitS);
        this.length += 1 + len.length + bitS.length + 1;
    }
    add(seq) {
        this.elements.push(seq);
        this.length += seq.length;
    }
    end(tag = bTagSequence) {
        const len = encodeLength(this.length);
        return Buffer$1.concat([tag, len, ...this.elements], 1 + len.length + this.length);
    }
}

const [major, minor] = process.versions.node.split('.').map((str) => parseInt(str, 10));
!('electron' in process.versions) && (major >= 17 || (major === 16 && minor >= 9));
const jwkExport = major >= 16 || (major === 15 && minor >= 9);
const jwkImport = major >= 16 || (major === 15 && minor >= 12);

const parse = (jwk) => {
    if (jwkImport && jwk.kty !== 'oct') {
        return jwk.d
            ? createPrivateKey({ format: 'jwk', key: jwk })
            : createPublicKey({ format: 'jwk', key: jwk });
    }
    switch (jwk.kty) {
        case 'oct': {
            return createSecretKey(decode(jwk.k));
        }
        case 'RSA': {
            const enc = new DumbAsn1Encoder();
            const isPrivate = jwk.d !== undefined;
            const modulus = Buffer$1.from(jwk.n, 'base64');
            const exponent = Buffer$1.from(jwk.e, 'base64');
            if (isPrivate) {
                enc.zero();
                enc.unsignedInteger(modulus);
                enc.unsignedInteger(exponent);
                enc.unsignedInteger(Buffer$1.from(jwk.d, 'base64'));
                enc.unsignedInteger(Buffer$1.from(jwk.p, 'base64'));
                enc.unsignedInteger(Buffer$1.from(jwk.q, 'base64'));
                enc.unsignedInteger(Buffer$1.from(jwk.dp, 'base64'));
                enc.unsignedInteger(Buffer$1.from(jwk.dq, 'base64'));
                enc.unsignedInteger(Buffer$1.from(jwk.qi, 'base64'));
            }
            else {
                enc.unsignedInteger(modulus);
                enc.unsignedInteger(exponent);
            }
            const der = enc.end();
            const createInput = {
                key: der,
                format: 'der',
                type: 'pkcs1',
            };
            const keyObject = isPrivate ? createPrivateKey(createInput) : createPublicKey(createInput);
            setModulusLength(keyObject, modulus.length << 3);
            return keyObject;
        }
        case 'EC': {
            const enc = new DumbAsn1Encoder();
            const isPrivate = jwk.d !== undefined;
            const pub = Buffer$1.concat([
                Buffer$1.alloc(1, 4),
                Buffer$1.from(jwk.x, 'base64'),
                Buffer$1.from(jwk.y, 'base64'),
            ]);
            if (isPrivate) {
                enc.zero();
                const enc$1 = new DumbAsn1Encoder();
                enc$1.oidFor('ecPublicKey');
                enc$1.oidFor(jwk.crv);
                enc.add(enc$1.end());
                const enc$2 = new DumbAsn1Encoder();
                enc$2.one();
                enc$2.octStr(Buffer$1.from(jwk.d, 'base64'));
                const enc$3 = new DumbAsn1Encoder();
                enc$3.bitStr(pub);
                const f2 = enc$3.end(Buffer$1.from([0xa1]));
                enc$2.add(f2);
                const f = enc$2.end();
                const enc$4 = new DumbAsn1Encoder();
                enc$4.add(f);
                const f3 = enc$4.end(Buffer$1.from([0x04]));
                enc.add(f3);
                const der = enc.end();
                const keyObject = createPrivateKey({ key: der, format: 'der', type: 'pkcs8' });
                setCurve(keyObject, jwk.crv);
                return keyObject;
            }
            const enc$1 = new DumbAsn1Encoder();
            enc$1.oidFor('ecPublicKey');
            enc$1.oidFor(jwk.crv);
            enc.add(enc$1.end());
            enc.bitStr(pub);
            const der = enc.end();
            const keyObject = createPublicKey({ key: der, format: 'der', type: 'spki' });
            setCurve(keyObject, jwk.crv);
            return keyObject;
        }
        case 'OKP': {
            const enc = new DumbAsn1Encoder();
            const isPrivate = jwk.d !== undefined;
            if (isPrivate) {
                enc.zero();
                const enc$1 = new DumbAsn1Encoder();
                enc$1.oidFor(jwk.crv);
                enc.add(enc$1.end());
                const enc$2 = new DumbAsn1Encoder();
                enc$2.octStr(Buffer$1.from(jwk.d, 'base64'));
                const f = enc$2.end(Buffer$1.from([0x04]));
                enc.add(f);
                const der = enc.end();
                return createPrivateKey({ key: der, format: 'der', type: 'pkcs8' });
            }
            const enc$1 = new DumbAsn1Encoder();
            enc$1.oidFor(jwk.crv);
            enc.add(enc$1.end());
            enc.bitStr(Buffer$1.from(jwk.x, 'base64'));
            const der = enc.end();
            return createPublicKey({ key: der, format: 'der', type: 'spki' });
        }
        default:
            throw new JOSENotSupported('Invalid or unsupported JWK "kty" (Key Type) Parameter value');
    }
};

async function importJWK(jwk, alg, octAsKeyObject) {
    var _a;
    if (!isObject(jwk)) {
        throw new TypeError('JWK must be an object');
    }
    alg || (alg = jwk.alg);
    switch (jwk.kty) {
        case 'oct':
            if (typeof jwk.k !== 'string' || !jwk.k) {
                throw new TypeError('missing "k" (Key Value) Parameter value');
            }
            octAsKeyObject !== null && octAsKeyObject !== void 0 ? octAsKeyObject : (octAsKeyObject = jwk.ext !== true);
            if (octAsKeyObject) {
                return parse({ ...jwk, alg, ext: (_a = jwk.ext) !== null && _a !== void 0 ? _a : false });
            }
            return decode(jwk.k);
        case 'RSA':
            if (jwk.oth !== undefined) {
                throw new JOSENotSupported('RSA JWK "oth" (Other Primes Info) Parameter value is not supported');
            }
        case 'EC':
        case 'OKP':
            return parse({ ...jwk, alg });
        default:
            throw new JOSENotSupported('Unsupported "kty" (Key Type) Parameter value');
    }
}

const symmetricTypeCheck = (alg, key) => {
    if (key instanceof Uint8Array)
        return;
    if (!isKeyLike(key)) {
        throw new TypeError(withAlg(alg, key, ...types$1, 'Uint8Array'));
    }
    if (key.type !== 'secret') {
        throw new TypeError(`${types$1.join(' or ')} instances for symmetric algorithms must be of type "secret"`);
    }
};
const asymmetricTypeCheck = (alg, key, usage) => {
    if (!isKeyLike(key)) {
        throw new TypeError(withAlg(alg, key, ...types$1));
    }
    if (key.type === 'secret') {
        throw new TypeError(`${types$1.join(' or ')} instances for asymmetric algorithms must not be of type "secret"`);
    }
    if (usage === 'sign' && key.type === 'public') {
        throw new TypeError(`${types$1.join(' or ')} instances for asymmetric algorithm signing must be of type "private"`);
    }
    if (usage === 'decrypt' && key.type === 'public') {
        throw new TypeError(`${types$1.join(' or ')} instances for asymmetric algorithm decryption must be of type "private"`);
    }
    if (key.algorithm && usage === 'verify' && key.type === 'private') {
        throw new TypeError(`${types$1.join(' or ')} instances for asymmetric algorithm verifying must be of type "public"`);
    }
    if (key.algorithm && usage === 'encrypt' && key.type === 'private') {
        throw new TypeError(`${types$1.join(' or ')} instances for asymmetric algorithm encryption must be of type "public"`);
    }
};
const checkKeyType = (alg, key, usage) => {
    const symmetric = alg.startsWith('HS') ||
        alg === 'dir' ||
        alg.startsWith('PBES2') ||
        /^A\d{3}(?:GCM)?KW$/.test(alg);
    if (symmetric) {
        symmetricTypeCheck(alg, key);
    }
    else {
        asymmetricTypeCheck(alg, key, usage);
    }
};

function cbcEncrypt(enc, plaintext, cek, iv, aad) {
    const keySize = parseInt(enc.slice(1, 4), 10);
    if (isKeyObject(cek)) {
        cek = cek.export();
    }
    const encKey = cek.subarray(keySize >> 3);
    const macKey = cek.subarray(0, keySize >> 3);
    const algorithm = `aes-${keySize}-cbc`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${enc} is not supported by your javascript runtime`);
    }
    const cipher = createCipheriv(algorithm, encKey, iv);
    const ciphertext = concat(cipher.update(plaintext), cipher.final());
    const macSize = parseInt(enc.slice(-3), 10);
    const tag = cbcTag(aad, iv, ciphertext, macSize, macKey, keySize);
    return { ciphertext, tag };
}
function gcmEncrypt(enc, plaintext, cek, iv, aad) {
    const keySize = parseInt(enc.slice(1, 4), 10);
    const algorithm = `aes-${keySize}-gcm`;
    if (!supported(algorithm)) {
        throw new JOSENotSupported(`alg ${enc} is not supported by your javascript runtime`);
    }
    const cipher = createCipheriv(algorithm, cek, iv, { authTagLength: 16 });
    if (aad.byteLength) {
        cipher.setAAD(aad, { plaintextLength: plaintext.length });
    }
    const ciphertext = cipher.update(plaintext);
    cipher.final();
    const tag = cipher.getAuthTag();
    return { ciphertext, tag };
}
const encrypt = (enc, plaintext, cek, iv, aad) => {
    let key;
    if (isCryptoKey(cek)) {
        checkEncCryptoKey(cek, enc, 'encrypt');
        key = KeyObject.from(cek);
    }
    else if (cek instanceof Uint8Array || isKeyObject(cek)) {
        key = cek;
    }
    else {
        throw new TypeError(invalidKeyInput(cek, ...types$1, 'Uint8Array'));
    }
    checkCekLength(enc, key);
    checkIvLength(enc, iv);
    switch (enc) {
        case 'A128CBC-HS256':
        case 'A192CBC-HS384':
        case 'A256CBC-HS512':
            return cbcEncrypt(enc, plaintext, key, iv, aad);
        case 'A128GCM':
        case 'A192GCM':
        case 'A256GCM':
            return gcmEncrypt(enc, plaintext, key, iv, aad);
        default:
            throw new JOSENotSupported('Unsupported JWE Content Encryption Algorithm');
    }
};

async function wrap(alg, key, cek, iv) {
    const jweAlgorithm = alg.slice(0, 7);
    iv || (iv = generateIv(jweAlgorithm));
    const { ciphertext: encryptedKey, tag } = await encrypt(jweAlgorithm, cek, key, iv, new Uint8Array(0));
    return { encryptedKey, iv: encode(iv), tag: encode(tag) };
}
async function unwrap(alg, key, encryptedKey, iv, tag) {
    const jweAlgorithm = alg.slice(0, 7);
    return decrypt$2(jweAlgorithm, key, encryptedKey, iv, tag, new Uint8Array(0));
}

async function decryptKeyManagement(alg, key, encryptedKey, joseHeader, options) {
    checkKeyType(alg, key, 'decrypt');
    switch (alg) {
        case 'dir': {
            if (encryptedKey !== undefined)
                throw new JWEInvalid('Encountered unexpected JWE Encrypted Key');
            return key;
        }
        case 'ECDH-ES':
            if (encryptedKey !== undefined)
                throw new JWEInvalid('Encountered unexpected JWE Encrypted Key');
        case 'ECDH-ES+A128KW':
        case 'ECDH-ES+A192KW':
        case 'ECDH-ES+A256KW': {
            if (!isObject(joseHeader.epk))
                throw new JWEInvalid(`JOSE Header "epk" (Ephemeral Public Key) missing or invalid`);
            if (!ecdhAllowed(key))
                throw new JOSENotSupported('ECDH with the provided key is not allowed or not supported by your javascript runtime');
            const epk = await importJWK(joseHeader.epk, alg);
            let partyUInfo;
            let partyVInfo;
            if (joseHeader.apu !== undefined) {
                if (typeof joseHeader.apu !== 'string')
                    throw new JWEInvalid(`JOSE Header "apu" (Agreement PartyUInfo) invalid`);
                try {
                    partyUInfo = decode(joseHeader.apu);
                }
                catch {
                    throw new JWEInvalid('Failed to base64url decode the apu');
                }
            }
            if (joseHeader.apv !== undefined) {
                if (typeof joseHeader.apv !== 'string')
                    throw new JWEInvalid(`JOSE Header "apv" (Agreement PartyVInfo) invalid`);
                try {
                    partyVInfo = decode(joseHeader.apv);
                }
                catch {
                    throw new JWEInvalid('Failed to base64url decode the apv');
                }
            }
            const sharedSecret = await deriveKey(epk, key, alg === 'ECDH-ES' ? joseHeader.enc : alg, alg === 'ECDH-ES' ? bitLength(joseHeader.enc) : parseInt(alg.slice(-5, -2), 10), partyUInfo, partyVInfo);
            if (alg === 'ECDH-ES')
                return sharedSecret;
            if (encryptedKey === undefined)
                throw new JWEInvalid('JWE Encrypted Key missing');
            return unwrap$1(alg.slice(-6), sharedSecret, encryptedKey);
        }
        case 'RSA1_5':
        case 'RSA-OAEP':
        case 'RSA-OAEP-256':
        case 'RSA-OAEP-384':
        case 'RSA-OAEP-512': {
            if (encryptedKey === undefined)
                throw new JWEInvalid('JWE Encrypted Key missing');
            return decrypt(alg, key, encryptedKey);
        }
        case 'PBES2-HS256+A128KW':
        case 'PBES2-HS384+A192KW':
        case 'PBES2-HS512+A256KW': {
            if (encryptedKey === undefined)
                throw new JWEInvalid('JWE Encrypted Key missing');
            if (typeof joseHeader.p2c !== 'number')
                throw new JWEInvalid(`JOSE Header "p2c" (PBES2 Count) missing or invalid`);
            const p2cLimit = (options === null || options === void 0 ? void 0 : options.maxPBES2Count) || 10000;
            if (joseHeader.p2c > p2cLimit)
                throw new JWEInvalid(`JOSE Header "p2c" (PBES2 Count) out is of acceptable bounds`);
            if (typeof joseHeader.p2s !== 'string')
                throw new JWEInvalid(`JOSE Header "p2s" (PBES2 Salt) missing or invalid`);
            let p2s;
            try {
                p2s = decode(joseHeader.p2s);
            }
            catch {
                throw new JWEInvalid('Failed to base64url decode the p2s');
            }
            return decrypt$1(alg, key, encryptedKey, joseHeader.p2c, p2s);
        }
        case 'A128KW':
        case 'A192KW':
        case 'A256KW': {
            if (encryptedKey === undefined)
                throw new JWEInvalid('JWE Encrypted Key missing');
            return unwrap$1(alg, key, encryptedKey);
        }
        case 'A128GCMKW':
        case 'A192GCMKW':
        case 'A256GCMKW': {
            if (encryptedKey === undefined)
                throw new JWEInvalid('JWE Encrypted Key missing');
            if (typeof joseHeader.iv !== 'string')
                throw new JWEInvalid(`JOSE Header "iv" (Initialization Vector) missing or invalid`);
            if (typeof joseHeader.tag !== 'string')
                throw new JWEInvalid(`JOSE Header "tag" (Authentication Tag) missing or invalid`);
            let iv;
            try {
                iv = decode(joseHeader.iv);
            }
            catch {
                throw new JWEInvalid('Failed to base64url decode the iv');
            }
            let tag;
            try {
                tag = decode(joseHeader.tag);
            }
            catch {
                throw new JWEInvalid('Failed to base64url decode the tag');
            }
            return unwrap(alg, key, encryptedKey, iv, tag);
        }
        default: {
            throw new JOSENotSupported('Invalid or unsupported "alg" (JWE Algorithm) header value');
        }
    }
}

function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
    if (joseHeader.crit !== undefined && protectedHeader.crit === undefined) {
        throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
    }
    if (!protectedHeader || protectedHeader.crit === undefined) {
        return new Set();
    }
    if (!Array.isArray(protectedHeader.crit) ||
        protectedHeader.crit.length === 0 ||
        protectedHeader.crit.some((input) => typeof input !== 'string' || input.length === 0)) {
        throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
    }
    let recognized;
    if (recognizedOption !== undefined) {
        recognized = new Map([...Object.entries(recognizedOption), ...recognizedDefault.entries()]);
    }
    else {
        recognized = recognizedDefault;
    }
    for (const parameter of protectedHeader.crit) {
        if (!recognized.has(parameter)) {
            throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
        }
        if (joseHeader[parameter] === undefined) {
            throw new Err(`Extension Header Parameter "${parameter}" is missing`);
        }
        else if (recognized.get(parameter) && protectedHeader[parameter] === undefined) {
            throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
        }
    }
    return new Set(protectedHeader.crit);
}

const validateAlgorithms = (option, algorithms) => {
    if (algorithms !== undefined &&
        (!Array.isArray(algorithms) || algorithms.some((s) => typeof s !== 'string'))) {
        throw new TypeError(`"${option}" option must be an array of strings`);
    }
    if (!algorithms) {
        return undefined;
    }
    return new Set(algorithms);
};

async function flattenedDecrypt(jwe, key, options) {
    var _a;
    if (!isObject(jwe)) {
        throw new JWEInvalid('Flattened JWE must be an object');
    }
    if (jwe.protected === undefined && jwe.header === undefined && jwe.unprotected === undefined) {
        throw new JWEInvalid('JOSE Header missing');
    }
    if (typeof jwe.iv !== 'string') {
        throw new JWEInvalid('JWE Initialization Vector missing or incorrect type');
    }
    if (typeof jwe.ciphertext !== 'string') {
        throw new JWEInvalid('JWE Ciphertext missing or incorrect type');
    }
    if (typeof jwe.tag !== 'string') {
        throw new JWEInvalid('JWE Authentication Tag missing or incorrect type');
    }
    if (jwe.protected !== undefined && typeof jwe.protected !== 'string') {
        throw new JWEInvalid('JWE Protected Header incorrect type');
    }
    if (jwe.encrypted_key !== undefined && typeof jwe.encrypted_key !== 'string') {
        throw new JWEInvalid('JWE Encrypted Key incorrect type');
    }
    if (jwe.aad !== undefined && typeof jwe.aad !== 'string') {
        throw new JWEInvalid('JWE AAD incorrect type');
    }
    if (jwe.header !== undefined && !isObject(jwe.header)) {
        throw new JWEInvalid('JWE Shared Unprotected Header incorrect type');
    }
    if (jwe.unprotected !== undefined && !isObject(jwe.unprotected)) {
        throw new JWEInvalid('JWE Per-Recipient Unprotected Header incorrect type');
    }
    let parsedProt;
    if (jwe.protected) {
        try {
            const protectedHeader = decode(jwe.protected);
            parsedProt = JSON.parse(decoder.decode(protectedHeader));
        }
        catch {
            throw new JWEInvalid('JWE Protected Header is invalid');
        }
    }
    if (!isDisjoint(parsedProt, jwe.header, jwe.unprotected)) {
        throw new JWEInvalid('JWE Protected, JWE Unprotected Header, and JWE Per-Recipient Unprotected Header Parameter names must be disjoint');
    }
    const joseHeader = {
        ...parsedProt,
        ...jwe.header,
        ...jwe.unprotected,
    };
    validateCrit(JWEInvalid, new Map(), options === null || options === void 0 ? void 0 : options.crit, parsedProt, joseHeader);
    if (joseHeader.zip !== undefined) {
        if (!parsedProt || !parsedProt.zip) {
            throw new JWEInvalid('JWE "zip" (Compression Algorithm) Header MUST be integrity protected');
        }
        if (joseHeader.zip !== 'DEF') {
            throw new JOSENotSupported('Unsupported JWE "zip" (Compression Algorithm) Header Parameter value');
        }
    }
    const { alg, enc } = joseHeader;
    if (typeof alg !== 'string' || !alg) {
        throw new JWEInvalid('missing JWE Algorithm (alg) in JWE Header');
    }
    if (typeof enc !== 'string' || !enc) {
        throw new JWEInvalid('missing JWE Encryption Algorithm (enc) in JWE Header');
    }
    const keyManagementAlgorithms = options && validateAlgorithms('keyManagementAlgorithms', options.keyManagementAlgorithms);
    const contentEncryptionAlgorithms = options &&
        validateAlgorithms('contentEncryptionAlgorithms', options.contentEncryptionAlgorithms);
    if (keyManagementAlgorithms && !keyManagementAlgorithms.has(alg)) {
        throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter not allowed');
    }
    if (contentEncryptionAlgorithms && !contentEncryptionAlgorithms.has(enc)) {
        throw new JOSEAlgNotAllowed('"enc" (Encryption Algorithm) Header Parameter not allowed');
    }
    let encryptedKey;
    if (jwe.encrypted_key !== undefined) {
        try {
            encryptedKey = decode(jwe.encrypted_key);
        }
        catch {
            throw new JWEInvalid('Failed to base64url decode the encrypted_key');
        }
    }
    let resolvedKey = false;
    if (typeof key === 'function') {
        key = await key(parsedProt, jwe);
        resolvedKey = true;
    }
    let cek;
    try {
        cek = await decryptKeyManagement(alg, key, encryptedKey, joseHeader, options);
    }
    catch (err) {
        if (err instanceof TypeError || err instanceof JWEInvalid || err instanceof JOSENotSupported) {
            throw err;
        }
        cek = generateCek(enc);
    }
    let iv;
    let tag;
    try {
        iv = decode(jwe.iv);
    }
    catch {
        throw new JWEInvalid('Failed to base64url decode the iv');
    }
    try {
        tag = decode(jwe.tag);
    }
    catch {
        throw new JWEInvalid('Failed to base64url decode the tag');
    }
    const protectedHeader = encoder.encode((_a = jwe.protected) !== null && _a !== void 0 ? _a : '');
    let additionalData;
    if (jwe.aad !== undefined) {
        additionalData = concat(protectedHeader, encoder.encode('.'), encoder.encode(jwe.aad));
    }
    else {
        additionalData = protectedHeader;
    }
    let ciphertext;
    try {
        ciphertext = decode(jwe.ciphertext);
    }
    catch {
        throw new JWEInvalid('Failed to base64url decode the ciphertext');
    }
    let plaintext = await decrypt$2(enc, cek, ciphertext, iv, tag, additionalData);
    if (joseHeader.zip === 'DEF') {
        plaintext = await ((options === null || options === void 0 ? void 0 : options.inflateRaw) || inflate)(plaintext);
    }
    const result = { plaintext };
    if (jwe.protected !== undefined) {
        result.protectedHeader = parsedProt;
    }
    if (jwe.aad !== undefined) {
        try {
            result.additionalAuthenticatedData = decode(jwe.aad);
        }
        catch {
            throw new JWEInvalid('Failed to base64url decode the aad');
        }
    }
    if (jwe.unprotected !== undefined) {
        result.sharedUnprotectedHeader = jwe.unprotected;
    }
    if (jwe.header !== undefined) {
        result.unprotectedHeader = jwe.header;
    }
    if (resolvedKey) {
        return { ...result, key };
    }
    return result;
}

async function compactDecrypt(jwe, key, options) {
    if (jwe instanceof Uint8Array) {
        jwe = decoder.decode(jwe);
    }
    if (typeof jwe !== 'string') {
        throw new JWEInvalid('Compact JWE must be a string or Uint8Array');
    }
    const { 0: protectedHeader, 1: encryptedKey, 2: iv, 3: ciphertext, 4: tag, length, } = jwe.split('.');
    if (length !== 5) {
        throw new JWEInvalid('Invalid Compact JWE');
    }
    const decrypted = await flattenedDecrypt({
        ciphertext,
        iv: (iv || undefined),
        protected: protectedHeader || undefined,
        tag: (tag || undefined),
        encrypted_key: encryptedKey || undefined,
    }, key, options);
    const result = { plaintext: decrypted.plaintext, protectedHeader: decrypted.protectedHeader };
    if (typeof key === 'function') {
        return { ...result, key: decrypted.key };
    }
    return result;
}

const tagInteger = 0x02;
const tagSequence = 0x30;
class Asn1SequenceDecoder {
    constructor(buffer) {
        if (buffer[0] !== tagSequence) {
            throw new TypeError();
        }
        this.buffer = buffer;
        this.offset = 1;
        const len = this.decodeLength();
        if (len !== buffer.length - this.offset) {
            throw new TypeError();
        }
    }
    decodeLength() {
        let length = this.buffer[this.offset++];
        if (length & 0x80) {
            const nBytes = length & -129;
            length = 0;
            for (let i = 0; i < nBytes; i++)
                length = (length << 8) | this.buffer[this.offset + i];
            this.offset += nBytes;
        }
        return length;
    }
    unsignedInteger() {
        if (this.buffer[this.offset++] !== tagInteger) {
            throw new TypeError();
        }
        let length = this.decodeLength();
        if (this.buffer[this.offset] === 0) {
            this.offset++;
            length--;
        }
        const result = this.buffer.slice(this.offset, this.offset + length);
        this.offset += length;
        return result;
    }
    end() {
        if (this.offset !== this.buffer.length) {
            throw new TypeError();
        }
    }
}

const keyToJWK = (key) => {
    let keyObject;
    if (isCryptoKey(key)) {
        if (!key.extractable) {
            throw new TypeError('CryptoKey is not extractable');
        }
        keyObject = KeyObject.from(key);
    }
    else if (isKeyObject(key)) {
        keyObject = key;
    }
    else if (key instanceof Uint8Array) {
        return {
            kty: 'oct',
            k: encode(key),
        };
    }
    else {
        throw new TypeError(invalidKeyInput(key, ...types$1, 'Uint8Array'));
    }
    if (jwkExport) {
        if (keyObject.type !== 'secret' &&
            !['rsa', 'ec', 'ed25519', 'x25519', 'ed448', 'x448'].includes(keyObject.asymmetricKeyType)) {
            throw new JOSENotSupported('Unsupported key asymmetricKeyType');
        }
        return keyObject.export({ format: 'jwk' });
    }
    switch (keyObject.type) {
        case 'secret':
            return {
                kty: 'oct',
                k: encode(keyObject.export()),
            };
        case 'private':
        case 'public': {
            switch (keyObject.asymmetricKeyType) {
                case 'rsa': {
                    const der = keyObject.export({ format: 'der', type: 'pkcs1' });
                    const dec = new Asn1SequenceDecoder(der);
                    if (keyObject.type === 'private') {
                        dec.unsignedInteger();
                    }
                    const n = encode(dec.unsignedInteger());
                    const e = encode(dec.unsignedInteger());
                    let jwk;
                    if (keyObject.type === 'private') {
                        jwk = {
                            d: encode(dec.unsignedInteger()),
                            p: encode(dec.unsignedInteger()),
                            q: encode(dec.unsignedInteger()),
                            dp: encode(dec.unsignedInteger()),
                            dq: encode(dec.unsignedInteger()),
                            qi: encode(dec.unsignedInteger()),
                        };
                    }
                    dec.end();
                    return { kty: 'RSA', n, e, ...jwk };
                }
                case 'ec': {
                    const crv = getNamedCurve(keyObject);
                    let len;
                    let offset;
                    let correction;
                    switch (crv) {
                        case 'secp256k1':
                            len = 64;
                            offset = 31 + 2;
                            correction = -1;
                            break;
                        case 'P-256':
                            len = 64;
                            offset = 34 + 2;
                            correction = -1;
                            break;
                        case 'P-384':
                            len = 96;
                            offset = 33 + 2;
                            correction = -3;
                            break;
                        case 'P-521':
                            len = 132;
                            offset = 33 + 2;
                            correction = -3;
                            break;
                        default:
                            throw new JOSENotSupported('Unsupported curve');
                    }
                    if (keyObject.type === 'public') {
                        const der = keyObject.export({ type: 'spki', format: 'der' });
                        return {
                            kty: 'EC',
                            crv,
                            x: encode(der.subarray(-len, -len / 2)),
                            y: encode(der.subarray(-len / 2)),
                        };
                    }
                    const der = keyObject.export({ type: 'pkcs8', format: 'der' });
                    if (der.length < 100) {
                        offset += correction;
                    }
                    return {
                        ...keyToJWK(createPublicKey(keyObject)),
                        d: encode(der.subarray(offset, offset + len / 2)),
                    };
                }
                case 'ed25519':
                case 'x25519': {
                    const crv = getNamedCurve(keyObject);
                    if (keyObject.type === 'public') {
                        const der = keyObject.export({ type: 'spki', format: 'der' });
                        return {
                            kty: 'OKP',
                            crv,
                            x: encode(der.subarray(-32)),
                        };
                    }
                    const der = keyObject.export({ type: 'pkcs8', format: 'der' });
                    return {
                        ...keyToJWK(createPublicKey(keyObject)),
                        d: encode(der.subarray(-32)),
                    };
                }
                case 'ed448':
                case 'x448': {
                    const crv = getNamedCurve(keyObject);
                    if (keyObject.type === 'public') {
                        const der = keyObject.export({ type: 'spki', format: 'der' });
                        return {
                            kty: 'OKP',
                            crv,
                            x: encode(der.subarray(crv === 'Ed448' ? -57 : -56)),
                        };
                    }
                    const der = keyObject.export({ type: 'pkcs8', format: 'der' });
                    return {
                        ...keyToJWK(createPublicKey(keyObject)),
                        d: encode(der.subarray(crv === 'Ed448' ? -57 : -56)),
                    };
                }
                default:
                    throw new JOSENotSupported('Unsupported key asymmetricKeyType');
            }
        }
        default:
            throw new JOSENotSupported('Unsupported key type');
    }
};

async function exportJWK(key) {
    return keyToJWK(key);
}

async function encryptKeyManagement(alg, enc, key, providedCek, providedParameters = {}) {
    let encryptedKey;
    let parameters;
    let cek;
    checkKeyType(alg, key, 'encrypt');
    switch (alg) {
        case 'dir': {
            cek = key;
            break;
        }
        case 'ECDH-ES':
        case 'ECDH-ES+A128KW':
        case 'ECDH-ES+A192KW':
        case 'ECDH-ES+A256KW': {
            if (!ecdhAllowed(key)) {
                throw new JOSENotSupported('ECDH with the provided key is not allowed or not supported by your javascript runtime');
            }
            const { apu, apv } = providedParameters;
            let { epk: ephemeralKey } = providedParameters;
            ephemeralKey || (ephemeralKey = (await generateEpk(key)).privateKey);
            const { x, y, crv, kty } = await exportJWK(ephemeralKey);
            const sharedSecret = await deriveKey(key, ephemeralKey, alg === 'ECDH-ES' ? enc : alg, alg === 'ECDH-ES' ? bitLength(enc) : parseInt(alg.slice(-5, -2), 10), apu, apv);
            parameters = { epk: { x, crv, kty } };
            if (kty === 'EC')
                parameters.epk.y = y;
            if (apu)
                parameters.apu = encode(apu);
            if (apv)
                parameters.apv = encode(apv);
            if (alg === 'ECDH-ES') {
                cek = sharedSecret;
                break;
            }
            cek = providedCek || generateCek(enc);
            const kwAlg = alg.slice(-6);
            encryptedKey = await wrap$1(kwAlg, sharedSecret, cek);
            break;
        }
        case 'RSA1_5':
        case 'RSA-OAEP':
        case 'RSA-OAEP-256':
        case 'RSA-OAEP-384':
        case 'RSA-OAEP-512': {
            cek = providedCek || generateCek(enc);
            encryptedKey = await encrypt$1(alg, key, cek);
            break;
        }
        case 'PBES2-HS256+A128KW':
        case 'PBES2-HS384+A192KW':
        case 'PBES2-HS512+A256KW': {
            cek = providedCek || generateCek(enc);
            const { p2c, p2s } = providedParameters;
            ({ encryptedKey, ...parameters } = await encrypt$2(alg, key, cek, p2c, p2s));
            break;
        }
        case 'A128KW':
        case 'A192KW':
        case 'A256KW': {
            cek = providedCek || generateCek(enc);
            encryptedKey = await wrap$1(alg, key, cek);
            break;
        }
        case 'A128GCMKW':
        case 'A192GCMKW':
        case 'A256GCMKW': {
            cek = providedCek || generateCek(enc);
            const { iv } = providedParameters;
            ({ encryptedKey, ...parameters } = await wrap(alg, key, cek, iv));
            break;
        }
        default: {
            throw new JOSENotSupported('Invalid or unsupported "alg" (JWE Algorithm) header value');
        }
    }
    return { cek, encryptedKey, parameters };
}

const unprotected = Symbol();
class FlattenedEncrypt {
    constructor(plaintext) {
        if (!(plaintext instanceof Uint8Array)) {
            throw new TypeError('plaintext must be an instance of Uint8Array');
        }
        this._plaintext = plaintext;
    }
    setKeyManagementParameters(parameters) {
        if (this._keyManagementParameters) {
            throw new TypeError('setKeyManagementParameters can only be called once');
        }
        this._keyManagementParameters = parameters;
        return this;
    }
    setProtectedHeader(protectedHeader) {
        if (this._protectedHeader) {
            throw new TypeError('setProtectedHeader can only be called once');
        }
        this._protectedHeader = protectedHeader;
        return this;
    }
    setSharedUnprotectedHeader(sharedUnprotectedHeader) {
        if (this._sharedUnprotectedHeader) {
            throw new TypeError('setSharedUnprotectedHeader can only be called once');
        }
        this._sharedUnprotectedHeader = sharedUnprotectedHeader;
        return this;
    }
    setUnprotectedHeader(unprotectedHeader) {
        if (this._unprotectedHeader) {
            throw new TypeError('setUnprotectedHeader can only be called once');
        }
        this._unprotectedHeader = unprotectedHeader;
        return this;
    }
    setAdditionalAuthenticatedData(aad) {
        this._aad = aad;
        return this;
    }
    setContentEncryptionKey(cek) {
        if (this._cek) {
            throw new TypeError('setContentEncryptionKey can only be called once');
        }
        this._cek = cek;
        return this;
    }
    setInitializationVector(iv) {
        if (this._iv) {
            throw new TypeError('setInitializationVector can only be called once');
        }
        this._iv = iv;
        return this;
    }
    async encrypt(key, options) {
        if (!this._protectedHeader && !this._unprotectedHeader && !this._sharedUnprotectedHeader) {
            throw new JWEInvalid('either setProtectedHeader, setUnprotectedHeader, or sharedUnprotectedHeader must be called before #encrypt()');
        }
        if (!isDisjoint(this._protectedHeader, this._unprotectedHeader, this._sharedUnprotectedHeader)) {
            throw new JWEInvalid('JWE Protected, JWE Shared Unprotected and JWE Per-Recipient Header Parameter names must be disjoint');
        }
        const joseHeader = {
            ...this._protectedHeader,
            ...this._unprotectedHeader,
            ...this._sharedUnprotectedHeader,
        };
        validateCrit(JWEInvalid, new Map(), options === null || options === void 0 ? void 0 : options.crit, this._protectedHeader, joseHeader);
        if (joseHeader.zip !== undefined) {
            if (!this._protectedHeader || !this._protectedHeader.zip) {
                throw new JWEInvalid('JWE "zip" (Compression Algorithm) Header MUST be integrity protected');
            }
            if (joseHeader.zip !== 'DEF') {
                throw new JOSENotSupported('Unsupported JWE "zip" (Compression Algorithm) Header Parameter value');
            }
        }
        const { alg, enc } = joseHeader;
        if (typeof alg !== 'string' || !alg) {
            throw new JWEInvalid('JWE "alg" (Algorithm) Header Parameter missing or invalid');
        }
        if (typeof enc !== 'string' || !enc) {
            throw new JWEInvalid('JWE "enc" (Encryption Algorithm) Header Parameter missing or invalid');
        }
        let encryptedKey;
        if (alg === 'dir') {
            if (this._cek) {
                throw new TypeError('setContentEncryptionKey cannot be called when using Direct Encryption');
            }
        }
        else if (alg === 'ECDH-ES') {
            if (this._cek) {
                throw new TypeError('setContentEncryptionKey cannot be called when using Direct Key Agreement');
            }
        }
        let cek;
        {
            let parameters;
            ({ cek, encryptedKey, parameters } = await encryptKeyManagement(alg, enc, key, this._cek, this._keyManagementParameters));
            if (parameters) {
                if (options && unprotected in options) {
                    if (!this._unprotectedHeader) {
                        this.setUnprotectedHeader(parameters);
                    }
                    else {
                        this._unprotectedHeader = { ...this._unprotectedHeader, ...parameters };
                    }
                }
                else {
                    if (!this._protectedHeader) {
                        this.setProtectedHeader(parameters);
                    }
                    else {
                        this._protectedHeader = { ...this._protectedHeader, ...parameters };
                    }
                }
            }
        }
        this._iv || (this._iv = generateIv(enc));
        let additionalData;
        let protectedHeader;
        let aadMember;
        if (this._protectedHeader) {
            protectedHeader = encoder.encode(encode(JSON.stringify(this._protectedHeader)));
        }
        else {
            protectedHeader = encoder.encode('');
        }
        if (this._aad) {
            aadMember = encode(this._aad);
            additionalData = concat(protectedHeader, encoder.encode('.'), encoder.encode(aadMember));
        }
        else {
            additionalData = protectedHeader;
        }
        let ciphertext;
        let tag;
        if (joseHeader.zip === 'DEF') {
            const deflated = await ((options === null || options === void 0 ? void 0 : options.deflateRaw) || deflate)(this._plaintext);
            ({ ciphertext, tag } = await encrypt(enc, deflated, cek, this._iv, additionalData));
        }
        else {
            ({ ciphertext, tag } = await encrypt(enc, this._plaintext, cek, this._iv, additionalData));
        }
        const jwe = {
            ciphertext: encode(ciphertext),
            iv: encode(this._iv),
            tag: encode(tag),
        };
        if (encryptedKey) {
            jwe.encrypted_key = encode(encryptedKey);
        }
        if (aadMember) {
            jwe.aad = aadMember;
        }
        if (this._protectedHeader) {
            jwe.protected = decoder.decode(protectedHeader);
        }
        if (this._sharedUnprotectedHeader) {
            jwe.unprotected = this._sharedUnprotectedHeader;
        }
        if (this._unprotectedHeader) {
            jwe.header = this._unprotectedHeader;
        }
        return jwe;
    }
}

const epoch = (date) => Math.floor(date.getTime() / 1000);

const minute = 60;
const hour = minute * 60;
const day = hour * 24;
const week = day * 7;
const year = day * 365.25;
const REGEX$1 = /^(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)$/i;
const secs = (str) => {
    const matched = REGEX$1.exec(str);
    if (!matched) {
        throw new TypeError('Invalid time period format');
    }
    const value = parseFloat(matched[1]);
    const unit = matched[2].toLowerCase();
    switch (unit) {
        case 'sec':
        case 'secs':
        case 'second':
        case 'seconds':
        case 's':
            return Math.round(value);
        case 'minute':
        case 'minutes':
        case 'min':
        case 'mins':
        case 'm':
            return Math.round(value * minute);
        case 'hour':
        case 'hours':
        case 'hr':
        case 'hrs':
        case 'h':
            return Math.round(value * hour);
        case 'day':
        case 'days':
        case 'd':
            return Math.round(value * day);
        case 'week':
        case 'weeks':
        case 'w':
            return Math.round(value * week);
        default:
            return Math.round(value * year);
    }
};

const normalizeTyp = (value) => value.toLowerCase().replace(/^application\//, '');
const checkAudiencePresence = (audPayload, audOption) => {
    if (typeof audPayload === 'string') {
        return audOption.includes(audPayload);
    }
    if (Array.isArray(audPayload)) {
        return audOption.some(Set.prototype.has.bind(new Set(audPayload)));
    }
    return false;
};
const jwtPayload = (protectedHeader, encodedPayload, options = {}) => {
    const { typ } = options;
    if (typ &&
        (typeof protectedHeader.typ !== 'string' ||
            normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ))) {
        throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', 'typ', 'check_failed');
    }
    let payload;
    try {
        payload = JSON.parse(decoder.decode(encodedPayload));
    }
    catch {
    }
    if (!isObject(payload)) {
        throw new JWTInvalid('JWT Claims Set must be a top-level JSON object');
    }
    const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options;
    if (maxTokenAge !== undefined)
        requiredClaims.push('iat');
    if (audience !== undefined)
        requiredClaims.push('aud');
    if (subject !== undefined)
        requiredClaims.push('sub');
    if (issuer !== undefined)
        requiredClaims.push('iss');
    for (const claim of new Set(requiredClaims.reverse())) {
        if (!(claim in payload)) {
            throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, claim, 'missing');
        }
    }
    if (issuer && !(Array.isArray(issuer) ? issuer : [issuer]).includes(payload.iss)) {
        throw new JWTClaimValidationFailed('unexpected "iss" claim value', 'iss', 'check_failed');
    }
    if (subject && payload.sub !== subject) {
        throw new JWTClaimValidationFailed('unexpected "sub" claim value', 'sub', 'check_failed');
    }
    if (audience &&
        !checkAudiencePresence(payload.aud, typeof audience === 'string' ? [audience] : audience)) {
        throw new JWTClaimValidationFailed('unexpected "aud" claim value', 'aud', 'check_failed');
    }
    let tolerance;
    switch (typeof options.clockTolerance) {
        case 'string':
            tolerance = secs(options.clockTolerance);
            break;
        case 'number':
            tolerance = options.clockTolerance;
            break;
        case 'undefined':
            tolerance = 0;
            break;
        default:
            throw new TypeError('Invalid clockTolerance option type');
    }
    const { currentDate } = options;
    const now = epoch(currentDate || new Date());
    if ((payload.iat !== undefined || maxTokenAge) && typeof payload.iat !== 'number') {
        throw new JWTClaimValidationFailed('"iat" claim must be a number', 'iat', 'invalid');
    }
    if (payload.nbf !== undefined) {
        if (typeof payload.nbf !== 'number') {
            throw new JWTClaimValidationFailed('"nbf" claim must be a number', 'nbf', 'invalid');
        }
        if (payload.nbf > now + tolerance) {
            throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', 'nbf', 'check_failed');
        }
    }
    if (payload.exp !== undefined) {
        if (typeof payload.exp !== 'number') {
            throw new JWTClaimValidationFailed('"exp" claim must be a number', 'exp', 'invalid');
        }
        if (payload.exp <= now - tolerance) {
            throw new JWTExpired('"exp" claim timestamp check failed', 'exp', 'check_failed');
        }
    }
    if (maxTokenAge) {
        const age = now - payload.iat;
        const max = typeof maxTokenAge === 'number' ? maxTokenAge : secs(maxTokenAge);
        if (age - tolerance > max) {
            throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', 'iat', 'check_failed');
        }
        if (age < 0 - tolerance) {
            throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', 'iat', 'check_failed');
        }
    }
    return payload;
};

async function jwtDecrypt(jwt, key, options) {
    const decrypted = await compactDecrypt(jwt, key, options);
    const payload = jwtPayload(decrypted.protectedHeader, decrypted.plaintext, options);
    const { protectedHeader } = decrypted;
    if (protectedHeader.iss !== undefined && protectedHeader.iss !== payload.iss) {
        throw new JWTClaimValidationFailed('replicated "iss" claim header parameter mismatch', 'iss', 'mismatch');
    }
    if (protectedHeader.sub !== undefined && protectedHeader.sub !== payload.sub) {
        throw new JWTClaimValidationFailed('replicated "sub" claim header parameter mismatch', 'sub', 'mismatch');
    }
    if (protectedHeader.aud !== undefined &&
        JSON.stringify(protectedHeader.aud) !== JSON.stringify(payload.aud)) {
        throw new JWTClaimValidationFailed('replicated "aud" claim header parameter mismatch', 'aud', 'mismatch');
    }
    const result = { payload, protectedHeader };
    if (typeof key === 'function') {
        return { ...result, key: decrypted.key };
    }
    return result;
}

class CompactEncrypt {
    constructor(plaintext) {
        this._flattened = new FlattenedEncrypt(plaintext);
    }
    setContentEncryptionKey(cek) {
        this._flattened.setContentEncryptionKey(cek);
        return this;
    }
    setInitializationVector(iv) {
        this._flattened.setInitializationVector(iv);
        return this;
    }
    setProtectedHeader(protectedHeader) {
        this._flattened.setProtectedHeader(protectedHeader);
        return this;
    }
    setKeyManagementParameters(parameters) {
        this._flattened.setKeyManagementParameters(parameters);
        return this;
    }
    async encrypt(key, options) {
        const jwe = await this._flattened.encrypt(key, options);
        return [jwe.protected, jwe.encrypted_key, jwe.iv, jwe.ciphertext, jwe.tag].join('.');
    }
}

class ProduceJWT {
    constructor(payload) {
        if (!isObject(payload)) {
            throw new TypeError('JWT Claims Set MUST be an object');
        }
        this._payload = payload;
    }
    setIssuer(issuer) {
        this._payload = { ...this._payload, iss: issuer };
        return this;
    }
    setSubject(subject) {
        this._payload = { ...this._payload, sub: subject };
        return this;
    }
    setAudience(audience) {
        this._payload = { ...this._payload, aud: audience };
        return this;
    }
    setJti(jwtId) {
        this._payload = { ...this._payload, jti: jwtId };
        return this;
    }
    setNotBefore(input) {
        if (typeof input === 'number') {
            this._payload = { ...this._payload, nbf: input };
        }
        else {
            this._payload = { ...this._payload, nbf: epoch(new Date()) + secs(input) };
        }
        return this;
    }
    setExpirationTime(input) {
        if (typeof input === 'number') {
            this._payload = { ...this._payload, exp: input };
        }
        else {
            this._payload = { ...this._payload, exp: epoch(new Date()) + secs(input) };
        }
        return this;
    }
    setIssuedAt(input) {
        if (typeof input === 'undefined') {
            this._payload = { ...this._payload, iat: epoch(new Date()) };
        }
        else {
            this._payload = { ...this._payload, iat: input };
        }
        return this;
    }
}

class EncryptJWT extends ProduceJWT {
    setProtectedHeader(protectedHeader) {
        if (this._protectedHeader) {
            throw new TypeError('setProtectedHeader can only be called once');
        }
        this._protectedHeader = protectedHeader;
        return this;
    }
    setKeyManagementParameters(parameters) {
        if (this._keyManagementParameters) {
            throw new TypeError('setKeyManagementParameters can only be called once');
        }
        this._keyManagementParameters = parameters;
        return this;
    }
    setContentEncryptionKey(cek) {
        if (this._cek) {
            throw new TypeError('setContentEncryptionKey can only be called once');
        }
        this._cek = cek;
        return this;
    }
    setInitializationVector(iv) {
        if (this._iv) {
            throw new TypeError('setInitializationVector can only be called once');
        }
        this._iv = iv;
        return this;
    }
    replicateIssuerAsHeader() {
        this._replicateIssuerAsHeader = true;
        return this;
    }
    replicateSubjectAsHeader() {
        this._replicateSubjectAsHeader = true;
        return this;
    }
    replicateAudienceAsHeader() {
        this._replicateAudienceAsHeader = true;
        return this;
    }
    async encrypt(key, options) {
        const enc = new CompactEncrypt(encoder.encode(JSON.stringify(this._payload)));
        if (this._replicateIssuerAsHeader) {
            this._protectedHeader = { ...this._protectedHeader, iss: this._payload.iss };
        }
        if (this._replicateSubjectAsHeader) {
            this._protectedHeader = { ...this._protectedHeader, sub: this._payload.sub };
        }
        if (this._replicateAudienceAsHeader) {
            this._protectedHeader = { ...this._protectedHeader, aud: this._payload.aud };
        }
        enc.setProtectedHeader(this._protectedHeader);
        if (this._iv) {
            enc.setInitializationVector(this._iv);
        }
        if (this._cek) {
            enc.setContentEncryptionKey(this._cek);
        }
        if (this._keyManagementParameters) {
            enc.setKeyManagementParameters(this._keyManagementParameters);
        }
        return enc.encrypt(key, options);
    }
}

const esm$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	CompactEncrypt: CompactEncrypt,
	EncryptJWT: EncryptJWT,
	FlattenedEncrypt: FlattenedEncrypt,
	compactDecrypt: compactDecrypt,
	exportJWK: exportJWK,
	flattenedDecrypt: flattenedDecrypt,
	importJWK: importJWK,
	jwtDecrypt: jwtDecrypt
}, Symbol.toStringTag, { value: 'Module' }));

const fallback = (digest, ikm, salt, info, keylen) => {
    const hashlen = parseInt(digest.substr(3), 10) >> 3 || 20;
    const prk = createHmac(digest, salt.byteLength ? salt : new Uint8Array(hashlen))
        .update(ikm)
        .digest();
    const N = Math.ceil(keylen / hashlen);
    const T = new Uint8Array(hashlen * N + info.byteLength + 1);
    let prev = 0;
    let start = 0;
    for (let c = 1; c <= N; c++) {
        T.set(info, start);
        T[start + info.byteLength] = c;
        T.set(createHmac(digest, prk)
            .update(T.subarray(prev, start + info.byteLength + 1))
            .digest(), start);
        prev = start;
        start += hashlen;
    }
    return T.slice(0, keylen);
};

let hkdf$1;
if (typeof crypto.hkdf === 'function' && !process.versions.electron) {
    hkdf$1 = async (...args) => new Promise((resolve, reject) => {
        crypto.hkdf(...args, (err, arrayBuffer) => {
            if (err)
                reject(err);
            else
                resolve(new Uint8Array(arrayBuffer));
        });
    });
}
const derive = async (digest, ikm, salt, info, keylen) => (hkdf$1 || fallback)(digest, ikm, salt, info, keylen);

function normalizeDigest(digest) {
    switch (digest) {
        case 'sha256':
        case 'sha384':
        case 'sha512':
        case 'sha1':
            return digest;
        default:
            throw new TypeError('unsupported "digest" value');
    }
}
function normalizeUint8Array(input, label) {
    if (typeof input === 'string')
        return new TextEncoder().encode(input);
    if (!(input instanceof Uint8Array))
        throw new TypeError(`"${label}"" must be an instance of Uint8Array or a string`);
    return input;
}
function normalizeIkm(input) {
    const ikm = normalizeUint8Array(input, 'ikm');
    if (!ikm.byteLength)
        throw new TypeError(`"ikm" must be at least one byte in length`);
    return ikm;
}
function normalizeInfo(input) {
    const info = normalizeUint8Array(input, 'info');
    if (info.byteLength > 1024) {
        throw TypeError('"info" must not contain more than 1024 bytes');
    }
    return info;
}
function normalizeKeylen(input, digest) {
    if (typeof input !== 'number' || !Number.isInteger(input) || input < 1) {
        throw new TypeError('"keylen" must be a positive integer');
    }
    const hashlen = parseInt(digest.substr(3), 10) >> 3 || 20;
    if (input > 255 * hashlen) {
        throw new TypeError('"keylen" too large');
    }
    return input;
}
async function hkdf(digest, ikm, salt, info, keylen) {
    return derive(normalizeDigest(digest), normalizeIkm(ikm), normalizeUint8Array(salt, 'salt'), normalizeInfo(info), normalizeKeylen(keylen, digest));
}

const esm = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: hkdf,
	hkdf: hkdf
}, Symbol.toStringTag, { value: 'Module' }));

const rnds8Pool = new Uint8Array(256); // # of random values to pre-allocate

let poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    crypto__default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }

  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

const REGEX = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;

function validate(uuid) {
  return typeof uuid === 'string' && REGEX.test(uuid);
}

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).substr(1));
}

function stringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  const uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase(); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!validate(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

function v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random || (options.rng || rng)(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  return stringify(rnds);
}

const esmNode = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	stringify: stringify,
	v4: v4,
	validate: validate
}, Symbol.toStringTag, { value: 'Module' }));

var cookie = {};

var classPrivateFieldGet = {exports: {}};

var classApplyDescriptorGet = {exports: {}};

var hasRequiredClassApplyDescriptorGet;

function requireClassApplyDescriptorGet () {
	if (hasRequiredClassApplyDescriptorGet) return classApplyDescriptorGet.exports;
	hasRequiredClassApplyDescriptorGet = 1;
	(function (module) {
		function _classApplyDescriptorGet(e, t) {
		  return t.get ? t.get.call(e) : t.value;
		}
		module.exports = _classApplyDescriptorGet, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classApplyDescriptorGet));
	return classApplyDescriptorGet.exports;
}

var classPrivateFieldGet2 = {exports: {}};

var assertClassBrand = {exports: {}};

var hasRequiredAssertClassBrand;

function requireAssertClassBrand () {
	if (hasRequiredAssertClassBrand) return assertClassBrand.exports;
	hasRequiredAssertClassBrand = 1;
	(function (module) {
		function _assertClassBrand(e, t, n) {
		  if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
		  throw new TypeError("Private element is not present on this object");
		}
		module.exports = _assertClassBrand, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (assertClassBrand));
	return assertClassBrand.exports;
}

var hasRequiredClassPrivateFieldGet2;

function requireClassPrivateFieldGet2 () {
	if (hasRequiredClassPrivateFieldGet2) return classPrivateFieldGet2.exports;
	hasRequiredClassPrivateFieldGet2 = 1;
	(function (module) {
		var assertClassBrand = /*@__PURE__*/ requireAssertClassBrand();
		function _classPrivateFieldGet2(s, a) {
		  return s.get(assertClassBrand(s, a));
		}
		module.exports = _classPrivateFieldGet2, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classPrivateFieldGet2));
	return classPrivateFieldGet2.exports;
}

var hasRequiredClassPrivateFieldGet;

function requireClassPrivateFieldGet () {
	if (hasRequiredClassPrivateFieldGet) return classPrivateFieldGet.exports;
	hasRequiredClassPrivateFieldGet = 1;
	(function (module) {
		var classApplyDescriptorGet = /*@__PURE__*/ requireClassApplyDescriptorGet();
		var classPrivateFieldGet2 = /*@__PURE__*/ requireClassPrivateFieldGet2();
		function _classPrivateFieldGet(e, t) {
		  var r = classPrivateFieldGet2(t, e);
		  return classApplyDescriptorGet(e, r);
		}
		module.exports = _classPrivateFieldGet, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classPrivateFieldGet));
	return classPrivateFieldGet.exports;
}

var classPrivateFieldSet = {exports: {}};

var classApplyDescriptorSet = {exports: {}};

var hasRequiredClassApplyDescriptorSet;

function requireClassApplyDescriptorSet () {
	if (hasRequiredClassApplyDescriptorSet) return classApplyDescriptorSet.exports;
	hasRequiredClassApplyDescriptorSet = 1;
	(function (module) {
		function _classApplyDescriptorSet(e, t, l) {
		  if (t.set) t.set.call(e, l);else {
		    if (!t.writable) throw new TypeError("attempted to set read only private field");
		    t.value = l;
		  }
		}
		module.exports = _classApplyDescriptorSet, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classApplyDescriptorSet));
	return classApplyDescriptorSet.exports;
}

var hasRequiredClassPrivateFieldSet;

function requireClassPrivateFieldSet () {
	if (hasRequiredClassPrivateFieldSet) return classPrivateFieldSet.exports;
	hasRequiredClassPrivateFieldSet = 1;
	(function (module) {
		var classApplyDescriptorSet = /*@__PURE__*/ requireClassApplyDescriptorSet();
		var classPrivateFieldGet2 = /*@__PURE__*/ requireClassPrivateFieldGet2();
		function _classPrivateFieldSet(e, t, r) {
		  var s = classPrivateFieldGet2(t, e);
		  return classApplyDescriptorSet(e, s, r), r;
		}
		module.exports = _classPrivateFieldSet, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (classPrivateFieldSet));
	return classPrivateFieldSet.exports;
}

var hasRequiredCookie;

function requireCookie () {
	if (hasRequiredCookie) return cookie;
	hasRequiredCookie = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(cookie, "__esModule", {
	  value: true
	});
	cookie.SessionStore = void 0;
	cookie.defaultCookies = defaultCookies;

	var _classPrivateFieldGet3 = _interopRequireDefault(/*@__PURE__*/ requireClassPrivateFieldGet());

	var _classPrivateFieldSet2 = _interopRequireDefault(/*@__PURE__*/ requireClassPrivateFieldSet());

	function _classPrivateMethodInitSpec(obj, privateSet) { _checkPrivateRedeclaration(obj, privateSet); privateSet.add(obj); }

	function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }

	function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }

	function _classPrivateMethodGet(receiver, privateSet, fn) { if (!privateSet.has(receiver)) { throw new TypeError("attempted to get private field on non-instance"); } return fn; }

	const ALLOWED_COOKIE_SIZE = 4096;
	const ESTIMATED_EMPTY_COOKIE_SIZE = 163;
	const CHUNK_SIZE = ALLOWED_COOKIE_SIZE - ESTIMATED_EMPTY_COOKIE_SIZE;

	function defaultCookies(useSecureCookies) {
	  const cookiePrefix = useSecureCookies ? "__Secure-" : "";
	  return {
	    sessionToken: {
	      name: `${cookiePrefix}next-auth.session-token`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies
	      }
	    },
	    callbackUrl: {
	      name: `${cookiePrefix}next-auth.callback-url`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies
	      }
	    },
	    csrfToken: {
	      name: `${useSecureCookies ? "__Host-" : ""}next-auth.csrf-token`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies
	      }
	    },
	    pkceCodeVerifier: {
	      name: `${cookiePrefix}next-auth.pkce.code_verifier`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies,
	        maxAge: 60 * 15
	      }
	    },
	    state: {
	      name: `${cookiePrefix}next-auth.state`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies,
	        maxAge: 60 * 15
	      }
	    },
	    nonce: {
	      name: `${cookiePrefix}next-auth.nonce`,
	      options: {
	        httpOnly: true,
	        sameSite: "lax",
	        path: "/",
	        secure: useSecureCookies
	      }
	    }
	  };
	}

	var _chunks = new WeakMap();

	var _option = new WeakMap();

	var _logger = new WeakMap();

	var _chunk = new WeakSet();

	var _clean = new WeakSet();

	class SessionStore {
	  constructor(option, req, logger) {
	    _classPrivateMethodInitSpec(this, _clean);

	    _classPrivateMethodInitSpec(this, _chunk);

	    _classPrivateFieldInitSpec(this, _chunks, {
	      writable: true,
	      value: {}
	    });

	    _classPrivateFieldInitSpec(this, _option, {
	      writable: true,
	      value: void 0
	    });

	    _classPrivateFieldInitSpec(this, _logger, {
	      writable: true,
	      value: void 0
	    });

	    (0, _classPrivateFieldSet2.default)(this, _logger, logger);
	    (0, _classPrivateFieldSet2.default)(this, _option, option);
	    const {
	      cookies: _cookies
	    } = req;
	    const {
	      name: cookieName
	    } = option;

	    if (typeof (_cookies === null || _cookies === void 0 ? void 0 : _cookies.getAll) === "function") {
	      for (const {
	        name,
	        value
	      } of _cookies.getAll()) {
	        if (name.startsWith(cookieName)) {
	          (0, _classPrivateFieldGet3.default)(this, _chunks)[name] = value;
	        }
	      }
	    } else if (_cookies instanceof Map) {
	      for (const name of _cookies.keys()) {
	        if (name.startsWith(cookieName)) (0, _classPrivateFieldGet3.default)(this, _chunks)[name] = _cookies.get(name);
	      }
	    } else {
	      for (const name in _cookies) {
	        if (name.startsWith(cookieName)) (0, _classPrivateFieldGet3.default)(this, _chunks)[name] = _cookies[name];
	      }
	    }
	  }

	  get value() {
	    var _Object$values;

	    return (_Object$values = Object.values((0, _classPrivateFieldGet3.default)(this, _chunks))) === null || _Object$values === void 0 ? void 0 : _Object$values.join("");
	  }

	  chunk(value, options) {
	    const cookies = _classPrivateMethodGet(this, _clean, _clean2).call(this);

	    const chunked = _classPrivateMethodGet(this, _chunk, _chunk2).call(this, {
	      name: (0, _classPrivateFieldGet3.default)(this, _option).name,
	      value,
	      options: { ...(0, _classPrivateFieldGet3.default)(this, _option).options,
	        ...options
	      }
	    });

	    for (const chunk of chunked) {
	      cookies[chunk.name] = chunk;
	    }

	    return Object.values(cookies);
	  }

	  clean() {
	    return Object.values(_classPrivateMethodGet(this, _clean, _clean2).call(this));
	  }

	}

	cookie.SessionStore = SessionStore;

	function _chunk2(cookie) {
	  const chunkCount = Math.ceil(cookie.value.length / CHUNK_SIZE);

	  if (chunkCount === 1) {
	    (0, _classPrivateFieldGet3.default)(this, _chunks)[cookie.name] = cookie.value;
	    return [cookie];
	  }

	  const cookies = [];

	  for (let i = 0; i < chunkCount; i++) {
	    const name = `${cookie.name}.${i}`;
	    const value = cookie.value.substr(i * CHUNK_SIZE, CHUNK_SIZE);
	    cookies.push({ ...cookie,
	      name,
	      value
	    });
	    (0, _classPrivateFieldGet3.default)(this, _chunks)[name] = value;
	  }

	  (0, _classPrivateFieldGet3.default)(this, _logger).debug("CHUNKING_SESSION_COOKIE", {
	    message: `Session cookie exceeds allowed ${ALLOWED_COOKIE_SIZE} bytes.`,
	    emptyCookieSize: ESTIMATED_EMPTY_COOKIE_SIZE,
	    valueSize: cookie.value.length,
	    chunks: cookies.map(c => c.value.length + ESTIMATED_EMPTY_COOKIE_SIZE)
	  });
	  return cookies;
	}

	function _clean2() {
	  const cleanedChunks = {};

	  for (const name in (0, _classPrivateFieldGet3.default)(this, _chunks)) {
	    var _classPrivateFieldGet2;

	    (_classPrivateFieldGet2 = (0, _classPrivateFieldGet3.default)(this, _chunks)) === null || _classPrivateFieldGet2 === void 0 ? true : delete _classPrivateFieldGet2[name];
	    cleanedChunks[name] = {
	      name,
	      value: "",
	      options: { ...(0, _classPrivateFieldGet3.default)(this, _option).options,
	        maxAge: 0
	      }
	    };
	  }

	  return cleanedChunks;
	}
	return cookie;
}

var types = {};

var hasRequiredTypes;

function requireTypes () {
	if (hasRequiredTypes) return types;
	hasRequiredTypes = 1;

	Object.defineProperty(types, "__esModule", {
	  value: true
	});
	return types;
}

(function (exports) {

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var _exportNames = {
	  encode: true,
	  decode: true,
	  getToken: true
	};
	exports.decode = decode;
	exports.encode = encode;
	exports.getToken = getToken;

	var _jose = esm$1;

	var _hkdf = _interopRequireDefault(esm);

	var _uuid = esmNode;

	var _cookie = /*@__PURE__*/ requireCookie();

	var _types = /*@__PURE__*/ requireTypes();

	Object.keys(_types).forEach(function (key) {
	  if (key === "default" || key === "__esModule") return;
	  if (Object.prototype.hasOwnProperty.call(_exportNames, key)) return;
	  if (key in exports && exports[key] === _types[key]) return;
	  Object.defineProperty(exports, key, {
	    enumerable: true,
	    get: function () {
	      return _types[key];
	    }
	  });
	});
	const DEFAULT_MAX_AGE = 30 * 24 * 60 * 60;

	const now = () => Date.now() / 1000 | 0;

	async function encode(params) {
	  const {
	    token = {},
	    secret,
	    maxAge = DEFAULT_MAX_AGE
	  } = params;
	  const encryptionSecret = await getDerivedEncryptionKey(secret);
	  return await new _jose.EncryptJWT(token).setProtectedHeader({
	    alg: "dir",
	    enc: "A256GCM"
	  }).setIssuedAt().setExpirationTime(now() + maxAge).setJti((0, _uuid.v4)()).encrypt(encryptionSecret);
	}

	async function decode(params) {
	  const {
	    token,
	    secret
	  } = params;
	  if (!token) return null;
	  const encryptionSecret = await getDerivedEncryptionKey(secret);
	  const {
	    payload
	  } = await (0, _jose.jwtDecrypt)(token, encryptionSecret, {
	    clockTolerance: 15
	  });
	  return payload;
	}

	async function getToken(params) {
	  var _process$env$NEXTAUTH, _process$env$NEXTAUTH2, _req$headers;

	  const {
	    req,
	    secureCookie = (_process$env$NEXTAUTH = (_process$env$NEXTAUTH2 = process.env.NEXTAUTH_URL) === null || _process$env$NEXTAUTH2 === void 0 ? void 0 : _process$env$NEXTAUTH2.startsWith("https://")) !== null && _process$env$NEXTAUTH !== void 0 ? _process$env$NEXTAUTH : !!process.env.VERCEL,
	    cookieName = secureCookie ? "__Secure-next-auth.session-token" : "next-auth.session-token",
	    raw,
	    decode: _decode = decode,
	    logger = console,
	    secret = process.env.NEXTAUTH_SECRET
	  } = params;
	  if (!req) throw new Error("Must pass `req` to JWT getToken()");
	  const sessionStore = new _cookie.SessionStore({
	    name: cookieName,
	    options: {
	      secure: secureCookie
	    }
	  }, {
	    cookies: req.cookies,
	    headers: req.headers
	  }, logger);
	  let token = sessionStore.value;
	  const authorizationHeader = req.headers instanceof Headers ? req.headers.get("authorization") : (_req$headers = req.headers) === null || _req$headers === void 0 ? void 0 : _req$headers.authorization;

	  if (!token && (authorizationHeader === null || authorizationHeader === void 0 ? void 0 : authorizationHeader.split(" ")[0]) === "Bearer") {
	    const urlEncodedToken = authorizationHeader.split(" ")[1];
	    token = decodeURIComponent(urlEncodedToken);
	  }

	  if (!token) return null;
	  if (raw) return token;

	  try {
	    return await _decode({
	      token,
	      secret
	    });
	  } catch (_unused) {
	    return null;
	  }
	}

	async function getDerivedEncryptionKey(secret) {
	  return await (0, _hkdf.default)("sha256", secret, "", "NextAuth.js Generated Encryption Key", 32);
	} 
} (jwt));

var hasRequiredChecks;

function requireChecks () {
	if (hasRequiredChecks) return checks;
	hasRequiredChecks = 1;

	Object.defineProperty(checks, "__esModule", {
	  value: true
	});
	checks.pkce = checks.nonce = checks.PKCE_CODE_CHALLENGE_METHOD = void 0;
	checks.signCookie = signCookie;
	checks.state = void 0;

	var _openidClient = require$$0$2;

	var jwt$1 = _interopRequireWildcard(jwt);

	function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

	function _interopRequireWildcard(obj, nodeInterop) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

	async function signCookie(type, value, maxAge, options) {
	  const {
	    cookies,
	    logger
	  } = options;
	  logger.debug(`CREATE_${type.toUpperCase()}`, {
	    value,
	    maxAge
	  });
	  const expires = new Date();
	  expires.setTime(expires.getTime() + maxAge * 1000);
	  return {
	    name: cookies[type].name,
	    value: await jwt$1.encode({ ...options.jwt,
	      maxAge,
	      token: {
	        value
	      }
	    }),
	    options: { ...cookies[type].options,
	      expires
	    }
	  };
	}

	const PKCE_MAX_AGE = 60 * 15;
	const PKCE_CODE_CHALLENGE_METHOD = "S256";
	checks.PKCE_CODE_CHALLENGE_METHOD = PKCE_CODE_CHALLENGE_METHOD;
	const pkce = {
	  async create(options, cookies, resParams) {
	    var _options$provider, _options$provider$che, _options$cookies$pkce;

	    if (!((_options$provider = options.provider) !== null && _options$provider !== void 0 && (_options$provider$che = _options$provider.checks) !== null && _options$provider$che !== void 0 && _options$provider$che.includes("pkce"))) return;

	    const code_verifier = _openidClient.generators.codeVerifier();

	    const value = _openidClient.generators.codeChallenge(code_verifier);

	    resParams.code_challenge = value;
	    resParams.code_challenge_method = PKCE_CODE_CHALLENGE_METHOD;
	    const maxAge = (_options$cookies$pkce = options.cookies.pkceCodeVerifier.options.maxAge) !== null && _options$cookies$pkce !== void 0 ? _options$cookies$pkce : PKCE_MAX_AGE;
	    cookies.push(await signCookie("pkceCodeVerifier", code_verifier, maxAge, options));
	  },

	  async use(cookies, resCookies, options, checks) {
	    var _options$provider2, _options$provider2$ch;

	    if (!((_options$provider2 = options.provider) !== null && _options$provider2 !== void 0 && (_options$provider2$ch = _options$provider2.checks) !== null && _options$provider2$ch !== void 0 && _options$provider2$ch.includes("pkce"))) return;
	    const codeVerifier = cookies === null || cookies === void 0 ? void 0 : cookies[options.cookies.pkceCodeVerifier.name];
	    if (!codeVerifier) throw new TypeError("PKCE code_verifier cookie was missing.");
	    const value = await jwt$1.decode({ ...options.jwt,
	      token: codeVerifier
	    });
	    if (!(value !== null && value !== void 0 && value.value)) throw new TypeError("PKCE code_verifier value could not be parsed.");
	    resCookies.push({
	      name: options.cookies.pkceCodeVerifier.name,
	      value: "",
	      options: { ...options.cookies.pkceCodeVerifier.options,
	        maxAge: 0
	      }
	    });
	    checks.code_verifier = value.value;
	  }

	};
	checks.pkce = pkce;
	const STATE_MAX_AGE = 60 * 15;
	const state = {
	  async create(options, cookies, resParams) {
	    var _options$provider$che2, _options$cookies$stat;

	    if (!((_options$provider$che2 = options.provider.checks) !== null && _options$provider$che2 !== void 0 && _options$provider$che2.includes("state"))) return;

	    const value = _openidClient.generators.state();

	    resParams.state = value;
	    const maxAge = (_options$cookies$stat = options.cookies.state.options.maxAge) !== null && _options$cookies$stat !== void 0 ? _options$cookies$stat : STATE_MAX_AGE;
	    cookies.push(await signCookie("state", value, maxAge, options));
	  },

	  async use(cookies, resCookies, options, checks) {
	    var _options$provider$che3;

	    if (!((_options$provider$che3 = options.provider.checks) !== null && _options$provider$che3 !== void 0 && _options$provider$che3.includes("state"))) return;
	    const state = cookies === null || cookies === void 0 ? void 0 : cookies[options.cookies.state.name];
	    if (!state) throw new TypeError("State cookie was missing.");
	    const value = await jwt$1.decode({ ...options.jwt,
	      token: state
	    });
	    if (!(value !== null && value !== void 0 && value.value)) throw new TypeError("State value could not be parsed.");
	    resCookies.push({
	      name: options.cookies.state.name,
	      value: "",
	      options: { ...options.cookies.state.options,
	        maxAge: 0
	      }
	    });
	    checks.state = value.value;
	  }

	};
	checks.state = state;
	const NONCE_MAX_AGE = 60 * 15;
	const nonce = {
	  async create(options, cookies, resParams) {
	    var _options$provider$che4, _options$cookies$nonc;

	    if (!((_options$provider$che4 = options.provider.checks) !== null && _options$provider$che4 !== void 0 && _options$provider$che4.includes("nonce"))) return;

	    const value = _openidClient.generators.nonce();

	    resParams.nonce = value;
	    const maxAge = (_options$cookies$nonc = options.cookies.nonce.options.maxAge) !== null && _options$cookies$nonc !== void 0 ? _options$cookies$nonc : NONCE_MAX_AGE;
	    cookies.push(await signCookie("nonce", value, maxAge, options));
	  },

	  async use(cookies, resCookies, options, checks) {
	    var _options$provider3, _options$provider3$ch;

	    if (!((_options$provider3 = options.provider) !== null && _options$provider3 !== void 0 && (_options$provider3$ch = _options$provider3.checks) !== null && _options$provider3$ch !== void 0 && _options$provider3$ch.includes("nonce"))) return;
	    const nonce = cookies === null || cookies === void 0 ? void 0 : cookies[options.cookies.nonce.name];
	    if (!nonce) throw new TypeError("Nonce cookie was missing.");
	    const value = await jwt$1.decode({ ...options.jwt,
	      token: nonce
	    });
	    if (!(value !== null && value !== void 0 && value.value)) throw new TypeError("Nonce value could not be parsed.");
	    resCookies.push({
	      name: options.cookies.nonce.name,
	      value: "",
	      options: { ...options.cookies.nonce.options,
	        maxAge: 0
	      }
	    });
	    checks.nonce = value.value;
	  }

	};
	checks.nonce = nonce;
	return checks;
}

var hasRequiredCallback$1;

function requireCallback$1 () {
	if (hasRequiredCallback$1) return callback;
	hasRequiredCallback$1 = 1;

	Object.defineProperty(callback, "__esModule", {
	  value: true
	});
	callback.default = oAuthCallback;

	var _openidClient = require$$0$2;

	var _client = /*@__PURE__*/ requireClient();

	var _clientLegacy = /*@__PURE__*/ requireClientLegacy();

	var _checks = _interopRequireWildcard(/*@__PURE__*/ requireChecks());

	var _errors = /*@__PURE__*/ requireErrors();

	function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

	function _interopRequireWildcard(obj, nodeInterop) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

	async function oAuthCallback(params) {
	  var _body$error, _provider$version;

	  const {
	    options,
	    query,
	    body,
	    method,
	    cookies
	  } = params;
	  const {
	    logger,
	    provider
	  } = options;
	  const errorMessage = (_body$error = body === null || body === void 0 ? void 0 : body.error) !== null && _body$error !== void 0 ? _body$error : query === null || query === void 0 ? void 0 : query.error;

	  if (errorMessage) {
	    const error = new Error(errorMessage);
	    logger.error("OAUTH_CALLBACK_HANDLER_ERROR", {
	      error,
	      error_description: query === null || query === void 0 ? void 0 : query.error_description,
	      providerId: provider.id
	    });
	    logger.debug("OAUTH_CALLBACK_HANDLER_ERROR", {
	      body
	    });
	    throw error;
	  }

	  if ((_provider$version = provider.version) !== null && _provider$version !== void 0 && _provider$version.startsWith("1.")) {
	    try {
	      const client = await (0, _clientLegacy.oAuth1Client)(options);
	      const {
	        oauth_token,
	        oauth_verifier
	      } = query !== null && query !== void 0 ? query : {};
	      const tokens = await client.getOAuthAccessToken(oauth_token, _clientLegacy.oAuth1TokenStore.get(oauth_token), oauth_verifier);
	      let profile = await client.get(provider.profileUrl, tokens.oauth_token, tokens.oauth_token_secret);

	      if (typeof profile === "string") {
	        profile = JSON.parse(profile);
	      }

	      const newProfile = await getProfile({
	        profile,
	        tokens,
	        provider,
	        logger
	      });
	      return { ...newProfile,
	        cookies: []
	      };
	    } catch (error) {
	      logger.error("OAUTH_V1_GET_ACCESS_TOKEN_ERROR", error);
	      throw error;
	    }
	  }

	  if (query !== null && query !== void 0 && query.oauth_token) _clientLegacy.oAuth1TokenStore.delete(query.oauth_token);

	  try {
	    var _provider$token, _provider$token2, _provider$userinfo;

	    const client = await (0, _client.openidClient)(options);
	    let tokens;
	    const checks = {};
	    const resCookies = [];
	    await _checks.state.use(cookies, resCookies, options, checks);
	    await _checks.pkce.use(cookies, resCookies, options, checks);
	    await _checks.nonce.use(cookies, resCookies, options, checks);
	    const params = { ...client.callbackParams({
	        url: `http://n?${new URLSearchParams(query)}`,
	        body,
	        method
	      }),
	      ...((_provider$token = provider.token) === null || _provider$token === void 0 ? void 0 : _provider$token.params)
	    };

	    if ((_provider$token2 = provider.token) !== null && _provider$token2 !== void 0 && _provider$token2.request) {
	      const response = await provider.token.request({
	        provider,
	        params,
	        checks,
	        client
	      });
	      tokens = new _openidClient.TokenSet(response.tokens);
	    } else if (provider.idToken) {
	      tokens = await client.callback(provider.callbackUrl, params, checks);
	    } else {
	      tokens = await client.oauthCallback(provider.callbackUrl, params, checks);
	    }

	    if (Array.isArray(tokens.scope)) {
	      tokens.scope = tokens.scope.join(" ");
	    }

	    let profile;

	    if ((_provider$userinfo = provider.userinfo) !== null && _provider$userinfo !== void 0 && _provider$userinfo.request) {
	      profile = await provider.userinfo.request({
	        provider,
	        tokens,
	        client
	      });
	    } else if (provider.idToken) {
	      profile = tokens.claims();
	    } else {
	      var _provider$userinfo2;

	      profile = await client.userinfo(tokens, {
	        params: (_provider$userinfo2 = provider.userinfo) === null || _provider$userinfo2 === void 0 ? void 0 : _provider$userinfo2.params
	      });
	    }

	    const profileResult = await getProfile({
	      profile,
	      provider,
	      tokens,
	      logger
	    });
	    return { ...profileResult,
	      cookies: resCookies
	    };
	  } catch (error) {
	    throw new _errors.OAuthCallbackError(error);
	  }
	}

	async function getProfile({
	  profile: OAuthProfile,
	  tokens,
	  provider,
	  logger
	}) {
	  try {
	    var _profile$email;

	    logger.debug("PROFILE_DATA", {
	      OAuthProfile
	    });
	    const profile = await provider.profile(OAuthProfile, tokens);
	    profile.email = (_profile$email = profile.email) === null || _profile$email === void 0 ? void 0 : _profile$email.toLowerCase();
	    if (!profile.id) throw new TypeError(`Profile id is missing in ${provider.name} OAuth profile response`);
	    return {
	      profile,
	      account: {
	        provider: provider.id,
	        type: provider.type,
	        providerAccountId: profile.id.toString(),
	        ...tokens
	      },
	      OAuthProfile
	    };
	  } catch (error) {
	    logger.error("OAUTH_PARSE_PROFILE_ERROR", {
	      error: error,
	      OAuthProfile
	    });
	  }
	}
	return callback;
}

var callbackHandler = {};

var utils = {};

const require$$1$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(crypto);

var hasRequiredUtils;

function requireUtils () {
	if (hasRequiredUtils) return utils;
	hasRequiredUtils = 1;

	Object.defineProperty(utils, "__esModule", {
	  value: true
	});
	utils.createSecret = createSecret;
	utils.fromDate = fromDate;
	utils.hashToken = hashToken;

	var _crypto = require$$1$1;

	function fromDate(time, date = Date.now()) {
	  return new Date(date + time * 1000);
	}

	function hashToken(token, options) {
	  var _provider$secret;

	  const {
	    provider,
	    secret
	  } = options;
	  return (0, _crypto.createHash)("sha256").update(`${token}${(_provider$secret = provider.secret) !== null && _provider$secret !== void 0 ? _provider$secret : secret}`).digest("hex");
	}

	function createSecret(params) {
	  var _authOptions$secret;

	  const {
	    authOptions,
	    url
	  } = params;
	  return (_authOptions$secret = authOptions.secret) !== null && _authOptions$secret !== void 0 ? _authOptions$secret : (0, _crypto.createHash)("sha256").update(JSON.stringify({ ...url,
	    ...authOptions
	  })).digest("hex");
	}
	return utils;
}

var hasRequiredCallbackHandler;

function requireCallbackHandler () {
	if (hasRequiredCallbackHandler) return callbackHandler;
	hasRequiredCallbackHandler = 1;

	Object.defineProperty(callbackHandler, "__esModule", {
	  value: true
	});
	callbackHandler.default = callbackHandler$1;

	var _errors = /*@__PURE__*/ requireErrors();

	var _utils = /*@__PURE__*/ requireUtils();

	async function callbackHandler$1(params) {
	  const {
	    sessionToken,
	    profile: _profile,
	    account,
	    options
	  } = params;
	  if (!(account !== null && account !== void 0 && account.providerAccountId) || !account.type) throw new Error("Missing or invalid provider account");
	  if (!["email", "oauth"].includes(account.type)) throw new Error("Provider not supported");
	  const {
	    adapter,
	    jwt,
	    events,
	    session: {
	      strategy: sessionStrategy,
	      generateSessionToken
	    }
	  } = options;

	  if (!adapter) {
	    return {
	      user: _profile,
	      account
	    };
	  }

	  const profile = _profile;
	  const {
	    createUser,
	    updateUser,
	    getUser,
	    getUserByAccount,
	    getUserByEmail,
	    linkAccount,
	    createSession,
	    getSessionAndUser,
	    deleteSession
	  } = adapter;
	  let session = null;
	  let user = null;
	  let isNewUser = false;
	  const useJwtSession = sessionStrategy === "jwt";

	  if (sessionToken) {
	    if (useJwtSession) {
	      try {
	        session = await jwt.decode({ ...jwt,
	          token: sessionToken
	        });

	        if (session && "sub" in session && session.sub) {
	          user = await getUser(session.sub);
	        }
	      } catch (_unused) {}
	    } else {
	      const userAndSession = await getSessionAndUser(sessionToken);

	      if (userAndSession) {
	        session = userAndSession.session;
	        user = userAndSession.user;
	      }
	    }
	  }

	  if (account.type === "email") {
	    const userByEmail = await getUserByEmail(profile.email);

	    if (userByEmail) {
	      var _user, _events$updateUser;

	      if (((_user = user) === null || _user === void 0 ? void 0 : _user.id) !== userByEmail.id && !useJwtSession && sessionToken) {
	        await deleteSession(sessionToken);
	      }

	      user = await updateUser({
	        id: userByEmail.id,
	        emailVerified: new Date()
	      });
	      await ((_events$updateUser = events.updateUser) === null || _events$updateUser === void 0 ? void 0 : _events$updateUser.call(events, {
	        user
	      }));
	    } else {
	      var _events$createUser;

	      const {
	        id: _,
	        ...newUser
	      } = { ...profile,
	        emailVerified: new Date()
	      };
	      user = await createUser(newUser);
	      await ((_events$createUser = events.createUser) === null || _events$createUser === void 0 ? void 0 : _events$createUser.call(events, {
	        user
	      }));
	      isNewUser = true;
	    }

	    session = useJwtSession ? {} : await createSession({
	      sessionToken: await generateSessionToken(),
	      userId: user.id,
	      expires: (0, _utils.fromDate)(options.session.maxAge)
	    });
	    return {
	      session,
	      user,
	      isNewUser
	    };
	  } else if (account.type === "oauth") {
	    const userByAccount = await getUserByAccount({
	      providerAccountId: account.providerAccountId,
	      provider: account.provider
	    });

	    if (userByAccount) {
	      if (user) {
	        if (userByAccount.id === user.id) {
	          return {
	            session,
	            user,
	            isNewUser
	          };
	        }

	        throw new _errors.AccountNotLinkedError("The account is already associated with another user");
	      }

	      session = useJwtSession ? {} : await createSession({
	        sessionToken: await generateSessionToken(),
	        userId: userByAccount.id,
	        expires: (0, _utils.fromDate)(options.session.maxAge)
	      });
	      return {
	        session,
	        user: userByAccount,
	        isNewUser
	      };
	    } else {
	      var _events$createUser2, _events$linkAccount2;

	      if (user) {
	        var _events$linkAccount;

	        await linkAccount({ ...account,
	          userId: user.id
	        });
	        await ((_events$linkAccount = events.linkAccount) === null || _events$linkAccount === void 0 ? void 0 : _events$linkAccount.call(events, {
	          user,
	          account,
	          profile
	        }));
	        return {
	          session,
	          user,
	          isNewUser
	        };
	      }

	      const userByEmail = profile.email ? await getUserByEmail(profile.email) : null;

	      if (userByEmail) {
	        const provider = options.provider;

	        if (provider !== null && provider !== void 0 && provider.allowDangerousEmailAccountLinking) {
	          user = userByEmail;
	        } else {
	          throw new _errors.AccountNotLinkedError("Another account already exists with the same e-mail address");
	        }
	      } else {
	        const {
	          id: _,
	          ...newUser
	        } = { ...profile,
	          emailVerified: null
	        };
	        user = await createUser(newUser);
	      }

	      await ((_events$createUser2 = events.createUser) === null || _events$createUser2 === void 0 ? void 0 : _events$createUser2.call(events, {
	        user
	      }));
	      await linkAccount({ ...account,
	        userId: user.id
	      });
	      await ((_events$linkAccount2 = events.linkAccount) === null || _events$linkAccount2 === void 0 ? void 0 : _events$linkAccount2.call(events, {
	        user,
	        account,
	        profile
	      }));
	      session = useJwtSession ? {} : await createSession({
	        sessionToken: await generateSessionToken(),
	        userId: user.id,
	        expires: (0, _utils.fromDate)(options.session.maxAge)
	      });
	      return {
	        session,
	        user,
	        isNewUser: true
	      };
	    }
	  }

	  throw new Error("Unsupported account type");
	}
	return callbackHandler;
}

var getUserFromEmail = {};

var hasRequiredGetUserFromEmail;

function requireGetUserFromEmail () {
	if (hasRequiredGetUserFromEmail) return getUserFromEmail;
	hasRequiredGetUserFromEmail = 1;

	Object.defineProperty(getUserFromEmail, "__esModule", {
	  value: true
	});
	getUserFromEmail.default = getAdapterUserFromEmail;

	async function getAdapterUserFromEmail({
	  email,
	  adapter
	}) {
	  const {
	    getUserByEmail
	  } = adapter;
	  const adapterUser = email ? await getUserByEmail(email) : null;
	  if (adapterUser) return adapterUser;
	  return {
	    id: email,
	    email,
	    emailVerified: null
	  };
	}
	return getUserFromEmail;
}

var hasRequiredCallback;

function requireCallback () {
	if (hasRequiredCallback) return callback$1;
	hasRequiredCallback = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(callback$1, "__esModule", {
	  value: true
	});
	callback$1.default = callback;

	var _callback = _interopRequireDefault(/*@__PURE__*/ requireCallback$1());

	var _callbackHandler = _interopRequireDefault(/*@__PURE__*/ requireCallbackHandler());

	var _utils = /*@__PURE__*/ requireUtils();

	var _getUserFromEmail = _interopRequireDefault(/*@__PURE__*/ requireGetUserFromEmail());

	async function callback(params) {
	  const {
	    options,
	    query,
	    body,
	    method,
	    headers,
	    sessionStore
	  } = params;
	  const {
	    provider,
	    adapter,
	    url,
	    callbackUrl,
	    pages,
	    jwt,
	    events,
	    callbacks,
	    session: {
	      strategy: sessionStrategy,
	      maxAge: sessionMaxAge
	    },
	    logger
	  } = options;
	  const cookies = [];
	  const useJwtSession = sessionStrategy === "jwt";

	  if (provider.type === "oauth") {
	    try {
	      const {
	        profile,
	        account,
	        OAuthProfile,
	        cookies: oauthCookies
	      } = await (0, _callback.default)({
	        query,
	        body,
	        method,
	        options,
	        cookies: params.cookies
	      });
	      if (oauthCookies.length) cookies.push(...oauthCookies);

	      try {
	        var _events$signIn;

	        logger.debug("OAUTH_CALLBACK_RESPONSE", {
	          profile,
	          account,
	          OAuthProfile
	        });

	        if (!profile || !account || !OAuthProfile) {
	          return {
	            redirect: `${url}/signin`,
	            cookies
	          };
	        }

	        let userOrProfile = profile;

	        if (adapter) {
	          const {
	            getUserByAccount
	          } = adapter;
	          const userByAccount = await getUserByAccount({
	            providerAccountId: account.providerAccountId,
	            provider: provider.id
	          });
	          if (userByAccount) userOrProfile = userByAccount;
	        }

	        try {
	          const isAllowed = await callbacks.signIn({
	            user: userOrProfile,
	            account,
	            profile: OAuthProfile
	          });

	          if (!isAllowed) {
	            return {
	              redirect: `${url}/error?error=AccessDenied`,
	              cookies
	            };
	          } else if (typeof isAllowed === "string") {
	            return {
	              redirect: isAllowed,
	              cookies
	            };
	          }
	        } catch (error) {
	          return {
	            redirect: `${url}/error?error=${encodeURIComponent(error.message)}`,
	            cookies
	          };
	        }

	        const {
	          user,
	          session,
	          isNewUser
	        } = await (0, _callbackHandler.default)({
	          sessionToken: sessionStore.value,
	          profile,
	          account,
	          options
	        });

	        if (useJwtSession) {
	          var _user$id;

	          const defaultToken = {
	            name: user.name,
	            email: user.email,
	            picture: user.image,
	            sub: (_user$id = user.id) === null || _user$id === void 0 ? void 0 : _user$id.toString()
	          };
	          const token = await callbacks.jwt({
	            token: defaultToken,
	            user,
	            account,
	            profile: OAuthProfile,
	            isNewUser,
	            trigger: isNewUser ? "signUp" : "signIn"
	          });
	          const newToken = await jwt.encode({ ...jwt,
	            token
	          });
	          const cookieExpires = new Date();
	          cookieExpires.setTime(cookieExpires.getTime() + sessionMaxAge * 1000);
	          const sessionCookies = sessionStore.chunk(newToken, {
	            expires: cookieExpires
	          });
	          cookies.push(...sessionCookies);
	        } else {
	          cookies.push({
	            name: options.cookies.sessionToken.name,
	            value: session.sessionToken,
	            options: { ...options.cookies.sessionToken.options,
	              expires: session.expires
	            }
	          });
	        }

	        await ((_events$signIn = events.signIn) === null || _events$signIn === void 0 ? void 0 : _events$signIn.call(events, {
	          user,
	          account,
	          profile,
	          isNewUser
	        }));

	        if (isNewUser && pages.newUser) {
	          return {
	            redirect: `${pages.newUser}${pages.newUser.includes("?") ? "&" : "?"}callbackUrl=${encodeURIComponent(callbackUrl)}`,
	            cookies
	          };
	        }

	        return {
	          redirect: callbackUrl,
	          cookies
	        };
	      } catch (error) {
	        if (error.name === "AccountNotLinkedError") {
	          return {
	            redirect: `${url}/error?error=OAuthAccountNotLinked`,
	            cookies
	          };
	        } else if (error.name === "CreateUserError") {
	          return {
	            redirect: `${url}/error?error=OAuthCreateAccount`,
	            cookies
	          };
	        }

	        logger.error("OAUTH_CALLBACK_HANDLER_ERROR", error);
	        return {
	          redirect: `${url}/error?error=Callback`,
	          cookies
	        };
	      }
	    } catch (error) {
	      if (error.name === "OAuthCallbackError") {
	        logger.error("OAUTH_CALLBACK_ERROR", {
	          error: error,
	          providerId: provider.id
	        });
	        return {
	          redirect: `${url}/error?error=OAuthCallback`,
	          cookies
	        };
	      }

	      logger.error("OAUTH_CALLBACK_ERROR", error);
	      return {
	        redirect: `${url}/error?error=Callback`,
	        cookies
	      };
	    }
	  } else if (provider.type === "email") {
	    try {
	      var _events$signIn2;

	      const token = query === null || query === void 0 ? void 0 : query.token;
	      const identifier = query === null || query === void 0 ? void 0 : query.email;

	      if (!token || !identifier) {
	        return {
	          redirect: `${url}/error?error=configuration`,
	          cookies
	        };
	      }

	      const invite = await adapter.useVerificationToken({
	        identifier,
	        token: (0, _utils.hashToken)(token, options)
	      });
	      const invalidInvite = !invite || invite.expires.valueOf() < Date.now();

	      if (invalidInvite) {
	        return {
	          redirect: `${url}/error?error=Verification`,
	          cookies
	        };
	      }

	      const profile = await (0, _getUserFromEmail.default)({
	        email: identifier,
	        adapter
	      });
	      const account = {
	        providerAccountId: profile.email,
	        type: "email",
	        provider: provider.id
	      };

	      try {
	        const signInCallbackResponse = await callbacks.signIn({
	          user: profile,
	          account
	        });

	        if (!signInCallbackResponse) {
	          return {
	            redirect: `${url}/error?error=AccessDenied`,
	            cookies
	          };
	        } else if (typeof signInCallbackResponse === "string") {
	          return {
	            redirect: signInCallbackResponse,
	            cookies
	          };
	        }
	      } catch (error) {
	        return {
	          redirect: `${url}/error?error=${encodeURIComponent(error.message)}`,
	          cookies
	        };
	      }

	      const {
	        user,
	        session,
	        isNewUser
	      } = await (0, _callbackHandler.default)({
	        sessionToken: sessionStore.value,
	        profile,
	        account,
	        options
	      });

	      if (useJwtSession) {
	        var _user$id2;

	        const defaultToken = {
	          name: user.name,
	          email: user.email,
	          picture: user.image,
	          sub: (_user$id2 = user.id) === null || _user$id2 === void 0 ? void 0 : _user$id2.toString()
	        };
	        const token = await callbacks.jwt({
	          token: defaultToken,
	          user,
	          account,
	          isNewUser,
	          trigger: isNewUser ? "signUp" : "signIn"
	        });
	        const newToken = await jwt.encode({ ...jwt,
	          token
	        });
	        const cookieExpires = new Date();
	        cookieExpires.setTime(cookieExpires.getTime() + sessionMaxAge * 1000);
	        const sessionCookies = sessionStore.chunk(newToken, {
	          expires: cookieExpires
	        });
	        cookies.push(...sessionCookies);
	      } else {
	        cookies.push({
	          name: options.cookies.sessionToken.name,
	          value: session.sessionToken,
	          options: { ...options.cookies.sessionToken.options,
	            expires: session.expires
	          }
	        });
	      }

	      await ((_events$signIn2 = events.signIn) === null || _events$signIn2 === void 0 ? void 0 : _events$signIn2.call(events, {
	        user,
	        account,
	        isNewUser
	      }));

	      if (isNewUser && pages.newUser) {
	        return {
	          redirect: `${pages.newUser}${pages.newUser.includes("?") ? "&" : "?"}callbackUrl=${encodeURIComponent(callbackUrl)}`,
	          cookies
	        };
	      }

	      return {
	        redirect: callbackUrl,
	        cookies
	      };
	    } catch (error) {
	      if (error.name === "CreateUserError") {
	        return {
	          redirect: `${url}/error?error=EmailCreateAccount`,
	          cookies
	        };
	      }

	      logger.error("CALLBACK_EMAIL_ERROR", error);
	      return {
	        redirect: `${url}/error?error=Callback`,
	        cookies
	      };
	    }
	  } else if (provider.type === "credentials" && method === "POST") {
	    var _user$id3, _events$signIn3;

	    const credentials = body;
	    let user;

	    try {
	      user = await provider.authorize(credentials, {
	        query,
	        body,
	        headers,
	        method
	      });

	      if (!user) {
	        return {
	          status: 401,
	          redirect: `${url}/error?${new URLSearchParams({
	            error: "CredentialsSignin",
	            provider: provider.id
	          })}`,
	          cookies
	        };
	      }
	    } catch (error) {
	      return {
	        status: 401,
	        redirect: `${url}/error?error=${encodeURIComponent(error.message)}`,
	        cookies
	      };
	    }

	    const account = {
	      providerAccountId: user.id,
	      type: "credentials",
	      provider: provider.id
	    };

	    try {
	      const isAllowed = await callbacks.signIn({
	        user,
	        account,
	        credentials
	      });

	      if (!isAllowed) {
	        return {
	          status: 403,
	          redirect: `${url}/error?error=AccessDenied`,
	          cookies
	        };
	      } else if (typeof isAllowed === "string") {
	        return {
	          redirect: isAllowed,
	          cookies
	        };
	      }
	    } catch (error) {
	      return {
	        redirect: `${url}/error?error=${encodeURIComponent(error.message)}`,
	        cookies
	      };
	    }

	    const defaultToken = {
	      name: user.name,
	      email: user.email,
	      picture: user.image,
	      sub: (_user$id3 = user.id) === null || _user$id3 === void 0 ? void 0 : _user$id3.toString()
	    };
	    const token = await callbacks.jwt({
	      token: defaultToken,
	      user,
	      account,
	      isNewUser: false,
	      trigger: "signIn"
	    });
	    const newToken = await jwt.encode({ ...jwt,
	      token
	    });
	    const cookieExpires = new Date();
	    cookieExpires.setTime(cookieExpires.getTime() + sessionMaxAge * 1000);
	    const sessionCookies = sessionStore.chunk(newToken, {
	      expires: cookieExpires
	    });
	    cookies.push(...sessionCookies);
	    await ((_events$signIn3 = events.signIn) === null || _events$signIn3 === void 0 ? void 0 : _events$signIn3.call(events, {
	      user,
	      account
	    }));
	    return {
	      redirect: callbackUrl,
	      cookies
	    };
	  }

	  return {
	    status: 500,
	    body: `Error: Callback for provider type ${provider.type} not supported`,
	    cookies
	  };
	}
	return callback$1;
}

var signin$2 = {};

var authorizationUrl = {};

var hasRequiredAuthorizationUrl;

function requireAuthorizationUrl () {
	if (hasRequiredAuthorizationUrl) return authorizationUrl;
	hasRequiredAuthorizationUrl = 1;

	Object.defineProperty(authorizationUrl, "__esModule", {
	  value: true
	});
	authorizationUrl.default = getAuthorizationUrl;

	var _client = /*@__PURE__*/ requireClient();

	var _clientLegacy = /*@__PURE__*/ requireClientLegacy();

	var checks = _interopRequireWildcard(/*@__PURE__*/ requireChecks());

	function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

	function _interopRequireWildcard(obj, nodeInterop) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

	async function getAuthorizationUrl({
	  options,
	  query
	}) {
	  var _provider$version;

	  const {
	    logger,
	    provider
	  } = options;
	  let params = {};

	  if (typeof provider.authorization === "string") {
	    const parsedUrl = new URL(provider.authorization);
	    const parsedParams = Object.fromEntries(parsedUrl.searchParams);
	    params = { ...params,
	      ...parsedParams
	    };
	  } else {
	    var _provider$authorizati;

	    params = { ...params,
	      ...((_provider$authorizati = provider.authorization) === null || _provider$authorizati === void 0 ? void 0 : _provider$authorizati.params)
	    };
	  }

	  params = { ...params,
	    ...query
	  };

	  if ((_provider$version = provider.version) !== null && _provider$version !== void 0 && _provider$version.startsWith("1.")) {
	    var _provider$authorizati2;

	    const client = (0, _clientLegacy.oAuth1Client)(options);
	    const tokens = await client.getOAuthRequestToken(params);
	    const url = `${(_provider$authorizati2 = provider.authorization) === null || _provider$authorizati2 === void 0 ? void 0 : _provider$authorizati2.url}?${new URLSearchParams({
	      oauth_token: tokens.oauth_token,
	      oauth_token_secret: tokens.oauth_token_secret,
	      ...tokens.params
	    })}`;

	    _clientLegacy.oAuth1TokenStore.set(tokens.oauth_token, tokens.oauth_token_secret);

	    logger.debug("GET_AUTHORIZATION_URL", {
	      url,
	      provider
	    });
	    return {
	      redirect: url
	    };
	  }

	  const client = await (0, _client.openidClient)(options);
	  const authorizationParams = params;
	  const cookies = [];
	  await checks.state.create(options, cookies, authorizationParams);
	  await checks.pkce.create(options, cookies, authorizationParams);
	  await checks.nonce.create(options, cookies, authorizationParams);
	  const url = client.authorizationUrl(authorizationParams);
	  logger.debug("GET_AUTHORIZATION_URL", {
	    url,
	    cookies,
	    provider
	  });
	  return {
	    redirect: url,
	    cookies
	  };
	}
	return authorizationUrl;
}

var signin$1 = {};

var hasRequiredSignin$2;

function requireSignin$2 () {
	if (hasRequiredSignin$2) return signin$1;
	hasRequiredSignin$2 = 1;

	Object.defineProperty(signin$1, "__esModule", {
	  value: true
	});
	signin$1.default = email;

	var _crypto = require$$1$1;

	var _utils = /*@__PURE__*/ requireUtils();

	async function email(identifier, options) {
	  var _await$provider$gener, _provider$generateVer, _provider$maxAge;

	  const {
	    url,
	    adapter,
	    provider,
	    callbackUrl,
	    theme
	  } = options;
	  const token = (_await$provider$gener = await ((_provider$generateVer = provider.generateVerificationToken) === null || _provider$generateVer === void 0 ? void 0 : _provider$generateVer.call(provider))) !== null && _await$provider$gener !== void 0 ? _await$provider$gener : (0, _crypto.randomBytes)(32).toString("hex");
	  const ONE_DAY_IN_SECONDS = 86400;
	  const expires = new Date(Date.now() + ((_provider$maxAge = provider.maxAge) !== null && _provider$maxAge !== void 0 ? _provider$maxAge : ONE_DAY_IN_SECONDS) * 1000);
	  const params = new URLSearchParams({
	    callbackUrl,
	    token,
	    email: identifier
	  });
	  const _url = `${url}/callback/${provider.id}?${params}`;
	  await Promise.all([provider.sendVerificationRequest({
	    identifier,
	    token,
	    expires,
	    url: _url,
	    provider,
	    theme
	  }), adapter.createVerificationToken({
	    identifier,
	    token: (0, _utils.hashToken)(token, options),
	    expires
	  })]);
	  return `${url}/verify-request?${new URLSearchParams({
	    provider: provider.id,
	    type: provider.type
	  })}`;
	}
	return signin$1;
}

var hasRequiredSignin$1;

function requireSignin$1 () {
	if (hasRequiredSignin$1) return signin$2;
	hasRequiredSignin$1 = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(signin$2, "__esModule", {
	  value: true
	});
	signin$2.default = signin;

	var _authorizationUrl = _interopRequireDefault(/*@__PURE__*/ requireAuthorizationUrl());

	var _signin = _interopRequireDefault(/*@__PURE__*/ requireSignin$2());

	var _getUserFromEmail = _interopRequireDefault(/*@__PURE__*/ requireGetUserFromEmail());

	async function signin(params) {
	  const {
	    options,
	    query,
	    body
	  } = params;
	  const {
	    url,
	    callbacks,
	    logger,
	    provider
	  } = options;

	  if (!provider.type) {
	    return {
	      status: 500,
	      text: `Error: Type not specified for ${provider.name}`
	    };
	  }

	  if (provider.type === "oauth") {
	    try {
	      const response = await (0, _authorizationUrl.default)({
	        options,
	        query
	      });
	      return response;
	    } catch (error) {
	      logger.error("SIGNIN_OAUTH_ERROR", {
	        error: error,
	        providerId: provider.id
	      });
	      return {
	        redirect: `${url}/error?error=OAuthSignin`
	      };
	    }
	  } else if (provider.type === "email") {
	    var _provider$normalizeId;

	    let email = body === null || body === void 0 ? void 0 : body.email;
	    if (!email) return {
	      redirect: `${url}/error?error=EmailSignin`
	    };
	    const normalizer = (_provider$normalizeId = provider.normalizeIdentifier) !== null && _provider$normalizeId !== void 0 ? _provider$normalizeId : identifier => {
	      let [local, domain] = identifier.toLowerCase().trim().split("@");
	      domain = domain.split(",")[0];
	      return `${local}@${domain}`;
	    };

	    try {
	      email = normalizer(body === null || body === void 0 ? void 0 : body.email);
	    } catch (error) {
	      logger.error("SIGNIN_EMAIL_ERROR", {
	        error,
	        providerId: provider.id
	      });
	      return {
	        redirect: `${url}/error?error=EmailSignin`
	      };
	    }

	    const user = await (0, _getUserFromEmail.default)({
	      email,
	      adapter: options.adapter
	    });
	    const account = {
	      providerAccountId: email,
	      userId: email,
	      type: "email",
	      provider: provider.id
	    };

	    try {
	      const signInCallbackResponse = await callbacks.signIn({
	        user,
	        account,
	        email: {
	          verificationRequest: true
	        }
	      });

	      if (!signInCallbackResponse) {
	        return {
	          redirect: `${url}/error?error=AccessDenied`
	        };
	      } else if (typeof signInCallbackResponse === "string") {
	        return {
	          redirect: signInCallbackResponse
	        };
	      }
	    } catch (error) {
	      return {
	        redirect: `${url}/error?${new URLSearchParams({
	          error: error
	        })}`
	      };
	    }

	    try {
	      const redirect = await (0, _signin.default)(email, options);
	      return {
	        redirect
	      };
	    } catch (error) {
	      logger.error("SIGNIN_EMAIL_ERROR", {
	        error,
	        providerId: provider.id
	      });
	      return {
	        redirect: `${url}/error?error=EmailSignin`
	      };
	    }
	  }

	  return {
	    redirect: `${url}/signin`
	  };
	}
	return signin$2;
}

var signout$1 = {};

var hasRequiredSignout$1;

function requireSignout$1 () {
	if (hasRequiredSignout$1) return signout$1;
	hasRequiredSignout$1 = 1;

	Object.defineProperty(signout$1, "__esModule", {
	  value: true
	});
	signout$1.default = signout;

	async function signout(params) {
	  const {
	    options,
	    sessionStore
	  } = params;
	  const {
	    adapter,
	    events,
	    jwt,
	    callbackUrl,
	    logger,
	    session
	  } = options;
	  const sessionToken = sessionStore === null || sessionStore === void 0 ? void 0 : sessionStore.value;

	  if (!sessionToken) {
	    return {
	      redirect: callbackUrl
	    };
	  }

	  if (session.strategy === "jwt") {
	    try {
	      var _events$signOut;

	      const decodedJwt = await jwt.decode({ ...jwt,
	        token: sessionToken
	      });
	      await ((_events$signOut = events.signOut) === null || _events$signOut === void 0 ? void 0 : _events$signOut.call(events, {
	        token: decodedJwt
	      }));
	    } catch (error) {
	      logger.error("SIGNOUT_ERROR", error);
	    }
	  } else {
	    try {
	      var _events$signOut2;

	      const session = await adapter.deleteSession(sessionToken);
	      await ((_events$signOut2 = events.signOut) === null || _events$signOut2 === void 0 ? void 0 : _events$signOut2.call(events, {
	        session
	      }));
	    } catch (error) {
	      logger.error("SIGNOUT_ERROR", error);
	    }
	  }

	  const sessionCookies = sessionStore.clean();
	  return {
	    redirect: callbackUrl,
	    cookies: sessionCookies
	  };
	}
	return signout$1;
}

var session = {};

var hasRequiredSession;

function requireSession () {
	if (hasRequiredSession) return session;
	hasRequiredSession = 1;

	Object.defineProperty(session, "__esModule", {
	  value: true
	});
	session.default = session$1;

	var _utils = /*@__PURE__*/ requireUtils();

	async function session$1(params) {
	  const {
	    options,
	    sessionStore,
	    newSession,
	    isUpdate
	  } = params;
	  const {
	    adapter,
	    jwt,
	    events,
	    callbacks,
	    logger,
	    session: {
	      strategy: sessionStrategy,
	      maxAge: sessionMaxAge
	    }
	  } = options;
	  const response = {
	    body: {},
	    headers: [{
	      key: "Content-Type",
	      value: "application/json"
	    }],
	    cookies: []
	  };
	  const sessionToken = sessionStore.value;
	  if (!sessionToken) return response;

	  if (sessionStrategy === "jwt") {
	    try {
	      var _response$cookies, _events$session;

	      const decodedToken = await jwt.decode({ ...jwt,
	        token: sessionToken
	      });
	      if (!decodedToken) throw new Error("JWT invalid");
	      const token = await callbacks.jwt({
	        token: decodedToken,
	        ...(isUpdate && {
	          trigger: "update"
	        }),
	        session: newSession
	      });
	      const newExpires = (0, _utils.fromDate)(sessionMaxAge);
	      const updatedSession = await callbacks.session({
	        session: {
	          user: {
	            name: decodedToken === null || decodedToken === void 0 ? void 0 : decodedToken.name,
	            email: decodedToken === null || decodedToken === void 0 ? void 0 : decodedToken.email,
	            image: decodedToken === null || decodedToken === void 0 ? void 0 : decodedToken.picture
	          },
	          expires: newExpires.toISOString()
	        },
	        token
	      });
	      response.body = updatedSession;
	      const newToken = await jwt.encode({ ...jwt,
	        token,
	        maxAge: options.session.maxAge
	      });
	      const sessionCookies = sessionStore.chunk(newToken, {
	        expires: newExpires
	      });
	      (_response$cookies = response.cookies) === null || _response$cookies === void 0 ? void 0 : _response$cookies.push(...sessionCookies);
	      await ((_events$session = events.session) === null || _events$session === void 0 ? void 0 : _events$session.call(events, {
	        session: updatedSession,
	        token
	      }));
	    } catch (error) {
	      var _response$cookies2;

	      logger.error("JWT_SESSION_ERROR", error);
	      (_response$cookies2 = response.cookies) === null || _response$cookies2 === void 0 ? void 0 : _response$cookies2.push(...sessionStore.clean());
	    }
	  } else {
	    try {
	      const {
	        getSessionAndUser,
	        deleteSession,
	        updateSession
	      } = adapter;
	      let userAndSession = await getSessionAndUser(sessionToken);

	      if (userAndSession && userAndSession.session.expires.valueOf() < Date.now()) {
	        await deleteSession(sessionToken);
	        userAndSession = null;
	      }

	      if (userAndSession) {
	        var _response$cookies3, _events$session2;

	        const {
	          user,
	          session
	        } = userAndSession;
	        const sessionUpdateAge = options.session.updateAge;
	        const sessionIsDueToBeUpdatedDate = session.expires.valueOf() - sessionMaxAge * 1000 + sessionUpdateAge * 1000;
	        const newExpires = (0, _utils.fromDate)(sessionMaxAge);

	        if (sessionIsDueToBeUpdatedDate <= Date.now()) {
	          await updateSession({
	            sessionToken,
	            expires: newExpires
	          });
	        }

	        const sessionPayload = await callbacks.session({
	          session: {
	            user: {
	              name: user.name,
	              email: user.email,
	              image: user.image
	            },
	            expires: session.expires.toISOString()
	          },
	          user,
	          newSession,
	          ...(isUpdate ? {
	            trigger: "update"
	          } : {})
	        });
	        response.body = sessionPayload;
	        (_response$cookies3 = response.cookies) === null || _response$cookies3 === void 0 ? void 0 : _response$cookies3.push({
	          name: options.cookies.sessionToken.name,
	          value: sessionToken,
	          options: { ...options.cookies.sessionToken.options,
	            expires: newExpires
	          }
	        });
	        await ((_events$session2 = events.session) === null || _events$session2 === void 0 ? void 0 : _events$session2.call(events, {
	          session: sessionPayload
	        }));
	      } else if (sessionToken) {
	        var _response$cookies4;

	        (_response$cookies4 = response.cookies) === null || _response$cookies4 === void 0 ? void 0 : _response$cookies4.push(...sessionStore.clean());
	      }
	    } catch (error) {
	      logger.error("SESSION_ERROR", error);
	    }
	  }

	  return response;
	}
	return session;
}

var providers$1 = {};

var hasRequiredProviders$1;

function requireProviders$1 () {
	if (hasRequiredProviders$1) return providers$1;
	hasRequiredProviders$1 = 1;

	Object.defineProperty(providers$1, "__esModule", {
	  value: true
	});
	providers$1.default = providers;

	function providers(providers) {
	  return {
	    headers: [{
	      key: "Content-Type",
	      value: "application/json"
	    }],
	    body: providers.reduce((acc, {
	      id,
	      name,
	      type,
	      signinUrl,
	      callbackUrl
	    }) => {
	      acc[id] = {
	        id,
	        name,
	        type,
	        signinUrl,
	        callbackUrl
	      };
	      return acc;
	    }, {})
	  };
	}
	return providers$1;
}

(function (exports) {

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	Object.defineProperty(exports, "callback", {
	  enumerable: true,
	  get: function () {
	    return _callback.default;
	  }
	});
	Object.defineProperty(exports, "providers", {
	  enumerable: true,
	  get: function () {
	    return _providers.default;
	  }
	});
	Object.defineProperty(exports, "session", {
	  enumerable: true,
	  get: function () {
	    return _session.default;
	  }
	});
	Object.defineProperty(exports, "signin", {
	  enumerable: true,
	  get: function () {
	    return _signin.default;
	  }
	});
	Object.defineProperty(exports, "signout", {
	  enumerable: true,
	  get: function () {
	    return _signout.default;
	  }
	});

	var _callback = _interopRequireDefault(/*@__PURE__*/ requireCallback());

	var _signin = _interopRequireDefault(/*@__PURE__*/ requireSignin$1());

	var _signout = _interopRequireDefault(/*@__PURE__*/ requireSignout$1());

	var _session = _interopRequireDefault(/*@__PURE__*/ requireSession());

	var _providers = _interopRequireDefault(/*@__PURE__*/ requireProviders$1()); 
} (routes$1));

var pages = {};

const require$$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(preactRenderToString);

var signin = {};

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(preact);

var _extends = {exports: {}};

var hasRequired_extends;

function require_extends () {
	if (hasRequired_extends) return _extends.exports;
	hasRequired_extends = 1;
	(function (module) {
		function _extends() {
		  return module.exports = _extends = Object.assign ? Object.assign.bind() : function (n) {
		    for (var e = 1; e < arguments.length; e++) {
		      var t = arguments[e];
		      for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		    }
		    return n;
		  }, module.exports.__esModule = true, module.exports["default"] = module.exports, _extends.apply(null, arguments);
		}
		module.exports = _extends, module.exports.__esModule = true, module.exports["default"] = module.exports; 
	} (_extends));
	return _extends.exports;
}

var hasRequiredSignin;

function requireSignin () {
	if (hasRequiredSignin) return signin;
	hasRequiredSignin = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(signin, "__esModule", {
	  value: true
	});
	signin.default = SigninPage;

	var _preact = require$$0;

	var _extends2 = _interopRequireDefault(/*@__PURE__*/ require_extends());

	function SigninPage(props) {
	  var _errors$errorType;

	  const {
	    csrfToken,
	    providers,
	    callbackUrl,
	    theme,
	    email,
	    error: errorType
	  } = props;
	  const providersToRender = providers.filter(provider => {
	    if (provider.type === "oauth" || provider.type === "email") {
	      return true;
	    } else if (provider.type === "credentials" && provider.credentials) {
	      return true;
	    }

	    return false;
	  });

	  if (typeof document !== "undefined" && theme.buttonText) {
	    document.documentElement.style.setProperty("--button-text-color", theme.buttonText);
	  }

	  if (typeof document !== "undefined" && theme.brandColor) {
	    document.documentElement.style.setProperty("--brand-color", theme.brandColor);
	  }

	  const errors = {
	    Signin: "Try signing in with a different account.",
	    OAuthSignin: "Try signing in with a different account.",
	    OAuthCallback: "Try signing in with a different account.",
	    OAuthCreateAccount: "Try signing in with a different account.",
	    EmailCreateAccount: "Try signing in with a different account.",
	    Callback: "Try signing in with a different account.",
	    OAuthAccountNotLinked: "To confirm your identity, sign in with the same account you used originally.",
	    EmailSignin: "The e-mail could not be sent.",
	    CredentialsSignin: "Sign in failed. Check the details you provided are correct.",
	    SessionRequired: "Please sign in to access this page.",
	    default: "Unable to sign in."
	  };
	  const error = errorType && ((_errors$errorType = errors[errorType]) !== null && _errors$errorType !== void 0 ? _errors$errorType : errors.default);
	  const logos = "https://authjs.dev/img/providers";
	  return (0, _preact.h)("div", {
	    className: "signin"
	  }, theme.brandColor && (0, _preact.h)("style", {
	    dangerouslySetInnerHTML: {
	      __html: `
        :root {
          --brand-color: ${theme.brandColor}
        }
      `
	    }
	  }), theme.buttonText && (0, _preact.h)("style", {
	    dangerouslySetInnerHTML: {
	      __html: `
        :root {
          --button-text-color: ${theme.buttonText}
        }
      `
	    }
	  }), (0, _preact.h)("div", {
	    className: "card"
	  }, theme.logo && (0, _preact.h)("img", {
	    src: theme.logo,
	    alt: "Logo",
	    className: "logo"
	  }), error && (0, _preact.h)("div", {
	    className: "error"
	  }, (0, _preact.h)("p", null, error)), providersToRender.map((provider, i) => {
	    var _provider$style$bg, _provider$style, _provider$style$bgDar, _provider$style2, _provider$style$text, _provider$style3, _provider$style$textD, _provider$style4, _provider$style5, _provider$style6;

	    return (0, _preact.h)("div", {
	      key: provider.id,
	      className: "provider"
	    }, provider.type === "oauth" && (0, _preact.h)("form", {
	      action: provider.signinUrl,
	      method: "POST"
	    }, (0, _preact.h)("input", {
	      type: "hidden",
	      name: "csrfToken",
	      value: csrfToken
	    }), callbackUrl && (0, _preact.h)("input", {
	      type: "hidden",
	      name: "callbackUrl",
	      value: callbackUrl
	    }), (0, _preact.h)("button", {
	      type: "submit",
	      className: "button",
	      style: {
	        "--provider-bg": (_provider$style$bg = (_provider$style = provider.style) === null || _provider$style === void 0 ? void 0 : _provider$style.bg) !== null && _provider$style$bg !== void 0 ? _provider$style$bg : "",
	        "--provider-dark-bg": (_provider$style$bgDar = (_provider$style2 = provider.style) === null || _provider$style2 === void 0 ? void 0 : _provider$style2.bgDark) !== null && _provider$style$bgDar !== void 0 ? _provider$style$bgDar : "",
	        "--provider-color": (_provider$style$text = (_provider$style3 = provider.style) === null || _provider$style3 === void 0 ? void 0 : _provider$style3.text) !== null && _provider$style$text !== void 0 ? _provider$style$text : "",
	        "--provider-dark-color": (_provider$style$textD = (_provider$style4 = provider.style) === null || _provider$style4 === void 0 ? void 0 : _provider$style4.textDark) !== null && _provider$style$textD !== void 0 ? _provider$style$textD : ""
	      }
	    }, ((_provider$style5 = provider.style) === null || _provider$style5 === void 0 ? void 0 : _provider$style5.logo) && (0, _preact.h)("img", {
	      loading: "lazy",
	      height: 24,
	      width: 24,
	      id: "provider-logo",
	      src: `${provider.style.logo.startsWith("/") ? logos : ""}${provider.style.logo}`
	    }), ((_provider$style6 = provider.style) === null || _provider$style6 === void 0 ? void 0 : _provider$style6.logoDark) && (0, _preact.h)("img", {
	      loading: "lazy",
	      height: 24,
	      width: 24,
	      id: "provider-logo-dark",
	      src: `${provider.style.logo.startsWith("/") ? logos : ""}${provider.style.logoDark}`
	    }), (0, _preact.h)("span", null, "Sign in with ", provider.name))), (provider.type === "email" || provider.type === "credentials") && i > 0 && providersToRender[i - 1].type !== "email" && providersToRender[i - 1].type !== "credentials" && (0, _preact.h)("hr", null), provider.type === "email" && (0, _preact.h)("form", {
	      action: provider.signinUrl,
	      method: "POST"
	    }, (0, _preact.h)("input", {
	      type: "hidden",
	      name: "csrfToken",
	      value: csrfToken
	    }), (0, _preact.h)("label", {
	      className: "section-header",
	      htmlFor: `input-email-for-${provider.id}-provider`
	    }, "Email"), (0, _preact.h)("input", {
	      id: `input-email-for-${provider.id}-provider`,
	      autoFocus: true,
	      type: "email",
	      name: "email",
	      value: email,
	      placeholder: "email@example.com",
	      required: true
	    }), (0, _preact.h)("button", {
	      id: "submitButton",
	      type: "submit"
	    }, "Sign in with ", provider.name)), provider.type === "credentials" && (0, _preact.h)("form", {
	      action: provider.callbackUrl,
	      method: "POST"
	    }, (0, _preact.h)("input", {
	      type: "hidden",
	      name: "csrfToken",
	      value: csrfToken
	    }), Object.keys(provider.credentials).map(credential => {
	      var _provider$credentials, _provider$credentials2, _provider$credentials3;

	      return (0, _preact.h)("div", {
	        key: `input-group-${provider.id}`
	      }, (0, _preact.h)("label", {
	        className: "section-header",
	        htmlFor: `input-${credential}-for-${provider.id}-provider`
	      }, (_provider$credentials = provider.credentials[credential].label) !== null && _provider$credentials !== void 0 ? _provider$credentials : credential), (0, _preact.h)("input", (0, _extends2.default)({
	        name: credential,
	        id: `input-${credential}-for-${provider.id}-provider`,
	        type: (_provider$credentials2 = provider.credentials[credential].type) !== null && _provider$credentials2 !== void 0 ? _provider$credentials2 : "text",
	        placeholder: (_provider$credentials3 = provider.credentials[credential].placeholder) !== null && _provider$credentials3 !== void 0 ? _provider$credentials3 : ""
	      }, provider.credentials[credential])));
	    }), (0, _preact.h)("button", {
	      type: "submit"
	    }, "Sign in with ", provider.name)), (provider.type === "email" || provider.type === "credentials") && i + 1 < providersToRender.length && (0, _preact.h)("hr", null));
	  })));
	}
	return signin;
}

var signout = {};

var hasRequiredSignout;

function requireSignout () {
	if (hasRequiredSignout) return signout;
	hasRequiredSignout = 1;

	Object.defineProperty(signout, "__esModule", {
	  value: true
	});
	signout.default = SignoutPage;

	var _preact = require$$0;

	function SignoutPage(props) {
	  const {
	    url,
	    csrfToken,
	    theme
	  } = props;
	  return (0, _preact.h)("div", {
	    className: "signout"
	  }, theme.brandColor && (0, _preact.h)("style", {
	    dangerouslySetInnerHTML: {
	      __html: `
        :root {
          --brand-color: ${theme.brandColor}
        }
      `
	    }
	  }), theme.buttonText && (0, _preact.h)("style", {
	    dangerouslySetInnerHTML: {
	      __html: `
        :root {
          --button-text-color: ${theme.buttonText}
        }
      `
	    }
	  }), (0, _preact.h)("div", {
	    className: "card"
	  }, theme.logo && (0, _preact.h)("img", {
	    src: theme.logo,
	    alt: "Logo",
	    className: "logo"
	  }), (0, _preact.h)("h1", null, "Signout"), (0, _preact.h)("p", null, "Are you sure you want to sign out?"), (0, _preact.h)("form", {
	    action: `${url}/signout`,
	    method: "POST"
	  }, (0, _preact.h)("input", {
	    type: "hidden",
	    name: "csrfToken",
	    value: csrfToken
	  }), (0, _preact.h)("button", {
	    id: "submitButton",
	    type: "submit"
	  }, "Sign out"))));
	}
	return signout;
}

var verifyRequest = {};

var hasRequiredVerifyRequest;

function requireVerifyRequest () {
	if (hasRequiredVerifyRequest) return verifyRequest;
	hasRequiredVerifyRequest = 1;

	Object.defineProperty(verifyRequest, "__esModule", {
	  value: true
	});
	verifyRequest.default = VerifyRequestPage;

	var _preact = require$$0;

	function VerifyRequestPage(props) {
	  const {
	    url,
	    theme
	  } = props;
	  return (0, _preact.h)("div", {
	    className: "verify-request"
	  }, theme.brandColor && (0, _preact.h)("style", {
	    dangerouslySetInnerHTML: {
	      __html: `
        :root {
          --brand-color: ${theme.brandColor}
        }
      `
	    }
	  }), (0, _preact.h)("div", {
	    className: "card"
	  }, theme.logo && (0, _preact.h)("img", {
	    src: theme.logo,
	    alt: "Logo",
	    className: "logo"
	  }), (0, _preact.h)("h1", null, "Check your email"), (0, _preact.h)("p", null, "A sign in link has been sent to your email address."), (0, _preact.h)("p", null, (0, _preact.h)("a", {
	    className: "site",
	    href: url.origin
	  }, url.host))));
	}
	return verifyRequest;
}

var error = {};

var hasRequiredError;

function requireError () {
	if (hasRequiredError) return error;
	hasRequiredError = 1;

	Object.defineProperty(error, "__esModule", {
	  value: true
	});
	error.default = ErrorPage;

	var _preact = require$$0;

	function ErrorPage(props) {
	  var _errors$error$toLower;

	  const {
	    url,
	    error = "default",
	    theme
	  } = props;
	  const signinPageUrl = `${url}/signin`;
	  const errors = {
	    default: {
	      status: 200,
	      heading: "Error",
	      message: (0, _preact.h)("p", null, (0, _preact.h)("a", {
	        className: "site",
	        href: url === null || url === void 0 ? void 0 : url.origin
	      }, url === null || url === void 0 ? void 0 : url.host))
	    },
	    configuration: {
	      status: 500,
	      heading: "Server error",
	      message: (0, _preact.h)("div", null, (0, _preact.h)("p", null, "There is a problem with the server configuration."), (0, _preact.h)("p", null, "Check the server logs for more information."))
	    },
	    accessdenied: {
	      status: 403,
	      heading: "Access Denied",
	      message: (0, _preact.h)("div", null, (0, _preact.h)("p", null, "You do not have permission to sign in."), (0, _preact.h)("p", null, (0, _preact.h)("a", {
	        className: "button",
	        href: signinPageUrl
	      }, "Sign in")))
	    },
	    verification: {
	      status: 403,
	      heading: "Unable to sign in",
	      message: (0, _preact.h)("div", null, (0, _preact.h)("p", null, "The sign in link is no longer valid."), (0, _preact.h)("p", null, "It may have been used already or it may have expired.")),
	      signin: (0, _preact.h)("p", null, (0, _preact.h)("a", {
	        className: "button",
	        href: signinPageUrl
	      }, "Sign in"))
	    }
	  };
	  const {
	    status,
	    heading,
	    message,
	    signin
	  } = (_errors$error$toLower = errors[error.toLowerCase()]) !== null && _errors$error$toLower !== void 0 ? _errors$error$toLower : errors.default;
	  return {
	    status,
	    html: (0, _preact.h)("div", {
	      className: "error"
	    }, (theme === null || theme === void 0 ? void 0 : theme.brandColor) && (0, _preact.h)("style", {
	      dangerouslySetInnerHTML: {
	        __html: `
        :root {
          --brand-color: ${theme === null || theme === void 0 ? void 0 : theme.brandColor}
        }
      `
	      }
	    }), (0, _preact.h)("div", {
	      className: "card"
	    }, (theme === null || theme === void 0 ? void 0 : theme.logo) && (0, _preact.h)("img", {
	      src: theme.logo,
	      alt: "Logo",
	      className: "logo"
	    }), (0, _preact.h)("h1", null, heading), (0, _preact.h)("div", {
	      className: "message"
	    }, message), signin))
	  };
	}
	return error;
}

var css;
var hasRequiredCss;

function requireCss () {
	if (hasRequiredCss) return css;
	hasRequiredCss = 1;
	css = function() { return ":root{--border-width:1px;--border-radius:0.5rem;--color-error:#c94b4b;--color-info:#157efb;--color-info-text:#fff}.__next-auth-theme-auto,.__next-auth-theme-light{--color-background:#ececec;--color-background-card:#fff;--color-text:#000;--color-primary:#444;--color-control-border:#bbb;--color-button-active-background:#f9f9f9;--color-button-active-border:#aaa;--color-seperator:#ccc}.__next-auth-theme-dark{--color-background:#161b22;--color-background-card:#0d1117;--color-text:#fff;--color-primary:#ccc;--color-control-border:#555;--color-button-active-background:#060606;--color-button-active-border:#666;--color-seperator:#444}@media (prefers-color-scheme:dark){.__next-auth-theme-auto{--color-background:#161b22;--color-background-card:#0d1117;--color-text:#fff;--color-primary:#ccc;--color-control-border:#555;--color-button-active-background:#060606;--color-button-active-border:#666;--color-seperator:#444}}body{background-color:var(--color-background);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;margin:0;padding:0}h1{font-weight:400;margin-bottom:1.5rem;padding:0 1rem}h1,p{color:var(--color-text)}form{margin:0;padding:0}label{font-weight:500;margin-bottom:.25rem;text-align:left}input[type],label{color:var(--color-text);display:block}input[type]{background:var(--color-background-card);border:var(--border-width) solid var(--color-control-border);border-radius:var(--border-radius);box-sizing:border-box;font-size:1rem;padding:.5rem 1rem;width:100%}input[type]:focus{box-shadow:none}p{font-size:1.1rem;line-height:2rem;margin:0 0 1.5rem;padding:0 1rem}a.button{line-height:1rem;text-decoration:none}a.button:link,a.button:visited{background-color:var(--color-background);color:var(--color-primary)}button span{flex-grow:1}a.button,button{align-items:center;background-color:var(--provider-bg,var(--color-background-card));border-color:rgba(0,0,0,.1);border-radius:var(--border-radius);color:var(--provider-color,var(--color-primary));display:flex;font-size:1.1rem;font-weight:500;justify-content:center;margin:0 0 .75rem;min-height:62px;padding:.75rem 1rem;position:relative;transition:all .1s ease-in-out}@media (max-width:450px){a.button,button{font-size:.9rem}}a.button:active,a.button:hover,button:active,button:hover{cursor:pointer}a.button #provider-logo,button #provider-logo{display:block;width:25px}a.button #provider-logo-dark,button #provider-logo-dark{display:none}#submitButton{background-color:var(--brand-color,var(--color-info));color:var(--button-text-color,var(--color-info-text));width:100%}@media (prefers-color-scheme:dark){a.button,button{background-color:var(--provider-dark-bg,var(--color-background));color:var(--provider-dark-color,var(--color-primary))}#provider-logo{display:none!important}#provider-logo-dark{display:block!important;width:25px}}a.site{color:var(--color-primary);font-size:1rem;line-height:2rem;text-decoration:none}a.site:hover{text-decoration:underline}.page{display:grid;height:100%;margin:0;padding:0;place-items:center;position:absolute;width:100%}.page>div{text-align:center}.error a.button{display:inline-block;margin-top:.5rem;padding-left:2rem;padding-right:2rem}.error .message{margin-bottom:1.5rem}.signin input[type=text]{display:block;margin-left:auto;margin-right:auto}.signin hr{border:0;border-top:1px solid var(--color-seperator);display:block;margin:2rem auto 1rem;overflow:visible}.signin hr:before{background:var(--color-background-card);color:#888;content:\"or\";padding:0 .4rem;position:relative;top:-.7rem}.signin .error{background:#f5f5f5;background:var(--color-error);border-radius:.3rem;font-weight:500}.signin .error p{color:var(--color-info-text);font-size:.9rem;line-height:1.2rem;padding:.5rem 1rem;text-align:left}.signin form,.signin>div{display:block}.signin form input[type],.signin>div input[type]{margin-bottom:.5rem}.signin form button,.signin>div button{width:100%}.signin form,.signin>div{max-width:300px}.logo{display:inline-block;margin-bottom:25px;margin-top:20px;max-height:70px;max-width:150px}@media screen and (min-width:450px){.card{width:350px}}@media screen and (max-width:450px){.card{width:200px}}.card{background-color:var(--color-background-card);border-radius:30px;margin:20px 0;padding:20px 50px}.card .header{color:var(--color-primary)}.section-header{color:var(--color-text)}" };
	return css;
}

var hasRequiredPages;

function requirePages () {
	if (hasRequiredPages) return pages;
	hasRequiredPages = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(pages, "__esModule", {
	  value: true
	});
	pages.default = renderPage;

	var _preactRenderToString = _interopRequireDefault(require$$1);

	var _signin = _interopRequireDefault(/*@__PURE__*/ requireSignin());

	var _signout = _interopRequireDefault(/*@__PURE__*/ requireSignout());

	var _verifyRequest = _interopRequireDefault(/*@__PURE__*/ requireVerifyRequest());

	var _error = _interopRequireDefault(/*@__PURE__*/ requireError());

	var _css = _interopRequireDefault(/*@__PURE__*/ requireCss());

	function renderPage(params) {
	  const {
	    url,
	    theme,
	    query,
	    cookies
	  } = params;

	  function send({
	    html,
	    title,
	    status
	  }) {
	    var _theme$colorScheme;

	    return {
	      cookies,
	      status,
	      headers: [{
	        key: "Content-Type",
	        value: "text/html"
	      }],
	      body: `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>${(0, _css.default)()}</style><title>${title}</title></head><body class="__next-auth-theme-${(_theme$colorScheme = theme === null || theme === void 0 ? void 0 : theme.colorScheme) !== null && _theme$colorScheme !== void 0 ? _theme$colorScheme : "auto"}"><div class="page">${(0, _preactRenderToString.default)(html)}</div></body></html>`
	    };
	  }

	  return {
	    signin(props) {
	      return send({
	        html: (0, _signin.default)({
	          csrfToken: params.csrfToken,
	          providers: params.providers,
	          callbackUrl: params.callbackUrl,
	          theme,
	          ...query,
	          ...props
	        }),
	        title: "Sign In"
	      });
	    },

	    signout(props) {
	      return send({
	        html: (0, _signout.default)({
	          csrfToken: params.csrfToken,
	          url,
	          theme,
	          ...props
	        }),
	        title: "Sign Out"
	      });
	    },

	    verifyRequest(props) {
	      return send({
	        html: (0, _verifyRequest.default)({
	          url,
	          theme,
	          ...props
	        }),
	        title: "Verify Request"
	      });
	    },

	    error(props) {
	      return send({ ...(0, _error.default)({
	          url,
	          theme,
	          ...props
	        }),
	        title: "Error"
	      });
	    }

	  };
	}
	return pages;
}

var init = {};

var providers = {};

var merge = {};

var hasRequiredMerge;

function requireMerge () {
	if (hasRequiredMerge) return merge;
	hasRequiredMerge = 1;

	Object.defineProperty(merge, "__esModule", {
	  value: true
	});
	merge.merge = merge$1;

	function isObject(item) {
	  return item && typeof item === "object" && !Array.isArray(item);
	}

	function merge$1(target, ...sources) {
	  if (!sources.length) return target;
	  const source = sources.shift();

	  if (isObject(target) && isObject(source)) {
	    for (const key in source) {
	      if (isObject(source[key])) {
	        if (!target[key]) Object.assign(target, {
	          [key]: {}
	        });
	        merge$1(target[key], source[key]);
	      } else {
	        Object.assign(target, {
	          [key]: source[key]
	        });
	      }
	    }
	  }

	  return merge$1(target, ...sources);
	}
	return merge;
}

var hasRequiredProviders;

function requireProviders () {
	if (hasRequiredProviders) return providers;
	hasRequiredProviders = 1;

	Object.defineProperty(providers, "__esModule", {
	  value: true
	});
	providers.default = parseProviders;

	var _merge = /*@__PURE__*/ requireMerge();

	function parseProviders(params) {
	  const {
	    url,
	    providerId
	  } = params;
	  const providers = params.providers.map(({
	    options: userOptions,
	    ...rest
	  }) => {
	    var _ref;

	    if (rest.type === "oauth") {
	      var _normalizedUserOption;

	      const normalizedOptions = normalizeOAuthOptions(rest);
	      const normalizedUserOptions = normalizeOAuthOptions(userOptions, true);
	      const id = (_normalizedUserOption = normalizedUserOptions === null || normalizedUserOptions === void 0 ? void 0 : normalizedUserOptions.id) !== null && _normalizedUserOption !== void 0 ? _normalizedUserOption : rest.id;
	      return (0, _merge.merge)(normalizedOptions, { ...normalizedUserOptions,
	        signinUrl: `${url}/signin/${id}`,
	        callbackUrl: `${url}/callback/${id}`
	      });
	    }

	    const id = (_ref = userOptions === null || userOptions === void 0 ? void 0 : userOptions.id) !== null && _ref !== void 0 ? _ref : rest.id;
	    return (0, _merge.merge)(rest, { ...userOptions,
	      signinUrl: `${url}/signin/${id}`,
	      callbackUrl: `${url}/callback/${id}`
	    });
	  });
	  return {
	    providers,
	    provider: providers.find(({
	      id
	    }) => id === providerId)
	  };
	}

	function normalizeOAuthOptions(oauthOptions, isUserOptions = false) {
	  var _normalized$version;

	  if (!oauthOptions) return;
	  const normalized = Object.entries(oauthOptions).reduce((acc, [key, value]) => {
	    if (["authorization", "token", "userinfo"].includes(key) && typeof value === "string") {
	      var _url$searchParams;

	      const url = new URL(value);
	      acc[key] = {
	        url: `${url.origin}${url.pathname}`,
	        params: Object.fromEntries((_url$searchParams = url.searchParams) !== null && _url$searchParams !== void 0 ? _url$searchParams : [])
	      };
	    } else {
	      acc[key] = value;
	    }

	    return acc;
	  }, {});

	  if (!isUserOptions && !((_normalized$version = normalized.version) !== null && _normalized$version !== void 0 && _normalized$version.startsWith("1."))) {
	    var _ref2, _normalized$idToken, _normalized$wellKnown, _normalized$authoriza, _normalized$authoriza2, _normalized$authoriza3;

	    normalized.idToken = Boolean((_ref2 = (_normalized$idToken = normalized.idToken) !== null && _normalized$idToken !== void 0 ? _normalized$idToken : (_normalized$wellKnown = normalized.wellKnown) === null || _normalized$wellKnown === void 0 ? void 0 : _normalized$wellKnown.includes("openid-configuration")) !== null && _ref2 !== void 0 ? _ref2 : (_normalized$authoriza = normalized.authorization) === null || _normalized$authoriza === void 0 ? void 0 : (_normalized$authoriza2 = _normalized$authoriza.params) === null || _normalized$authoriza2 === void 0 ? void 0 : (_normalized$authoriza3 = _normalized$authoriza2.scope) === null || _normalized$authoriza3 === void 0 ? void 0 : _normalized$authoriza3.includes("openid"));
	    if (!normalized.checks) normalized.checks = ["state"];
	  }

	  return normalized;
	}
	return providers;
}

var defaultCallbacks = {};

var hasRequiredDefaultCallbacks;

function requireDefaultCallbacks () {
	if (hasRequiredDefaultCallbacks) return defaultCallbacks;
	hasRequiredDefaultCallbacks = 1;

	Object.defineProperty(defaultCallbacks, "__esModule", {
	  value: true
	});
	defaultCallbacks.defaultCallbacks = void 0;
	const defaultCallbacks$1 = {
	  signIn() {
	    return true;
	  },

	  redirect({
	    url,
	    baseUrl
	  }) {
	    if (url.startsWith("/")) return `${baseUrl}${url}`;else if (new URL(url).origin === baseUrl) return url;
	    return baseUrl;
	  },

	  session({
	    session
	  }) {
	    return session;
	  },

	  jwt({
	    token
	  }) {
	    return token;
	  }

	};
	defaultCallbacks.defaultCallbacks = defaultCallbacks$1;
	return defaultCallbacks;
}

var csrfToken = {};

var hasRequiredCsrfToken;

function requireCsrfToken () {
	if (hasRequiredCsrfToken) return csrfToken;
	hasRequiredCsrfToken = 1;

	Object.defineProperty(csrfToken, "__esModule", {
	  value: true
	});
	csrfToken.createCSRFToken = createCSRFToken;

	var _crypto = require$$1$1;

	function createCSRFToken({
	  options,
	  cookieValue,
	  isPost,
	  bodyValue
	}) {
	  if (cookieValue) {
	    const [csrfToken, csrfTokenHash] = cookieValue.split("|");
	    const expectedCsrfTokenHash = (0, _crypto.createHash)("sha256").update(`${csrfToken}${options.secret}`).digest("hex");

	    if (csrfTokenHash === expectedCsrfTokenHash) {
	      const csrfTokenVerified = isPost && csrfToken === bodyValue;
	      return {
	        csrfTokenVerified,
	        csrfToken
	      };
	    }
	  }

	  const csrfToken = (0, _crypto.randomBytes)(32).toString("hex");
	  const csrfTokenHash = (0, _crypto.createHash)("sha256").update(`${csrfToken}${options.secret}`).digest("hex");
	  const cookie = `${csrfToken}|${csrfTokenHash}`;
	  return {
	    cookie,
	    csrfToken
	  };
	}
	return csrfToken;
}

var callbackUrl = {};

var hasRequiredCallbackUrl;

function requireCallbackUrl () {
	if (hasRequiredCallbackUrl) return callbackUrl;
	hasRequiredCallbackUrl = 1;

	Object.defineProperty(callbackUrl, "__esModule", {
	  value: true
	});
	callbackUrl.createCallbackUrl = createCallbackUrl;

	async function createCallbackUrl({
	  options,
	  paramValue,
	  cookieValue
	}) {
	  const {
	    url,
	    callbacks
	  } = options;
	  let callbackUrl = url.origin;

	  if (paramValue) {
	    callbackUrl = await callbacks.redirect({
	      url: paramValue,
	      baseUrl: url.origin
	    });
	  } else if (cookieValue) {
	    callbackUrl = await callbacks.redirect({
	      url: cookieValue,
	      baseUrl: url.origin
	    });
	  }

	  return {
	    callbackUrl,
	    callbackUrlCookie: callbackUrl !== cookieValue ? callbackUrl : undefined
	  };
	}
	return callbackUrl;
}

var parseUrl = {};

var hasRequiredParseUrl;

function requireParseUrl () {
	if (hasRequiredParseUrl) return parseUrl;
	hasRequiredParseUrl = 1;

	Object.defineProperty(parseUrl, "__esModule", {
	  value: true
	});
	parseUrl.default = parseUrl$1;

	function parseUrl$1(url) {
	  var _url2;

	  const defaultUrl = new URL("http://localhost:3000/api/auth");

	  if (url && !url.startsWith("http")) {
	    url = `https://${url}`;
	  }

	  const _url = new URL((_url2 = url) !== null && _url2 !== void 0 ? _url2 : defaultUrl);

	  const path = (_url.pathname === "/" ? defaultUrl.pathname : _url.pathname).replace(/\/$/, "");
	  const base = `${_url.origin}${path}`;
	  return {
	    origin: _url.origin,
	    host: _url.host,
	    path,
	    base,
	    toString: () => base
	  };
	}
	return parseUrl;
}

var hasRequiredInit;

function requireInit () {
	if (hasRequiredInit) return init;
	hasRequiredInit = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(init, "__esModule", {
	  value: true
	});
	init.init = init$1;

	var _crypto = require$$1$1;

	var _logger = _interopRequireDefault(logger);

	var _errors = /*@__PURE__*/ requireErrors();

	var _providers = _interopRequireDefault(/*@__PURE__*/ requireProviders());

	var _utils = /*@__PURE__*/ requireUtils();

	var cookie = _interopRequireWildcard(/*@__PURE__*/ requireCookie());

	var jwt$1 = _interopRequireWildcard(jwt);

	var _defaultCallbacks = /*@__PURE__*/ requireDefaultCallbacks();

	var _csrfToken = /*@__PURE__*/ requireCsrfToken();

	var _callbackUrl = /*@__PURE__*/ requireCallbackUrl();

	var _parseUrl = _interopRequireDefault(/*@__PURE__*/ requireParseUrl());

	function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

	function _interopRequireWildcard(obj, nodeInterop) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

	async function init$1({
	  authOptions,
	  providerId,
	  action,
	  host,
	  cookies: reqCookies,
	  callbackUrl: reqCallbackUrl,
	  csrfToken: reqCsrfToken,
	  isPost
	}) {
	  var _authOptions$useSecur, _authOptions$events;

	  const url = (0, _parseUrl.default)(host);
	  const secret = (0, _utils.createSecret)({
	    authOptions,
	    url
	  });
	  const {
	    providers,
	    provider
	  } = (0, _providers.default)({
	    providers: authOptions.providers,
	    url,
	    providerId
	  });
	  const maxAge = 30 * 24 * 60 * 60;
	  const options = {
	    debug: false,
	    pages: {},
	    theme: {
	      colorScheme: "auto",
	      logo: "",
	      brandColor: "",
	      buttonText: ""
	    },
	    ...authOptions,
	    url,
	    action,
	    provider,
	    cookies: { ...cookie.defaultCookies((_authOptions$useSecur = authOptions.useSecureCookies) !== null && _authOptions$useSecur !== void 0 ? _authOptions$useSecur : url.base.startsWith("https://")),
	      ...authOptions.cookies
	    },
	    secret,
	    providers,
	    session: {
	      strategy: authOptions.adapter ? "database" : "jwt",
	      maxAge,
	      updateAge: 24 * 60 * 60,
	      generateSessionToken: () => {
	        var _randomUUID;

	        return (_randomUUID = _crypto.randomUUID === null || _crypto.randomUUID === void 0 ? void 0 : (0, _crypto.randomUUID)()) !== null && _randomUUID !== void 0 ? _randomUUID : (0, _crypto.randomBytes)(32).toString("hex");
	      },
	      ...authOptions.session
	    },
	    jwt: {
	      secret,
	      maxAge,
	      encode: jwt$1.encode,
	      decode: jwt$1.decode,
	      ...authOptions.jwt
	    },
	    events: (0, _errors.eventsErrorHandler)((_authOptions$events = authOptions.events) !== null && _authOptions$events !== void 0 ? _authOptions$events : {}, _logger.default),
	    adapter: (0, _errors.adapterErrorHandler)(authOptions.adapter, _logger.default),
	    callbacks: { ..._defaultCallbacks.defaultCallbacks,
	      ...authOptions.callbacks
	    },
	    logger: _logger.default,
	    callbackUrl: url.origin
	  };
	  const cookies = [];
	  const {
	    csrfToken,
	    cookie: csrfCookie,
	    csrfTokenVerified
	  } = (0, _csrfToken.createCSRFToken)({
	    options,
	    cookieValue: reqCookies === null || reqCookies === void 0 ? void 0 : reqCookies[options.cookies.csrfToken.name],
	    isPost,
	    bodyValue: reqCsrfToken
	  });
	  options.csrfToken = csrfToken;
	  options.csrfTokenVerified = csrfTokenVerified;

	  if (csrfCookie) {
	    cookies.push({
	      name: options.cookies.csrfToken.name,
	      value: csrfCookie,
	      options: options.cookies.csrfToken.options
	    });
	  }

	  const {
	    callbackUrl,
	    callbackUrlCookie
	  } = await (0, _callbackUrl.createCallbackUrl)({
	    options,
	    cookieValue: reqCookies === null || reqCookies === void 0 ? void 0 : reqCookies[options.cookies.callbackUrl.name],
	    paramValue: reqCallbackUrl
	  });
	  options.callbackUrl = callbackUrl;

	  if (callbackUrlCookie) {
	    cookies.push({
	      name: options.cookies.callbackUrl.name,
	      value: callbackUrlCookie,
	      options: options.cookies.callbackUrl.options
	    });
	  }

	  return {
	    options,
	    cookies
	  };
	}
	return init;
}

var assert = {};

var hasRequiredAssert;

function requireAssert () {
	if (hasRequiredAssert) return assert;
	hasRequiredAssert = 1;

	var _interopRequireDefault = interopRequireDefaultExports;

	Object.defineProperty(assert, "__esModule", {
	  value: true
	});
	assert.assertConfig = assertConfig;

	var _errors = /*@__PURE__*/ requireErrors();

	var _parseUrl = _interopRequireDefault(/*@__PURE__*/ requireParseUrl());

	var _cookie = /*@__PURE__*/ requireCookie();

	let warned = false;

	function isValidHttpUrl(url, baseUrl) {
	  try {
	    return /^https?:/.test(new URL(url, url.startsWith("/") ? baseUrl : undefined).protocol);
	  } catch (_unused) {
	    return false;
	  }
	}

	function assertConfig(params) {
	  var _req$query, _req$query2, _options$useSecureCoo, _req$cookies, _options$cookies$call, _options$cookies, _options$cookies$call2;

	  const {
	    options,
	    req
	  } = params;
	  const warnings = [];

	  if (!warned) {
	    if (!req.host) warnings.push("NEXTAUTH_URL");
	    if (!options.secret && "production" !== "production") ;
	    if (options.debug) warnings.push("DEBUG_ENABLED");
	  }

	  if (!options.secret && "production" === "production") {
	    return new _errors.MissingSecret("Please define a `secret` in production.");
	  }

	  if (!((_req$query = req.query) !== null && _req$query !== void 0 && _req$query.nextauth) && !req.action) {
	    return new _errors.MissingAPIRoute("Cannot find [...nextauth].{js,ts} in `/pages/api/auth`. Make sure the filename is written correctly.");
	  }

	  const callbackUrlParam = (_req$query2 = req.query) === null || _req$query2 === void 0 ? void 0 : _req$query2.callbackUrl;
	  const url = (0, _parseUrl.default)(req.host);

	  if (callbackUrlParam && !isValidHttpUrl(callbackUrlParam, url.base)) {
	    return new _errors.InvalidCallbackUrl(`Invalid callback URL. Received: ${callbackUrlParam}`);
	  }

	  const {
	    callbackUrl: defaultCallbackUrl
	  } = (0, _cookie.defaultCookies)((_options$useSecureCoo = options.useSecureCookies) !== null && _options$useSecureCoo !== void 0 ? _options$useSecureCoo : url.base.startsWith("https://"));
	  const callbackUrlCookie = (_req$cookies = req.cookies) === null || _req$cookies === void 0 ? void 0 : _req$cookies[(_options$cookies$call = (_options$cookies = options.cookies) === null || _options$cookies === void 0 ? void 0 : (_options$cookies$call2 = _options$cookies.callbackUrl) === null || _options$cookies$call2 === void 0 ? void 0 : _options$cookies$call2.name) !== null && _options$cookies$call !== void 0 ? _options$cookies$call : defaultCallbackUrl.name];

	  if (callbackUrlCookie && !isValidHttpUrl(callbackUrlCookie, url.base)) {
	    return new _errors.InvalidCallbackUrl(`Invalid callback URL. Received: ${callbackUrlCookie}`);
	  }

	  let hasCredentials, hasEmail;
	  let hasTwitterOAuth2;

	  for (const provider of options.providers) {
	    if (provider.type === "credentials") hasCredentials = true;else if (provider.type === "email") hasEmail = true;else if (provider.id === "twitter" && provider.version === "2.0") hasTwitterOAuth2 = true;
	  }

	  if (hasCredentials) {
	    var _options$session;

	    const dbStrategy = ((_options$session = options.session) === null || _options$session === void 0 ? void 0 : _options$session.strategy) === "database";
	    const onlyCredentials = !options.providers.some(p => p.type !== "credentials");

	    if (dbStrategy && onlyCredentials) {
	      return new _errors.UnsupportedStrategy("Signin in with credentials only supported if JWT strategy is enabled");
	    }

	    const credentialsNoAuthorize = options.providers.some(p => p.type === "credentials" && !p.authorize);

	    if (credentialsNoAuthorize) {
	      return new _errors.MissingAuthorize("Must define an authorize() handler to use credentials authentication provider");
	    }
	  }

	  if (hasEmail) {
	    const {
	      adapter
	    } = options;

	    if (!adapter) {
	      return new _errors.MissingAdapter("E-mail login requires an adapter.");
	    }

	    const missingMethods = ["createVerificationToken", "useVerificationToken", "getUserByEmail"].filter(method => !adapter[method]);

	    if (missingMethods.length) {
	      return new _errors.MissingAdapterMethods(`Required adapter methods were missing: ${missingMethods.join(", ")}`);
	    }
	  }

	  if (!warned) {
	    if (hasTwitterOAuth2) warnings.push("TWITTER_OAUTH_2_BETA");
	    warned = true;
	  }

	  return warnings;
	}
	return assert;
}

const require$$8 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(cookie$1);

var _interopRequireDefault = interopRequireDefaultExports;

Object.defineProperty(core, "__esModule", {
  value: true
});
var AuthHandler_1 = core.AuthHandler = AuthHandler;

var _logger = _interopRequireWildcard(logger);

var _detectHost = detectHost$1;

var routes = _interopRequireWildcard(routes$1);

var _pages = _interopRequireDefault(/*@__PURE__*/ requirePages());

var _init = /*@__PURE__*/ requireInit();

var _assert = /*@__PURE__*/ requireAssert();

var _cookie = /*@__PURE__*/ requireCookie();

var _cookie2 = require$$8;

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

async function getBody(req) {
  try {
    return await req.json();
  } catch (_unused) {}
}

async function toInternalRequest(req) {
  if (req instanceof Request) {
    var _req$headers$get, _url$searchParams$get, _headers$xForwarded;

    const url = new URL(req.url);
    const nextauth = url.pathname.split("/").slice(3);
    const headers = Object.fromEntries(req.headers);
    const query = Object.fromEntries(url.searchParams);
    query.nextauth = nextauth;
    return {
      action: nextauth[0],
      method: req.method,
      headers,
      body: await getBody(req),
      cookies: (0, _cookie2.parse)((_req$headers$get = req.headers.get("cookie")) !== null && _req$headers$get !== void 0 ? _req$headers$get : ""),
      providerId: nextauth[1],
      error: (_url$searchParams$get = url.searchParams.get("error")) !== null && _url$searchParams$get !== void 0 ? _url$searchParams$get : nextauth[1],
      host: (0, _detectHost.detectHost)((_headers$xForwarded = headers["x-forwarded-host"]) !== null && _headers$xForwarded !== void 0 ? _headers$xForwarded : headers.host),
      query
    };
  }

  return req;
}

async function AuthHandler(params) {
  var _req$body$callbackUrl, _req$body, _req$query2, _req$body2;

  const {
    options: authOptions,
    req: incomingRequest
  } = params;
  const req = await toInternalRequest(incomingRequest);
  (0, _logger.setLogger)(authOptions.logger, authOptions.debug);
  const assertionResult = (0, _assert.assertConfig)({
    options: authOptions,
    req
  });

  if (Array.isArray(assertionResult)) {
    assertionResult.forEach(_logger.default.warn);
  } else if (assertionResult instanceof Error) {
    var _req$query, _req$query$callbackUr;

    _logger.default.error(assertionResult.code, assertionResult);

    const htmlPages = ["signin", "signout", "error", "verify-request"];

    if (!htmlPages.includes(req.action) || req.method !== "GET") {
      const message = `There is a problem with the server configuration. Check the server logs for more information.`;
      return {
        status: 500,
        headers: [{
          key: "Content-Type",
          value: "application/json"
        }],
        body: {
          message
        }
      };
    }

    const {
      pages,
      theme
    } = authOptions;
    const authOnErrorPage = (pages === null || pages === void 0 ? void 0 : pages.error) && ((_req$query = req.query) === null || _req$query === void 0 ? void 0 : (_req$query$callbackUr = _req$query.callbackUrl) === null || _req$query$callbackUr === void 0 ? void 0 : _req$query$callbackUr.startsWith(pages.error));

    if (!(pages !== null && pages !== void 0 && pages.error) || authOnErrorPage) {
      if (authOnErrorPage) {
        _logger.default.error("AUTH_ON_ERROR_PAGE_ERROR", new Error(`The error page ${pages === null || pages === void 0 ? void 0 : pages.error} should not require authentication`));
      }

      const render = (0, _pages.default)({
        theme
      });
      return render.error({
        error: "configuration"
      });
    }

    return {
      redirect: `${pages.error}?error=Configuration`
    };
  }

  const {
    action,
    providerId,
    error,
    method = "GET"
  } = req;
  const {
    options,
    cookies
  } = await (0, _init.init)({
    authOptions,
    action,
    providerId,
    host: req.host,
    callbackUrl: (_req$body$callbackUrl = (_req$body = req.body) === null || _req$body === void 0 ? void 0 : _req$body.callbackUrl) !== null && _req$body$callbackUrl !== void 0 ? _req$body$callbackUrl : (_req$query2 = req.query) === null || _req$query2 === void 0 ? void 0 : _req$query2.callbackUrl,
    csrfToken: (_req$body2 = req.body) === null || _req$body2 === void 0 ? void 0 : _req$body2.csrfToken,
    cookies: req.cookies,
    isPost: method === "POST"
  });
  const sessionStore = new _cookie.SessionStore(options.cookies.sessionToken, req, options.logger);

  if (method === "GET") {
    const render = (0, _pages.default)({ ...options,
      query: req.query,
      cookies
    });
    const {
      pages
    } = options;

    switch (action) {
      case "providers":
        return await routes.providers(options.providers);

      case "session":
        {
          const session = await routes.session({
            options,
            sessionStore
          });
          if (session.cookies) cookies.push(...session.cookies);
          return { ...session,
            cookies
          };
        }

      case "csrf":
        return {
          headers: [{
            key: "Content-Type",
            value: "application/json"
          }],
          body: {
            csrfToken: options.csrfToken
          },
          cookies
        };

      case "signin":
        if (pages.signIn) {
          let signinUrl = `${pages.signIn}${pages.signIn.includes("?") ? "&" : "?"}callbackUrl=${encodeURIComponent(options.callbackUrl)}`;
          if (error) signinUrl = `${signinUrl}&error=${encodeURIComponent(error)}`;
          return {
            redirect: signinUrl,
            cookies
          };
        }

        return render.signin();

      case "signout":
        if (pages.signOut) return {
          redirect: pages.signOut,
          cookies
        };
        return render.signout();

      case "callback":
        if (options.provider) {
          const callback = await routes.callback({
            body: req.body,
            query: req.query,
            headers: req.headers,
            cookies: req.cookies,
            method,
            options,
            sessionStore
          });
          if (callback.cookies) cookies.push(...callback.cookies);
          return { ...callback,
            cookies
          };
        }

        break;

      case "verify-request":
        if (pages.verifyRequest) {
          return {
            redirect: pages.verifyRequest,
            cookies
          };
        }

        return render.verifyRequest();

      case "error":
        if (["Signin", "OAuthSignin", "OAuthCallback", "OAuthCreateAccount", "EmailCreateAccount", "Callback", "OAuthAccountNotLinked", "EmailSignin", "CredentialsSignin", "SessionRequired"].includes(error)) {
          return {
            redirect: `${options.url}/signin?error=${error}`,
            cookies
          };
        }

        if (pages.error) {
          return {
            redirect: `${pages.error}${pages.error.includes("?") ? "&" : "?"}error=${error}`,
            cookies
          };
        }

        return render.error({
          error: error
        });
    }
  } else if (method === "POST") {
    switch (action) {
      case "signin":
        if (options.csrfTokenVerified && options.provider) {
          const signin = await routes.signin({
            query: req.query,
            body: req.body,
            options
          });
          if (signin.cookies) cookies.push(...signin.cookies);
          return { ...signin,
            cookies
          };
        }

        return {
          redirect: `${options.url}/signin?csrf=true`,
          cookies
        };

      case "signout":
        if (options.csrfTokenVerified) {
          const signout = await routes.signout({
            options,
            sessionStore
          });
          if (signout.cookies) cookies.push(...signout.cookies);
          return { ...signout,
            cookies
          };
        }

        return {
          redirect: `${options.url}/signout?csrf=true`,
          cookies
        };

      case "callback":
        if (options.provider) {
          if (options.provider.type === "credentials" && !options.csrfTokenVerified) {
            return {
              redirect: `${options.url}/signin?csrf=true`,
              cookies
            };
          }

          const callback = await routes.callback({
            body: req.body,
            query: req.query,
            headers: req.headers,
            cookies: req.cookies,
            method,
            options,
            sessionStore
          });
          if (callback.cookies) cookies.push(...callback.cookies);
          return { ...callback,
            cookies
          };
        }

        break;

      case "_log":
        {
          if (authOptions.logger) {
            try {
              var _req$body3;

              const {
                code,
                level,
                ...metadata
              } = (_req$body3 = req.body) !== null && _req$body3 !== void 0 ? _req$body3 : {};

              _logger.default[level](code, metadata);
            } catch (error) {
              _logger.default.error("LOGGER_ERROR", error);
            }
          }

          return {};
        }

      case "session":
        {
          if (options.csrfTokenVerified) {
            var _req$body4;

            const session = await routes.session({
              options,
              sessionStore,
              newSession: (_req$body4 = req.body) === null || _req$body4 === void 0 ? void 0 : _req$body4.data,
              isUpdate: true
            });
            if (session.cookies) cookies.push(...session.cookies);
            return { ...session,
              cookies
            };
          }

          return {
            status: 400,
            body: {},
            cookies
          };
        }
    }
  }

  return {
    status: 400,
    body: `Error: This action with HTTP ${method} is not supported by NextAuth.js`
  };
}

let preparedAuthjsHandler;
let usedSecret;
function NuxtAuthHandler(nuxtAuthOptions) {
  const trustHostUserPreference = useTypedBackendConfig(useRuntimeConfig(), "authjs").trustHost;
  usedSecret = nuxtAuthOptions?.secret;
  if (!usedSecret) {
    {
      throw new Error(ERROR_MESSAGES.NO_SECRET);
    }
  }
  const options = defu(nuxtAuthOptions, {
    secret: usedSecret,
    logger: void 0,
    providers: [],
    // SAFETY: We trust host here because `getRequestURLFromH3Event` is responsible for producing a trusted URL
    trustHost: true,
    // AuthJS uses `/auth` as default, but we rely on `/api/auth` (same as in previous `next-auth`)
    basePath: "/api/auth"
    // Uncomment to enable framework-author specific functionality
    // raw: raw as typeof raw
  });
  if (preparedAuthjsHandler) {
    console.error("You setup the auth handler for a second time - this is likely undesired. Make sure that you only call `NuxtAuthHandler( ... )` once");
  }
  preparedAuthjsHandler = (req) => AuthHandler_1({ req, options });
  return eventHandler(async (event) => {
    const { res } = event.node;
    const nextRequest = await createRequestForAuthjs(event, trustHostUserPreference);
    const nextResult = await preparedAuthjsHandler(nextRequest);
    if (nextResult.status) {
      res.statusCode = nextResult.status;
    }
    nextResult.cookies?.forEach((cookie) => setCookieDeduped(event, cookie.name, cookie.value, cookie.options));
    nextResult.headers?.forEach((header) => appendHeaderDeduped(event, header.key, header.value));
    if (!nextResult.redirect) {
      return nextResult.body;
    }
    if (nextRequest.body?.json) {
      return { url: nextResult.redirect };
    }
    return await sendRedirect(event, nextResult.redirect);
  });
}
async function createRequestForAuthjs(event, trustHostUserPreference) {
  const nextRequest = {
    host: getRequestURLFromH3Event(event, trustHostUserPreference).origin,
    body: void 0,
    cookies: parseCookies(event),
    query: void 0,
    headers: getHeaders(event),
    method: event.method,
    providerId: void 0,
    error: void 0
  };
  const query = getQuery(event);
  const { action, providerId } = parseActionAndProvider(event);
  const error = query.error;
  if (Array.isArray(error)) {
    throw createError({ statusCode: 400, statusMessage: "Error query parameter can only appear once" });
  }
  const body = isMethod(event, ["PATCH", "POST", "PUT", "DELETE"]) ? await readBody(event) : void 0;
  return {
    ...nextRequest,
    body,
    query,
    action,
    providerId,
    error: error ? String(error) : void 0
  };
}
function getRequestURLFromH3Event(event, trustHost) {
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  const base = getRequestBaseFromH3Event(event, trustHost);
  return new URL(path, base);
}
function getRequestBaseFromH3Event(event, trustHost) {
  if (trustHost) {
    const host = getRequestHost(event, { xForwardedHost: trustHost });
    const protocol = getRequestProtocol(event);
    return `${protocol}://${host}`;
  }
  const origin = getServerOrigin(event);
  return origin;
}
const SUPPORTED_ACTIONS = ["providers", "session", "csrf", "signin", "signout", "callback", "verify-request", "error", "_log"];
function parseActionAndProvider({ context }) {
  const params = context.params?._?.split("/");
  if (!params || ![1, 2].includes(params.length)) {
    throw createError({ statusCode: 400, statusMessage: `Invalid path used for auth-endpoint. Supply either one path parameter (e.g., \`/api/auth/session\`) or two (e.g., \`/api/auth/signin/github\` after the base path (in previous examples base path was: \`/api/auth/\`. Received \`${params}\`` });
  }
  const [unvalidatedAction, providerId] = params;
  const action = SUPPORTED_ACTIONS.find((action2) => action2 === unvalidatedAction);
  if (!action) {
    throw createError({ statusCode: 400, statusMessage: `Called endpoint with unsupported action ${unvalidatedAction}. Only the following actions are supported: ${SUPPORTED_ACTIONS.join(", ")}` });
  }
  return { action, providerId };
}
function appendHeaderDeduped(event, name, value) {
  let current = getResponseHeader(event, name);
  if (!current) {
    setResponseHeader(event, name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  if (current.includes(value)) {
    return;
  }
  current.push(value);
  setResponseHeader(event, name, current);
}
function setCookieDeduped(event, name, value, serializeOptions) {
  let setCookiesHeader = getResponseHeader(event, "set-cookie");
  if (setCookiesHeader) {
    if (!Array.isArray(setCookiesHeader)) {
      setCookiesHeader = [setCookiesHeader.toString()];
    }
    const filterBy = `${name}=`;
    setCookiesHeader = setCookiesHeader.filter((cookie) => !cookie.startsWith(filterBy));
    setResponseHeader(event, "set-cookie", setCookiesHeader);
  }
  setCookie(event, name, value, serializeOptions);
}

var _a, _b;
const CognitoProvider = typeof _default$2 === "function" ? _default$2 : ((_a = _default$2) == null ? void 0 : _a.default) || _default$2;
const CredentialsProvider = typeof _default$1 === "function" ? _default$1 : ((_b = _default$1) == null ? void 0 : _b.default) || _default$1;
function calculateSecretHash(username, clientId, clientSecret) {
  return crypto__default.createHmac("sha256", clientSecret).update(username + clientId).digest("base64");
}
async function refreshCognitoToken(refreshToken, email) {
  const clientId = process.env.COGNITO_CLIENT_ID || "4ef8k4tofjj4ounvo8nf7d9pep";
  const clientSecret = process.env.COGNITO_CLIENT_SECRET || "";
  const issuer = process.env.COGNITO_ISSUER || "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_trquL61F2";
  const region = process.env.COGNITO_REGION || issuer.split(".")[1] || "us-east-1";
  const authParameters = {
    REFRESH_TOKEN: refreshToken
  };
  if (clientSecret && email) {
    authParameters.SECRET_HASH = calculateSecretHash(
      email,
      clientId,
      clientSecret
    );
  }
  try {
    const res = await fetch(`https://cognito-idp.${region}.amazonaws.com/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-amz-json-1.1",
        "X-Amz-Target": "AWSCognitoIdentityProviderService.InitiateAuth"
      },
      body: JSON.stringify({
        AuthFlow: "REFRESH_TOKEN_AUTH",
        ClientId: clientId,
        AuthParameters: authParameters
      })
    });
    const data = await res.json();
    if (data.AuthenticationResult) {
      return {
        idToken: data.AuthenticationResult.IdToken,
        accessToken: data.AuthenticationResult.AccessToken
      };
    }
  } catch (err) {
    console.error("Failed to refresh Cognito token:", err);
  }
  return null;
}
const _____ = NuxtAuthHandler({
  providers: [
    CognitoProvider({
      clientId: process.env.COGNITO_CLIENT_ID || "4ef8k4tofjj4ounvo8nf7d9pep",
      clientSecret: process.env.COGNITO_CLIENT_SECRET || "",
      issuer: process.env.COGNITO_ISSUER || "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_trquL61F2"
    }),
    CredentialsProvider({
      id: "credentials",
      name: "CognitoCredentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
        mfaCode: { label: "MfaCode", type: "text" },
        mfaSession: { label: "MfaSession", type: "text" },
        mfaChallenge: { label: "MfaChallenge", type: "text" }
      },
      async authorize(credentials) {
        if (!(credentials == null ? void 0 : credentials.email)) {
          throw new Error("Email es requerido");
        }
        const clientId = process.env.COGNITO_CLIENT_ID || "4ef8k4tofjj4ounvo8nf7d9pep";
        const clientSecret = process.env.COGNITO_CLIENT_SECRET || "";
        const issuer = process.env.COGNITO_ISSUER || "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_trquL61F2";
        const region = process.env.COGNITO_REGION || issuer.split(".")[1] || "us-east-1";
        try {
          let responseData;
          if (credentials.mfaCode && credentials.mfaSession && credentials.mfaChallenge) {
            const challengeResponses = {
              USERNAME: credentials.email
            };
            if (credentials.mfaChallenge === "SMS_MFA") {
              challengeResponses.SMS_MFA_CODE = credentials.mfaCode;
            } else if (credentials.mfaChallenge === "SOFTWARE_TOKEN_MFA") {
              challengeResponses.SOFTWARE_TOKEN_MFA_CODE = credentials.mfaCode;
            } else {
              challengeResponses.ANSWER = credentials.mfaCode;
            }
            if (clientSecret) {
              challengeResponses.SECRET_HASH = calculateSecretHash(
                credentials.email,
                clientId,
                clientSecret
              );
            }
            const response = await fetch(
              `https://cognito-idp.${region}.amazonaws.com/`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-amz-json-1.1",
                  "X-Amz-Target": "AWSCognitoIdentityProviderService.RespondToAuthChallenge"
                },
                body: JSON.stringify({
                  ClientId: clientId,
                  ChallengeName: credentials.mfaChallenge,
                  Session: credentials.mfaSession,
                  ChallengeResponses: challengeResponses
                })
              }
            );
            responseData = await response.json();
            if (!response.ok) {
              const errorCode = responseData.__type ? responseData.__type.split("#")[1] : "MFAError";
              throw new Error(
                JSON.stringify({
                  code: errorCode,
                  message: translateCognitoError(
                    errorCode,
                    responseData.message || "C\xF3digo de MFA incorrecto o expirado"
                  )
                })
              );
            }
          } else {
            if (!credentials.password) {
              throw new Error("Contrase\xF1a es requerida");
            }
            const authParams = {
              USERNAME: credentials.email,
              PASSWORD: credentials.password
            };
            if (clientSecret) {
              authParams.SECRET_HASH = calculateSecretHash(
                credentials.email,
                clientId,
                clientSecret
              );
            }
            const response = await fetch(
              `https://cognito-idp.${region}.amazonaws.com/`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-amz-json-1.1",
                  "X-Amz-Target": "AWSCognitoIdentityProviderService.InitiateAuth"
                },
                body: JSON.stringify({
                  AuthFlow: "USER_PASSWORD_AUTH",
                  ClientId: clientId,
                  AuthParameters: authParams
                })
              }
            );
            responseData = await response.json();
            if (!response.ok) {
              const errorCode = responseData.__type ? responseData.__type.split("#")[1] : "AuthError";
              throw new Error(
                JSON.stringify({
                  code: errorCode,
                  message: translateCognitoError(
                    errorCode,
                    responseData.message || "Usuario o contrase\xF1a incorrectos"
                  )
                })
              );
            }
          }
          if (responseData.ChallengeName) {
            throw new Error(
              JSON.stringify({
                code: "ChallengeRequired",
                challengeName: responseData.ChallengeName,
                session: responseData.Session,
                email: credentials.email
              })
            );
          }
          const authResult = responseData.AuthenticationResult;
          if (authResult) {
            return {
              id: credentials.email,
              email: credentials.email,
              name: credentials.email.split("@")[0],
              idToken: authResult.IdToken,
              accessToken: authResult.AccessToken,
              refreshToken: authResult.RefreshToken
            };
          }
          return null;
        } catch (error) {
          return {
            id: "error",
            error: error.message
          };
        }
      }
    })
  ],
  callbacks: {
    async signIn({ user }) {
      if (user && user.error) {
        throw new Error(user.error);
      }
      if (user && user.idToken) {
        try {
          const payloadBase64 = user.idToken.split(".")[1];
          const payload = JSON.parse(
            Buffer.from(payloadBase64, "base64").toString("ascii")
          );
          const userId = payload.sub || user.id;
          const rawGroups = payload["cognito:groups"] || payload.groups || [];
          const groups = Array.isArray(rawGroups) ? rawGroups : typeof rawGroups === "string" ? [rawGroups] : [];
          const rawScope = payload.scope || payload.scp || "";
          const scopes = Array.isArray(rawScope) ? rawScope : typeof rawScope === "string" ? rawScope.split(" ") : [];
          const customRole = (payload["custom:role"] || payload["custom:tipoUsuario"] || payload["custom:groups"] || "").toString().toUpperCase();
          let cognitoRole = "";
          if (groups.some(
            (g) => g.toUpperCase() === "ADMIN" || g.toUpperCase().includes("ADMIN")
          ) || scopes.some((s) => s.includes("admin")) || customRole === "ADMIN")
            cognitoRole = "ADMIN";
          else if (groups.some(
            (g) => g.toUpperCase() === "MODERATOR" || g.toUpperCase().includes("MOD")
          ) || scopes.some(
            (s) => s.includes("moderator") || s.includes("mod")
          ) || customRole === "MODERATOR")
            cognitoRole = "MODERATOR";
          else if (groups.some(
            (g) => g.toUpperCase() === "ORGANIZACION" || g.toUpperCase() === "EMPRESA" || g.toUpperCase() === "COMPANY"
          ) || scopes.some(
            (s) => s.includes("organization") || s.includes("empresa")
          ) || customRole === "ORGANIZACION" || customRole === "EMPRESA" || customRole === "COMPANY")
            cognitoRole = "ORGANIZACION";
          else if (groups.some(
            (g) => g.toUpperCase() === "CANDIDATO" || g.toUpperCase() === "CANDIDATE"
          ) || scopes.some(
            (s) => s.includes("candidate") || s.includes("candidato")
          ) || customRole === "CANDIDATO" || customRole === "CANDIDATE")
            cognitoRole = "CANDIDATO";
          const config = useRuntimeConfig();
          const profile = await $fetch(
            `${config.public.apiUrl}/profile/${userId}`
          ).catch(() => null);
          if (profile) {
            if (profile.estadoCuenta === "SUSPENDIDA") {
              throw new Error(
                "Su cuenta ha sido suspendida definitivamente por infracci\xF3n."
              );
            }
            if (profile.estadoCuenta === "SUSPENDIDA_TEMPORAL") {
              const fin = profile.fechaFinSuspension ? new Date(profile.fechaFinSuspension) : null;
              if (fin && /* @__PURE__ */ new Date() < fin) {
                const diasRestantes = Math.ceil(
                  (fin.getTime() - (/* @__PURE__ */ new Date()).getTime()) / (1e3 * 3600 * 24)
                );
                throw new Error(
                  `Su cuenta est\xE1 suspendida temporalmente. Restan ${diasRestantes} d\xEDas.`
                );
              } else {
                await $fetch(`${config.public.apiUrl}/profile/${userId}`, {
                  method: "POST",
                  headers: {
                    "x-user-id": userId,
                    "x-user-role": cognitoRole || "CANDIDATO"
                  },
                  body: {
                    estadoCuenta: "ACTIVO",
                    fechaFinSuspension: null
                  }
                }).catch(() => null);
              }
            }
            if (cognitoRole && cognitoRole !== "CANDIDATO" && (profile.tipoUsuario === "PENDIENTE" || profile.estadoCuenta === "PENDIENTE_ROL" || profile.tipoUsuario !== cognitoRole)) {
              await $fetch(`${config.public.apiUrl}/profile/${userId}`, {
                method: "POST",
                headers: {
                  "x-user-id": userId,
                  "x-user-role": cognitoRole
                },
                body: {
                  tipoUsuario: cognitoRole,
                  estadoCuenta: "ACTIVO"
                }
              }).catch(() => null);
              profile.tipoUsuario = cognitoRole;
              profile.estadoCuenta = "ACTIVO";
            }
            if (profile.estadoCuenta === "PENDIENTE_ROL" || profile.tipoUsuario === "PENDIENTE" || customRole === "BLANK" || customRole === "UNASSIGNED" || customRole.includes("PENDING") || customRole.includes("ASPIRANT")) {
              const isMod = profile.solicitudRol === "MODERATOR" || customRole.includes("MOD") || profile.biografia && profile.biografia.includes("Moderador");
              const roleTitle = isMod ? "de moderaci\xF3n" : "administrativo";
              throw new Error(
                JSON.stringify({
                  code: "AccountInactive",
                  message: `Su cuenta se encuentra en estado inactivo neutral. El titular de AWS Cognito debe autorizar y asignar expl\xEDcitamente el rol ${roleTitle} para habilitar el acceso.`
                })
              );
            }
          }
          if (!cognitoRole) {
            if (customRole === "BLANK" || customRole === "UNASSIGNED" || customRole.includes("PENDING") || customRole.includes("ASPIRANT")) {
              const isMod = customRole.includes("MOD");
              throw new Error(
                JSON.stringify({
                  code: "AccountInactive",
                  message: `Su cuenta se encuentra en estado inactivo neutral. El titular de AWS Cognito debe autorizar y asignar expl\xEDcitamente el rol ${isMod ? "de moderaci\xF3n" : "administrativo"} para habilitar el acceso.`
                })
              );
            }
          }
        } catch (e) {
          if (e.message && (e.message.includes("suspendida") || e.message.includes("AccountInactive") || e.message.includes("inactivo") || e.message.includes("neutral") || e.message.includes("autorizar") || e.message.includes("Cognito") || e.message.includes("PENDIENTE"))) {
            throw e;
          }
          console.error("Error checking account status on login:", e);
        }
      }
      return true;
    },
    async redirect({ url, baseUrl }) {
      if (!url || url === "undefined") {
        return baseUrl;
      }
      if (url.startsWith("/")) {
        return `${baseUrl}${url}`;
      }
      try {
        const parsedUrl = new URL(url);
        if (parsedUrl.origin === baseUrl) {
          return url;
        }
      } catch (e) {
      }
      return baseUrl;
    },
    async jwt({ token, user, account }) {
      if (account) {
        token.idToken = account.id_token;
        token.accessToken = account.access_token;
      }
      if (user && !user.error) {
        token.email = user.email;
        token.idToken = user.idToken || token.idToken;
        token.accessToken = user.accessToken || token.accessToken;
        token.refreshToken = user.refreshToken || token.refreshToken;
        token.name = user.name || token.name;
      }
      if (token.idToken) {
        try {
          const payloadBase64 = token.idToken.split(".")[1];
          if (payloadBase64) {
            const payloadJson = Buffer.from(payloadBase64, "base64").toString(
              "ascii"
            );
            const payload = JSON.parse(payloadJson);
            token.id = payload.sub;
            if (payload.name) {
              token.name = payload.name;
            }
            const rawGroups = payload["cognito:groups"] || payload.groups || [];
            const groups = Array.isArray(rawGroups) ? rawGroups : typeof rawGroups === "string" ? [rawGroups] : [];
            const rawScope = payload.scope || payload.scp || "";
            const scopes = Array.isArray(rawScope) ? rawScope : typeof rawScope === "string" ? rawScope.split(" ") : [];
            const customRole = (payload["custom:role"] || payload["custom:tipoUsuario"] || payload["custom:groups"] || "").toString().toUpperCase();
            if (groups.some(
              (g) => g.toUpperCase() === "ADMIN" || g.toUpperCase().includes("ADMIN")
            ) || scopes.some((s) => s.includes("admin")) || customRole === "ADMIN") {
              token.tipoUsuario = "ADMIN";
            } else if (groups.some(
              (g) => g.toUpperCase() === "MODERATOR" || g.toUpperCase().includes("MOD")
            ) || scopes.some(
              (s) => s.includes("moderator") || s.includes("mod")
            ) || customRole === "MODERATOR") {
              token.tipoUsuario = "MODERATOR";
            } else if (groups.some(
              (g) => g.toUpperCase() === "ORGANIZACION" || g.toUpperCase() === "EMPRESA" || g.toUpperCase() === "COMPANY"
            ) || scopes.some(
              (s) => s.includes("organization") || s.includes("empresa")
            ) || customRole === "ORGANIZACION" || customRole === "EMPRESA" || customRole === "COMPANY") {
              token.tipoUsuario = "ORGANIZACION";
            } else if (groups.some(
              (g) => g.toUpperCase() === "CANDIDATO" || g.toUpperCase() === "CANDIDATE"
            ) || scopes.some(
              (s) => s.includes("candidate") || s.includes("candidato")
            ) || customRole === "CANDIDATO" || customRole === "CANDIDATE") {
              token.tipoUsuario = "CANDIDATO";
            } else if (customRole === "BLANK" || customRole === "UNASSIGNED" || customRole === "PENDIENTE" || customRole.includes("PENDING") || customRole.includes("ASPIRANT")) {
              token.tipoUsuario = "PENDIENTE";
            } else {
              token.tipoUsuario = "PENDIENTE";
            }
            const nowInSeconds = Math.floor(Date.now() / 1e3);
            if (payload.exp && payload.exp - nowInSeconds < 300 && token.refreshToken) {
              console.log(
                "Cognito idToken is expired or expiring soon. Refreshing via REFRESH_TOKEN_AUTH..."
              );
              const refreshed = await refreshCognitoToken(
                token.refreshToken,
                token.email
              );
              if (refreshed == null ? void 0 : refreshed.idToken) {
                token.idToken = refreshed.idToken;
                if (refreshed.accessToken)
                  token.accessToken = refreshed.accessToken;
                console.log("Successfully refreshed Cognito idToken!");
              }
            }
          }
        } catch (e) {
          console.error(
            "Error decoding/refreshing Cognito IdToken payload:",
            e
          );
        }
      }
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.idToken = token.idToken;
        session.accessToken = token.accessToken;
        session.refreshToken = token.refreshToken;
        session.user.id = token.id;
        session.user.tipoUsuario = token.tipoUsuario;
        session.user.role = token.tipoUsuario;
        session.user.name = token.name;
      }
      return session;
    }
  },
  pages: {
    signIn: "/login",
    error: "/login"
  },
  jwt: {
    secret: process.env.NEXTAUTH_SECRET || process.env.NUXT_AUTH_SECRET || "jobnet-super-secret-key-prod-2026",
    async encode({ token, secret }) {
      var _a2;
      if (!token) return "";
      const hkdfModule = await Promise.resolve().then(function () { return esm; });
      const hkdfFn = hkdfModule.hkdf || ((_a2 = hkdfModule.default) == null ? void 0 : _a2.hkdf) || hkdfModule.default;
      const joseModule = await Promise.resolve().then(function () { return esm$1; });
      const EncryptJWT = joseModule.EncryptJWT;
      const keySecret = secret || "jobnet-super-secret-key-prod-2026";
      const encryptionSecret = await hkdfFn(
        "sha256",
        keySecret,
        "",
        "NextAuth.js Generated Encryption Key",
        32
      );
      return await new EncryptJWT({ ...token }).setProtectedHeader({ alg: "dir", enc: "A256GCM" }).setIssuedAt().setExpirationTime("30d").encrypt(encryptionSecret);
    },
    async decode({ token, secret }) {
      var _a2;
      if (!token) return null;
      const hkdfModule = await Promise.resolve().then(function () { return esm; });
      const hkdfFn = hkdfModule.hkdf || ((_a2 = hkdfModule.default) == null ? void 0 : _a2.hkdf) || hkdfModule.default;
      const joseModule = await Promise.resolve().then(function () { return esm$1; });
      const jwtDecrypt = joseModule.jwtDecrypt;
      const keySecret = secret || "jobnet-super-secret-key-prod-2026";
      const encryptionSecret = await hkdfFn(
        "sha256",
        keySecret,
        "",
        "NextAuth.js Generated Encryption Key",
        32
      );
      try {
        const { payload } = await jwtDecrypt(token, encryptionSecret);
        return payload;
      } catch (e) {
        return null;
      }
    }
  },
  secret: process.env.NEXTAUTH_SECRET || process.env.NUXT_AUTH_SECRET || "jobnet-super-secret-key-prod-2026"
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
