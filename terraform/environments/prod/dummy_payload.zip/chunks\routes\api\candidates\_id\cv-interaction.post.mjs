import { d as defineEventHandler, H as getRouterParam, r as readBody, e as useRuntimeConfig, f as getHeader } from '../../../../_/nitro.mjs';
import fs from 'fs';
import path from 'path';
import webpush from 'web-push';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const DEFAULT_VAPID_PUBLIC_KEY = "BOIrktuQCHHiOWcKICA7YEwdKJf8WNYCmBS_PI338wnaB9VqXPQfCRwTN5NLYokujXBp5pdD83av6DACG2rAYok";
const DEFAULT_VAPID_PRIVATE_KEY = "oJXO_P5wuj45JaC8taPC1E3pPR8Hu1zi_kAiv5yAaNg";
const DEFAULT_VAPID_SUBJECT = "mailto:contacto@franciscojgh.com";
webpush.setVapidDetails(
  process.env.VAPID_SUBJECT || DEFAULT_VAPID_SUBJECT,
  process.env.VAPID_PUBLIC_KEY || DEFAULT_VAPID_PUBLIC_KEY,
  process.env.VAPID_PRIVATE_KEY || DEFAULT_VAPID_PRIVATE_KEY
);
const cvInteraction_post = defineEventHandler(async (event) => {
  var _a;
  const candidateId = getRouterParam(event, "id");
  if (!candidateId) {
    return { error: "Missing candidate id" };
  }
  const body = await readBody(event) || {};
  const config = useRuntimeConfig();
  if ((_a = config.public) == null ? void 0 : _a.apiUrl) {
    const authHeader = getHeader(event, "authorization");
    const userIdHeader = getHeader(event, "x-user-id");
    const userRoleHeader = getHeader(event, "x-user-role");
    const forwardHeaders = {};
    if (authHeader) forwardHeaders["Authorization"] = authHeader;
    if (userIdHeader) forwardHeaders["x-user-id"] = userIdHeader;
    if (userRoleHeader) forwardHeaders["x-user-role"] = userRoleHeader;
    try {
      const backendRes = await $fetch(
        `${config.public.apiUrl}/profile/${candidateId}/cv-interaction`,
        {
          method: "POST",
          body,
          headers: forwardHeaders
        }
      );
      if (backendRes) {
        return backendRes;
      }
    } catch (backendErr) {
      console.warn(
        "[Nitro cv-interaction] Backend forwarding returned error:",
        (backendErr == null ? void 0 : backendErr.message) || backendErr
      );
    }
  }
  const action = (body.action || "VIEW").toUpperCase();
  const companyName = body.companyName || "Una organizaci\xF3n reclutadora";
  const recruiterName = body.recruiterName || "";
  const vacancyTitle = body.vacancyTitle || "";
  const recruiterEntity = recruiterName ? `${recruiterName} (${companyName})` : companyName;
  const isDownload = action === "DOWNLOAD";
  const title = isDownload ? "Tu CV ha sido descargado" : "Tu CV ha sido visualizado";
  const contextText = vacancyTitle && vacancyTitle !== "Vacante seleccionada" ? `para la vacante "${vacancyTitle}"` : `desde tu perfil profesional`;
  const message = isDownload ? `${recruiterEntity} ha descargado tu Curr\xEDculum Vitae ${contextText}.` : `${recruiterEntity} acaba de abrir y visualizar tu Curr\xEDculum Vitae ${contextText}.`;
  let sentPush = false;
  try {
    const subPath = path.resolve(
      process.cwd(),
      "..",
      ".push-subscription.json"
    );
    if (fs.existsSync(subPath)) {
      const subRaw = fs.readFileSync(subPath, "utf-8");
      const subscription = JSON.parse(subRaw);
      if ((subscription == null ? void 0 : subscription.endpoint) && (subscription == null ? void 0 : subscription.keys)) {
        await webpush.sendNotification(
          subscription,
          JSON.stringify({
            title,
            body: message,
            icon: "/logotipo.svg",
            badge: "/logotipo.svg",
            url: "/candidate/my-applications",
            data: {
              type: "cv_interaction",
              candidateId,
              action,
              companyName,
              timestamp: (/* @__PURE__ */ new Date()).toISOString()
            }
          })
        );
        sentPush = true;
      }
    }
  } catch (err) {
    console.warn(
      "[CV Interaction Push] Could not send local webpush notification:",
      (err == null ? void 0 : err.message) || err
    );
  }
  return {
    success: true,
    candidateId,
    action,
    title,
    message,
    sentPush,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
});

export { cvInteraction_post as default };
//# sourceMappingURL=cv-interaction.post.mjs.map
