import { d as defineEventHandler, r as readBody, l as createError, C as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const verify_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { accessToken, userCode } = body || {};
  if (!accessToken || !userCode) {
    throw createError({
      statusCode: 400,
      statusMessage: "AccessToken y C\xF3digo MFA requeridos"
    });
  }
  try {
    const verifyResult = await callCognito("VerifySoftwareToken", {
      AccessToken: accessToken,
      UserCode: userCode,
      FriendlyDeviceName: "JobNetAuthenticatorApp"
    });
    if (verifyResult.Status !== "SUCCESS") {
      throw createError({
        statusCode: 400,
        statusMessage: "El c\xF3digo de verificaci\xF3n ingresado no es v\xE1lido"
      });
    }
    await callCognito("SetUserMFAPreference", {
      AccessToken: accessToken,
      SoftwareTokenMfaSettings: {
        Enabled: true,
        PreferredMfa: true
      }
    });
    return {
      success: true,
      status: verifyResult.Status
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al verificar y activar MFA en Cognito",
      data: error.data || {}
    });
  }
});

export { verify_post as default };
//# sourceMappingURL=verify.post.mjs.map
