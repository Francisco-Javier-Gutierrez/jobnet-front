import { d as defineEventHandler, H as getRouterParam, e as useRuntimeConfig, f as getHeader, l as createError, r as readBody } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const auditDictum_post = defineEventHandler(async (event) => {
  const incidentId = getRouterParam(event, "id");
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = (getHeader(event, "x-user-role") || "MODERATOR").toUpperCase();
  const userIdHeader = getHeader(event, "x-user-id");
  const userNameHeader = getHeader(event, "x-user-name");
  const userEmailHeader = getHeader(event, "x-user-email");
  if (userRoleHeader !== "MODERATOR" && userRoleHeader !== "MODERADOR" && userRoleHeader !== "ADMIN") {
    throw createError({
      statusCode: 403,
      statusMessage: "Acceso denegado: Emisi\xF3n de dictamen de auditor\xEDa exclusiva para Moderadores."
    });
  }
  const body = await readBody(event).catch(() => ({}));
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/moderator/incidents/${incidentId}/audit-dictum`,
      {
        method: "POST",
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader,
          ...userIdHeader ? { "x-user-id": userIdHeader } : {},
          ...userNameHeader ? { "x-user-name": userNameHeader } : {},
          ...userEmailHeader ? { "x-user-email": userEmailHeader } : {}
        },
        body
      }
    );
    return backendData;
  } catch (error) {
    throw createError({
      statusCode: (error == null ? void 0 : error.statusCode) || 500,
      statusMessage: (error == null ? void 0 : error.message) || "Error al emitir dictamen de auditor\xEDa."
    });
  }
});

export { auditDictum_post as default };
//# sourceMappingURL=audit-dictum.post.mjs.map
