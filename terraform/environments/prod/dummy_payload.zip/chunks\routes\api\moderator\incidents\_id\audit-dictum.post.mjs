import { d as defineEventHandler, J as getRouterParam, e as useRuntimeConfig, f as getHeader, o as createError, r as readBody, K as MOCK_INCIDENTS } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const auditDictum_post = defineEventHandler(async (event) => {
  const incidentId = getRouterParam(event, "id");
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = (getHeader(event, "x-user-role") || "MODERATOR").toUpperCase();
  if (userRoleHeader !== "MODERATOR" && userRoleHeader !== "MODERADOR" && userRoleHeader !== "ADMIN") {
    throw createError({
      statusCode: 403,
      statusMessage: "Acceso denegado: Emisi\xF3n de dictamen de auditor\xEDa exclusiva para Moderadores."
    });
  }
  const body = await readBody(event).catch(() => ({}));
  const { dictum, notes } = body;
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/moderator/incidents/${incidentId}/audit-dictum`,
      {
        method: "POST",
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader
        },
        body
      }
    );
    if (backendData == null ? void 0 : backendData.success) {
      return backendData;
    }
  } catch {
  }
  const incident = MOCK_INCIDENTS.find((i) => i.id === incidentId);
  if (incident) {
    incident.estatus = "RESUELTO";
    incident.status = "RESUELTO";
    incident.auditState = "AUDIT_CONCLUDED";
    incident.auditDictum = dictum;
    incident.auditDictumNotes = notes;
    incident.supervisionStatus = "CONCLUDED";
  }
  return {
    success: true,
    message: "Dictamen de auditor\xEDa emitido exitosamente. Expediente concluido y partes notificadas.",
    incidentId,
    dictum
  };
});

export { auditDictum_post as default };
//# sourceMappingURL=audit-dictum.post.mjs.map
