import { d as defineEventHandler, e as useRuntimeConfig, g as getQuery } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const profiles = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/profiles`, {
      query
    });
    if (Array.isArray(data)) return data;
  } catch (error) {
    console.warn("Failed to fetch profiles from backend API:", error == null ? void 0 : error.message);
  }
  return [];
});

export { profiles as default };
//# sourceMappingURL=profiles.mjs.map
