import { y as defineEventHandler, e as useRuntimeConfig, i as getQuery, D as MOCK_COMPANIES, F as MOCK_CANDIDATE_DEMO } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const profiles = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/profiles`, {
      query
    });
    if (Array.isArray(data) && data.length > 0) return data;
  } catch (error) {
  }
  if (query.tipoUsuario === "ORGANIZACION" || query.tipoUsuario === "EMPRESA") {
    let list = [...MOCK_COMPANIES];
    if (query.q) {
      const q = String(query.q).toLowerCase();
      list = list.filter(
        (c) => {
          var _a, _b, _c;
          return ((_a = c.nombre) == null ? void 0 : _a.toLowerCase().includes(q)) || ((_b = c.nombreComercial) == null ? void 0 : _b.toLowerCase().includes(q)) || ((_c = c.sector) == null ? void 0 : _c.toLowerCase().includes(q));
        }
      );
    }
    return list;
  }
  return [...MOCK_COMPANIES, MOCK_CANDIDATE_DEMO];
});

export { profiles as default };
//# sourceMappingURL=profiles.mjs.map
