import { y as defineEventHandler, e as useRuntimeConfig } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const profiles = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  try {
    const data = await $fetch(`${config.public.apiUrl}/profiles`);
    return data;
  } catch (error) {
    console.error("Error fetching profiles from AWS backend:", error);
    return [];
  }
});

export { profiles as default };
//# sourceMappingURL=profiles.mjs.map
