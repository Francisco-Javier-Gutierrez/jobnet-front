import { d as defineEventHandler, H as getRouterParam, e as useRuntimeConfig, f as getHeader, l as createError } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const auditChat_get = defineEventHandler(async (event) => {
  const incidentId = getRouterParam(event, "id");
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = (getHeader(event, "x-user-role") || "MODERATOR").toUpperCase();
  const userIdHeader = getHeader(event, "x-user-id");
  if (userRoleHeader !== "MODERATOR" && userRoleHeader !== "MODERADOR" && userRoleHeader !== "ADMIN") {
    throw createError({
      statusCode: 403,
      statusMessage: "Acceso denegado: Acceso a historial de auditor\xEDa exclusivo para Moderadores."
    });
  }
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/moderator/incidents/${incidentId}/audit-chat`,
      {
        method: "GET",
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader,
          ...userIdHeader ? { "x-user-id": userIdHeader } : {}
        }
      }
    );
    if ((backendData == null ? void 0 : backendData.success) && Array.isArray(backendData == null ? void 0 : backendData.messages)) {
      return backendData;
    }
  } catch (err) {
    console.warn(
      `Could not fetch audit-chat for incident ${incidentId}:`,
      err == null ? void 0 : err.message
    );
  }
  return {
    success: true,
    incidentId,
    messages: []
  };
});

export { auditChat_get as default };
//# sourceMappingURL=audit-chat.get.mjs.map
