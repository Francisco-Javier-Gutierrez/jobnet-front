import { d as defineEventHandler, r as readBody, l as createError, C as callCognito } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const changePassword_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { oldPassword, newPassword, accessToken } = body || {};
  if (!accessToken) {
    throw createError({
      statusCode: 401,
      statusMessage: "No est\xE1s autenticado o falta el token de acceso."
    });
  }
  if (!oldPassword || !newPassword) {
    throw createError({
      statusCode: 400,
      statusMessage: "La contrase\xF1a actual y la nueva son requeridas."
    });
  }
  try {
    const result = await callCognito("ChangePassword", {
      PreviousPassword: oldPassword,
      ProposedPassword: newPassword,
      AccessToken: accessToken
    });
    return {
      success: true,
      message: "Contrase\xF1a actualizada exitosamente."
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al cambiar la contrase\xF1a en Cognito",
      data: error.data || {}
    });
  }
});

export { changePassword_post as default };
//# sourceMappingURL=change-password.post.mjs.map
