import { d as defineEventHandler, r as readBody, o as createError, C as getCognitoConfig, D as calculateSecretHash, F as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const resetPassword_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, code, newPassword } = body;
  if (!email || !code || !newPassword) {
    throw createError({
      statusCode: 400,
      statusMessage: "Todos los campos (email, code, newPassword) son obligatorios"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const resetParams = {
    ClientId: clientId,
    Username: email,
    ConfirmationCode: code,
    Password: newPassword
  };
  if (clientSecret) {
    resetParams.SecretHash = calculateSecretHash(email, clientId, clientSecret);
  }
  try {
    await callCognito("ConfirmForgotPassword", resetParams);
    return {
      success: true,
      message: "Contrase\xF1a restablecida con \xE9xito"
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al restablecer la contrase\xF1a",
      data: error.data || {}
    });
  }
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
