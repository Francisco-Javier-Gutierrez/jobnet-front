import { d as defineEventHandler, g as getQuery, e as useRuntimeConfig, f as getHeader } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const analytics_get = defineEventHandler(async (event) => {
  const query = getQuery(event);
  const region = query.region || "ALL";
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = getHeader(event, "x-user-role") || "ADMIN";
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/admin/analytics`,
      {
        method: "GET",
        params: { region },
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader
        }
      }
    );
    if ((backendData == null ? void 0 : backendData.success) && (backendData == null ? void 0 : backendData.data)) {
      return backendData;
    }
  } catch (err) {
    console.warn(
      "Failed to fetch admin analytics from backend API:",
      err == null ? void 0 : err.message
    );
  }
  return {
    success: true,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    data: {
      regions: ["Todas las Regiones"],
      selectedRegion: region,
      topSkills: [],
      monthlyOrganizations: [],
      applicationRate: {
        averagePerJob: 0,
        totalApplications: 0,
        totalJobs: 0,
        byModality: {
          Remoto: 0,
          H\u00EDbrido: 0,
          Presencial: 0
        },
        distribution: []
      },
      anomalies: [],
      kpis: {
        totalVacancies: 0,
        totalOrganizations: 0,
        verifiedOrganizations: 0,
        totalApplications: 0,
        averageApplicationsPerJob: 0,
        topSkillName: "N/A",
        topSkillCount: 0,
        monthlyGrowthRate: "0%",
        activeAnomaliesCount: 0
      }
    }
  };
});

export { analytics_get as default };
//# sourceMappingURL=analytics.get.mjs.map
