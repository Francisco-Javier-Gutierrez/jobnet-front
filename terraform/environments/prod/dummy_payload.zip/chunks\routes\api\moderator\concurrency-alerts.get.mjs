import { d as defineEventHandler, e as useRuntimeConfig, f as getHeader, l as createError } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const concurrencyAlerts_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const authHeader = getHeader(event, "authorization");
  const userRoleHeader = (getHeader(event, "x-user-role") || "MODERATOR").toUpperCase();
  if (userRoleHeader !== "MODERATOR" && userRoleHeader !== "MODERADOR" && userRoleHeader !== "ADMIN") {
    throw createError({
      statusCode: 403,
      statusMessage: "Acceso denegado: Panel de alertas de concurrencia exclusivo para Moderadores de Comunidad."
    });
  }
  try {
    const backendData = await $fetch(
      `${config.public.apiUrl}/moderator/concurrency-alerts`,
      {
        method: "GET",
        headers: {
          ...authHeader ? { Authorization: authHeader } : {},
          "x-user-role": userRoleHeader
        }
      }
    );
    if ((backendData == null ? void 0 : backendData.success) && (backendData == null ? void 0 : backendData.anomalies)) {
      return backendData;
    }
  } catch (err) {
    console.warn(
      "Could not reach backend for concurrency alerts:",
      err == null ? void 0 : err.message
    );
  }
  return {
    success: true,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    anomalies: []
  };
});

export { concurrencyAlerts_get as default };
//# sourceMappingURL=concurrency-alerts.get.mjs.map
