import { d as defineEventHandler, e as useRuntimeConfig, g as getQuery } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const jobs = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/jobs`, {
      query
    });
    if (Array.isArray(data)) return data;
    if ((data == null ? void 0 : data.data) && Array.isArray(data.data)) return data.data;
  } catch (error) {
    console.warn("Failed to fetch jobs from backend API:", error == null ? void 0 : error.message);
  }
  return [];
});

export { jobs as default };
//# sourceMappingURL=jobs.mjs.map
