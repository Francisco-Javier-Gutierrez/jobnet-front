import { y as defineEventHandler, e as useRuntimeConfig, i as getQuery } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const jobs = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/jobs`, {
      query
    });
    return data;
  } catch (error) {
    console.error("Error fetching jobs from AWS backend:", error);
    return [];
  }
});

export { jobs as default };
//# sourceMappingURL=jobs.mjs.map
