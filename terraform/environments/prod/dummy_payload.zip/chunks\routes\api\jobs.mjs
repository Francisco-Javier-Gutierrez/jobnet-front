import { d as defineEventHandler, e as useRuntimeConfig, g as getQuery, M as MOCK_VACANCIES } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const jobs = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/jobs`, {
      query
    });
    if (Array.isArray(data) && data.length > 0) return data;
    if ((data == null ? void 0 : data.data) && Array.isArray(data.data) && data.data.length > 0) return data;
  } catch (error) {
  }
  let results = [...MOCK_VACANCIES];
  if (query.q) {
    const qStr = String(query.q).toLowerCase();
    results = results.filter(
      (j) => {
        var _a, _b, _c;
        return ((_a = j.title) == null ? void 0 : _a.toLowerCase().includes(qStr)) || ((_b = j.company) == null ? void 0 : _b.toLowerCase().includes(qStr)) || ((_c = j.habilidadesRequeridas) == null ? void 0 : _c.some((s) => s.toLowerCase().includes(qStr)));
      }
    );
  }
  if (query.modalidad) {
    results = results.filter(
      (j) => {
        var _a;
        return ((_a = j.modalidad) == null ? void 0 : _a.toLowerCase()) === String(query.modalidad).toLowerCase();
      }
    );
  }
  return results;
});

export { jobs as default };
//# sourceMappingURL=jobs.mjs.map
