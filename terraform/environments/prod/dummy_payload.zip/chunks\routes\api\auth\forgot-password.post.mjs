import { y as defineEventHandler, r as readBody, j as createError, z as getCognitoConfig, A as calculateSecretHash, B as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const forgotPassword_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email } = body;
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email es obligatorio"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const forgotParams = {
    ClientId: clientId,
    Username: email
  };
  if (clientSecret) {
    forgotParams.SecretHash = calculateSecretHash(
      email,
      clientId,
      clientSecret
    );
  }
  try {
    await callCognito("ForgotPassword", forgotParams);
    return {
      success: true,
      message: "C\xF3digo de restablecimiento enviado"
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al solicitar el restablecimiento de contrase\xF1a",
      data: error.data || {}
    });
  }
});

export { forgotPassword_post as default };
//# sourceMappingURL=forgot-password.post.mjs.map
