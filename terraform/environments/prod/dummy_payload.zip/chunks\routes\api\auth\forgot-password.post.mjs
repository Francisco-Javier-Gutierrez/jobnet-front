import { d as defineEventHandler, r as readBody, o as createError, C as getCognitoConfig, D as calculateSecretHash, F as callCognito, e as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const forgotPassword_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email } = body;
  if (!email) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email es obligatorio"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const forgotParams = {
    ClientId: clientId,
    Username: email
  };
  if (clientSecret) {
    forgotParams.SecretHash = calculateSecretHash(
      email,
      clientId,
      clientSecret
    );
  }
  try {
    await callCognito("ForgotPassword", forgotParams);
    return {
      success: true,
      message: "C\xF3digo de restablecimiento enviado"
    };
  } catch (error) {
    try {
      const config = useRuntimeConfig();
      const profiles = await $fetch(
        `${config.public.apiUrl}/profiles`
      ).catch(() => []);
      const matching = profiles.filter(
        (p) => p.email && p.email.toLowerCase() === email.toLowerCase()
      );
      const isOnlyGoogle = matching.length > 0 && matching.every((p) => p.origenRegistro === "GOOGLE_OAUTH") && !matching.some(
        (p) => p.origenRegistro === "LINKED_GOOGLE" || p.linkedGoogleSub
      );
      if (isOnlyGoogle) {
        throw createError({
          statusCode: 400,
          statusMessage: "Esta cuenta fue creada mediante Google Sign-In y no utiliza una contrase\xF1a independiente. Por favor, inicia sesi\xF3n directamente con el bot\xF3n de Google.",
          data: { code: "FederatedUserAccount", isFederated: true }
        });
      }
    } catch (err) {
      if (err.statusCode) throw err;
    }
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al solicitar el restablecimiento de contrase\xF1a",
      data: error.data || {}
    });
  }
});

export { forgotPassword_post as default };
//# sourceMappingURL=forgot-password.post.mjs.map
