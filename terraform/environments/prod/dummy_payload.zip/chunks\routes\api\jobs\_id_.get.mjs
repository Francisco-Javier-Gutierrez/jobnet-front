import { d as defineEventHandler, e as useRuntimeConfig, l as createError } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  try {
    const data = await $fetch(`${config.public.apiUrl}/jobs/${id}`);
    if (data && (data.id || data.uniqueId || data.title)) {
      return data;
    }
  } catch (error) {
    console.warn(`Failed to fetch job ${id} from backend API:`, error == null ? void 0 : error.message);
  }
  throw createError({
    statusCode: 404,
    statusMessage: "Vacante no encontrada"
  });
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
