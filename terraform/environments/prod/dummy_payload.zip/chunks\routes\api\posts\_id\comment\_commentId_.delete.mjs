import { d as defineEventHandler, e as useRuntimeConfig, o as createError } from '../../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const _commentId__delete = defineEventHandler(async (event) => {
  var _a, _b;
  const config = useRuntimeConfig();
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  const commentId = (_b = event.context.params) == null ? void 0 : _b.commentId;
  try {
    const data = await $fetch(
      `${config.public.apiUrl}/posts/${id}/comment/${encodeURIComponent(commentId)}`,
      {
        method: "DELETE"
      }
    );
    return data;
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error deleting comment in AWS backend",
      data: error.data || {}
    });
  }
});

export { _commentId__delete as default };
//# sourceMappingURL=_commentId_.delete.mjs.map
