import { y as defineEventHandler, e as useRuntimeConfig } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const index_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  try {
    const data = await $fetch(`${config.public.apiUrl}/posts`);
    return data;
  } catch (error) {
    console.error("Error fetching posts from AWS backend:", error);
    return [];
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
