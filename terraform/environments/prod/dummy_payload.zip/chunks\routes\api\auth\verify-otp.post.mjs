import { d as defineEventHandler, r as readBody, l as createError, A as getCognitoConfig, B as calculateSecretHash, C as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const verifyOtp_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, code } = body;
  if (!email || !code) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email y c\xF3digo son obligatorios"
    });
  }
  const { clientId, clientSecret } = getCognitoConfig();
  const confirmSignUpParams = {
    ClientId: clientId,
    Username: email,
    ConfirmationCode: code
  };
  if (clientSecret) {
    confirmSignUpParams.SecretHash = calculateSecretHash(
      email,
      clientId,
      clientSecret
    );
  }
  try {
    await callCognito("ConfirmSignUp", confirmSignUpParams);
    return {
      success: true,
      message: "Cuenta verificada con \xE9xito"
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al verificar el c\xF3digo",
      data: error.data || {}
    });
  }
});

export { verifyOtp_post as default };
//# sourceMappingURL=verify-otp.post.mjs.map
