import { d as defineEventHandler, r as readBody, l as createError, C as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const associate_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { accessToken } = body || {};
  if (!accessToken) {
    throw createError({
      statusCode: 400,
      statusMessage: "AccessToken de sesi\xF3n requerido"
    });
  }
  try {
    const result = await callCognito("AssociateSoftwareToken", {
      AccessToken: accessToken
    });
    return {
      success: true,
      secretCode: result.SecretCode
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al asociar token MFA en Cognito",
      data: error.data || {}
    });
  }
});

export { associate_post as default };
//# sourceMappingURL=associate.post.mjs.map
