import { d as defineEventHandler, e as useRuntimeConfig, r as readBody, o as createError } from '../../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const bookmark_post = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const id = (_a = event.context.params) == null ? void 0 : _a.id;
  const body = await readBody(event);
  try {
    const data = await $fetch(
      `${config.public.apiUrl}/jobs/${id}/bookmark`,
      {
        method: "POST",
        body
      }
    );
    return data;
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error toggling bookmark in AWS backend",
      data: error.data || {}
    });
  }
});

export { bookmark_post as default };
//# sourceMappingURL=bookmark.post.mjs.map
