import { y as defineEventHandler, r as readBody, j as createError, B as callCognito } from '../../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const disable_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { accessToken } = body || {};
  if (!accessToken) {
    throw createError({
      statusCode: 400,
      statusMessage: "AccessToken de sesi\xF3n requerido"
    });
  }
  try {
    await callCognito("SetUserMFAPreference", {
      AccessToken: accessToken,
      SoftwareTokenMfaSettings: {
        Enabled: false,
        PreferredMfa: false
      }
    });
    return {
      success: true
    };
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error al desactivar MFA en Cognito",
      data: error.data || {}
    });
  }
});

export { disable_post as default };
//# sourceMappingURL=disable.post.mjs.map
