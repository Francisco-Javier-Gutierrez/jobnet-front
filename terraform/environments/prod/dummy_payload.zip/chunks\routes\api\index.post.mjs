import { d as defineEventHandler, e as useRuntimeConfig, r as readBody, l as createError } from '../../_/nitro.mjs';
import 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

const index_post = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const body = await readBody(event);
  try {
    const data = await $fetch(`${config.public.apiUrl}/posts`, {
      method: "POST",
      body
    });
    return data;
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || "Error creating post in AWS backend",
      data: error.data || {}
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
