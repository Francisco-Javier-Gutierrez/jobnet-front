import _CognitoProvider from 'next-auth/providers/cognito';
import _CredentialsProvider from 'next-auth/providers/credentials';
import crypto from 'crypto';
import { d as useTypedBackendConfig, e as useRuntimeConfig, E as ERROR_MESSAGES, f as defu, g as eventHandler, s as sendRedirect, h as getHeaders, p as parseCookies, i as getQuery, j as createError, k as isMethod, r as readBody, l as getRequestHost, m as getRequestProtocol, o as getServerOrigin, q as getResponseHeader, t as setResponseHeader, v as setCookie } from '../../../_/nitro.mjs';
import { AuthHandler } from 'next-auth/core';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'requrl';
import 'node:fs';
import 'node:path';
import 'node:crypto';

let preparedAuthjsHandler;
let usedSecret;
function NuxtAuthHandler(nuxtAuthOptions) {
  const trustHostUserPreference = useTypedBackendConfig(useRuntimeConfig(), "authjs").trustHost;
  usedSecret = nuxtAuthOptions?.secret;
  if (!usedSecret) {
    {
      throw new Error(ERROR_MESSAGES.NO_SECRET);
    }
  }
  const options = defu(nuxtAuthOptions, {
    secret: usedSecret,
    logger: void 0,
    providers: [],
    // SAFETY: We trust host here because `getRequestURLFromH3Event` is responsible for producing a trusted URL
    trustHost: true,
    // AuthJS uses `/auth` as default, but we rely on `/api/auth` (same as in previous `next-auth`)
    basePath: "/api/auth"
    // Uncomment to enable framework-author specific functionality
    // raw: raw as typeof raw
  });
  if (preparedAuthjsHandler) {
    console.error("You setup the auth handler for a second time - this is likely undesired. Make sure that you only call `NuxtAuthHandler( ... )` once");
  }
  preparedAuthjsHandler = (req) => AuthHandler({ req, options });
  return eventHandler(async (event) => {
    const { res } = event.node;
    const nextRequest = await createRequestForAuthjs(event, trustHostUserPreference);
    const nextResult = await preparedAuthjsHandler(nextRequest);
    if (nextResult.status) {
      res.statusCode = nextResult.status;
    }
    nextResult.cookies?.forEach((cookie) => setCookieDeduped(event, cookie.name, cookie.value, cookie.options));
    nextResult.headers?.forEach((header) => appendHeaderDeduped(event, header.key, header.value));
    if (!nextResult.redirect) {
      return nextResult.body;
    }
    if (nextRequest.body?.json) {
      return { url: nextResult.redirect };
    }
    return await sendRedirect(event, nextResult.redirect);
  });
}
async function createRequestForAuthjs(event, trustHostUserPreference) {
  const nextRequest = {
    host: getRequestURLFromH3Event(event, trustHostUserPreference).origin,
    body: void 0,
    cookies: parseCookies(event),
    query: void 0,
    headers: getHeaders(event),
    method: event.method,
    providerId: void 0,
    error: void 0
  };
  const query = getQuery(event);
  const { action, providerId } = parseActionAndProvider(event);
  const error = query.error;
  if (Array.isArray(error)) {
    throw createError({ statusCode: 400, statusMessage: "Error query parameter can only appear once" });
  }
  const body = isMethod(event, ["PATCH", "POST", "PUT", "DELETE"]) ? await readBody(event) : void 0;
  return {
    ...nextRequest,
    body,
    query,
    action,
    providerId,
    error: error ? String(error) : void 0
  };
}
function getRequestURLFromH3Event(event, trustHost) {
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  const base = getRequestBaseFromH3Event(event, trustHost);
  return new URL(path, base);
}
function getRequestBaseFromH3Event(event, trustHost) {
  if (trustHost) {
    const host = getRequestHost(event, { xForwardedHost: trustHost });
    const protocol = getRequestProtocol(event);
    return `${protocol}://${host}`;
  }
  const origin = getServerOrigin(event);
  return origin;
}
const SUPPORTED_ACTIONS = ["providers", "session", "csrf", "signin", "signout", "callback", "verify-request", "error", "_log"];
function parseActionAndProvider({ context }) {
  const params = context.params?._?.split("/");
  if (!params || ![1, 2].includes(params.length)) {
    throw createError({ statusCode: 400, statusMessage: `Invalid path used for auth-endpoint. Supply either one path parameter (e.g., \`/api/auth/session\`) or two (e.g., \`/api/auth/signin/github\` after the base path (in previous examples base path was: \`/api/auth/\`. Received \`${params}\`` });
  }
  const [unvalidatedAction, providerId] = params;
  const action = SUPPORTED_ACTIONS.find((action2) => action2 === unvalidatedAction);
  if (!action) {
    throw createError({ statusCode: 400, statusMessage: `Called endpoint with unsupported action ${unvalidatedAction}. Only the following actions are supported: ${SUPPORTED_ACTIONS.join(", ")}` });
  }
  return { action, providerId };
}
function appendHeaderDeduped(event, name, value) {
  let current = getResponseHeader(event, name);
  if (!current) {
    setResponseHeader(event, name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  if (current.includes(value)) {
    return;
  }
  current.push(value);
  setResponseHeader(event, name, current);
}
function setCookieDeduped(event, name, value, serializeOptions) {
  let setCookiesHeader = getResponseHeader(event, "set-cookie");
  if (setCookiesHeader) {
    if (!Array.isArray(setCookiesHeader)) {
      setCookiesHeader = [setCookiesHeader.toString()];
    }
    const filterBy = `${name}=`;
    setCookiesHeader = setCookiesHeader.filter((cookie) => !cookie.startsWith(filterBy));
    setResponseHeader(event, "set-cookie", setCookiesHeader);
  }
  setCookie(event, name, value, serializeOptions);
}

const CognitoProvider = _CognitoProvider.default || _CognitoProvider;
const CredentialsProvider = _CredentialsProvider.default || _CredentialsProvider;
function calculateSecretHash(username, clientId, clientSecret) {
  return crypto.createHmac("sha256", clientSecret).update(username + clientId).digest("base64");
}
const _____ = NuxtAuthHandler({
  providers: [
    CognitoProvider({
      clientId: process.env.COGNITO_CLIENT_ID || "",
      clientSecret: process.env.COGNITO_CLIENT_SECRET || "",
      issuer: process.env.COGNITO_ISSUER || ""
    }),
    CredentialsProvider({
      id: "credentials",
      name: "CognitoCredentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
        mfaCode: { label: "MfaCode", type: "text" },
        mfaSession: { label: "MfaSession", type: "text" },
        mfaChallenge: { label: "MfaChallenge", type: "text" }
      },
      async authorize(credentials) {
        if (!(credentials == null ? void 0 : credentials.email)) {
          throw new Error("Email es requerido");
        }
        const clientId = process.env.COGNITO_CLIENT_ID || "";
        const clientSecret = process.env.COGNITO_CLIENT_SECRET || "";
        const issuer = process.env.COGNITO_ISSUER || "";
        const region = process.env.COGNITO_REGION || issuer.split(".")[1] || "us-east-1";
        try {
          let responseData;
          if (credentials.mfaCode && credentials.mfaSession && credentials.mfaChallenge) {
            const challengeResponses = {
              USERNAME: credentials.email
            };
            if (credentials.mfaChallenge === "SMS_MFA") {
              challengeResponses.SMS_MFA_CODE = credentials.mfaCode;
            } else if (credentials.mfaChallenge === "SOFTWARE_TOKEN_MFA") {
              challengeResponses.SOFTWARE_TOKEN_MFA_CODE = credentials.mfaCode;
            } else {
              challengeResponses.ANSWER = credentials.mfaCode;
            }
            if (clientSecret) {
              challengeResponses.SECRET_HASH = calculateSecretHash(
                credentials.email,
                clientId,
                clientSecret
              );
            }
            const response = await fetch(
              `https://cognito-idp.${region}.amazonaws.com/`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-amz-json-1.1",
                  "X-Amz-Target": "AWSCognitoIdentityProviderService.RespondToAuthChallenge"
                },
                body: JSON.stringify({
                  ClientId: clientId,
                  ChallengeName: credentials.mfaChallenge,
                  Session: credentials.mfaSession,
                  ChallengeResponses: challengeResponses
                })
              }
            );
            responseData = await response.json();
            if (!response.ok) {
              const errorCode = responseData.__type ? responseData.__type.split("#")[1] : "MFAError";
              throw new Error(
                JSON.stringify({
                  code: errorCode,
                  message: responseData.message || "C\xF3digo de MFA incorrecto o expirado"
                })
              );
            }
          } else {
            if (!credentials.password) {
              throw new Error("Contrase\xF1a es requerida");
            }
            const authParams = {
              USERNAME: credentials.email,
              PASSWORD: credentials.password
            };
            if (clientSecret) {
              authParams.SECRET_HASH = calculateSecretHash(
                credentials.email,
                clientId,
                clientSecret
              );
            }
            const response = await fetch(
              `https://cognito-idp.${region}.amazonaws.com/`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-amz-json-1.1",
                  "X-Amz-Target": "AWSCognitoIdentityProviderService.InitiateAuth"
                },
                body: JSON.stringify({
                  AuthFlow: "USER_PASSWORD_AUTH",
                  ClientId: clientId,
                  AuthParameters: authParams
                })
              }
            );
            responseData = await response.json();
            if (!response.ok) {
              const errorCode = responseData.__type ? responseData.__type.split("#")[1] : "AuthError";
              throw new Error(
                JSON.stringify({
                  code: errorCode,
                  message: responseData.message || "Usuario o contrase\xF1a incorrectos"
                })
              );
            }
          }
          if (responseData.ChallengeName) {
            throw new Error(
              JSON.stringify({
                code: "ChallengeRequired",
                challengeName: responseData.ChallengeName,
                session: responseData.Session,
                email: credentials.email
              })
            );
          }
          const authResult = responseData.AuthenticationResult;
          if (authResult) {
            return {
              id: credentials.email,
              email: credentials.email,
              name: credentials.email.split("@")[0],
              idToken: authResult.IdToken,
              accessToken: authResult.AccessToken,
              refreshToken: authResult.RefreshToken
            };
          }
          return null;
        } catch (error) {
          return {
            id: "error",
            error: error.message
          };
        }
      }
    })
  ],
  callbacks: {
    async signIn({ user }) {
      if (user && user.error) {
        throw new Error(user.error);
      }
      return true;
    },
    async redirect({ url, baseUrl }) {
      if (!url || url === "undefined") {
        return baseUrl;
      }
      if (url.startsWith("/")) {
        return `${baseUrl}${url}`;
      }
      try {
        const parsedUrl = new URL(url);
        if (parsedUrl.origin === baseUrl) {
          return url;
        }
      } catch (e) {
      }
      return baseUrl;
    },
    async jwt({ token, user, account }) {
      if (account) {
        token.idToken = account.id_token;
        token.accessToken = account.access_token;
      }
      if (token.idToken) {
        try {
          const payloadBase64 = token.idToken.split(".")[1];
          if (payloadBase64) {
            const payloadJson = Buffer.from(payloadBase64, "base64").toString(
              "ascii"
            );
            const payload = JSON.parse(payloadJson);
            token.id = payload.sub;
            const groups = payload["cognito:groups"] || [];
            if (groups.includes("EMPRESA")) {
              token.tipoUsuario = "EMPRESA";
            } else if (groups.includes("ADMIN")) {
              token.tipoUsuario = "ADMIN";
            } else if (groups.includes("MODERATOR")) {
              token.tipoUsuario = "MODERATOR";
            } else {
              token.tipoUsuario = "CANDIDATO";
            }
          }
        } catch (e) {
          console.error("Error decoding Cognito IdToken payload:", e);
        }
      }
      if (user && !user.error) {
        token.email = user.email;
        token.idToken = user.idToken || token.idToken;
        token.accessToken = user.accessToken || token.accessToken;
        token.refreshToken = user.refreshToken;
      }
      return token;
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.idToken = token.idToken;
        session.accessToken = token.accessToken;
        session.refreshToken = token.refreshToken;
        session.user.id = token.id;
        session.user.tipoUsuario = token.tipoUsuario;
      }
      return session;
    }
  },
  pages: {
    signIn: "/login",
    error: "/login"
  },
  secret: process.env.NEXTAUTH_SECRET
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
